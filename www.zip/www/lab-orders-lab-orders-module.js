(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["lab-orders-lab-orders-module"],{

/***/ "1uXY":
/*!*************************************************!*\
  !*** ./src/app/lab-orders/lab-orders.module.ts ***!
  \*************************************************/
/*! exports provided: LabOrdersPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LabOrdersPageModule", function() { return LabOrdersPageModule; });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _lab_orders_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./lab-orders-routing.module */ "zmPX");
/* harmony import */ var _lab_orders_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./lab-orders.page */ "WkQ7");
/* harmony import */ var _shared_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../shared.module */ "d2mR");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngx-translate/core */ "sYmb");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ "fXoL");








class LabOrdersPageModule {
}
LabOrdersPageModule.ɵfac = function LabOrdersPageModule_Factory(t) { return new (t || LabOrdersPageModule)(); };
LabOrdersPageModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineNgModule"]({ type: LabOrdersPageModule });
LabOrdersPageModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineInjector"]({ imports: [[
            _angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["IonicModule"],
            _lab_orders_routing_module__WEBPACK_IMPORTED_MODULE_3__["LabOrdersPageRoutingModule"],
            _shared_module__WEBPACK_IMPORTED_MODULE_5__["SharedModule"],
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__["TranslateModule"]
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵsetNgModuleScope"](LabOrdersPageModule, { declarations: [_lab_orders_page__WEBPACK_IMPORTED_MODULE_4__["LabOrdersPage"]], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"],
        _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormsModule"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["IonicModule"],
        _lab_orders_routing_module__WEBPACK_IMPORTED_MODULE_3__["LabOrdersPageRoutingModule"],
        _shared_module__WEBPACK_IMPORTED_MODULE_5__["SharedModule"],
        _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__["TranslateModule"]] }); })();


/***/ }),

/***/ "WkQ7":
/*!***********************************************!*\
  !*** ./src/app/lab-orders/lab-orders.page.ts ***!
  \***********************************************/
/*! exports provided: LabOrdersPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LabOrdersPage", function() { return LabOrdersPage; });
/* harmony import */ var _home_mohammad_Work_RisosFront_Risos_node_modules_angular_devkit_build_angular_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@angular-devkit/build-angular/node_modules/@babel/runtime/helpers/esm/asyncToGenerator */ "20ZU");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs/operators */ "kU1M");
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../constants */ "l207");
/* harmony import */ var _ticket_ticket_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./ticket/ticket.component */ "rxeI");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var src_generated_graphql__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/generated/graphql */ "FJRG");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ngx-translate/core */ "sYmb");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _order_card_order_card_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../order-card/order-card.component */ "yyFB");












function LabOrdersPage_ion_row_8_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "ion-row", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "ion-col", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "app-order-card", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function LabOrdersPage_ion_row_8_Template_app_order_card_click_2_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r3);
      const item_r1 = ctx.$implicit;
      const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
      return ctx_r2.show(item_r1.node.id);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    const item_r1 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpropertyInterpolate"]("name", item_r1.node.relatedService.relatedPatient.relatedProfile.firstName);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpropertyInterpolate"]("img", item_r1.node.relatedService.relatedPatient.relatedProfile.profilePic);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpropertyInterpolate"]("status", item_r1.node.status);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpropertyInterpolate"]("date", item_r1.node.expectedDate);
  }
}

class LabOrdersPage {
  constructor(modalController, orders_l, route, router) {
    this.modalController = modalController;
    this.orders_l = orders_l;
    this.route = route;
    this.router = router;
    this.route.queryParams.subscribe(params => {
      if (this.router.getCurrentNavigation().extras.state) {
        this.id = this.router.getCurrentNavigation().extras.state.id;
        this.profile = this.router.getCurrentNavigation().extras.state.profile;
      }
    });
  }

  ngOnInit() {
    this.orders = this.orders_l.watch({
      dr: localStorage.getItem(_constants__WEBPACK_IMPORTED_MODULE_2__["ID"]),
      lab: this.id
    }).valueChanges.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_1__["map"])(result => result.data.allOrder.edges));
    console.log("profile id is " + this.profile);
  }

  show(e) {
    var _this = this;

    return Object(_home_mohammad_Work_RisosFront_Risos_node_modules_angular_devkit_build_angular_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      // console.log("hit")
      const modal = yield _this.modalController.create({
        component: _ticket_ticket_component__WEBPACK_IMPORTED_MODULE_3__["TicketComponent"],
        componentProps: {
          id: e,
          profile: _this.profile
        }
      });
      return yield modal.present();
    })();
  }

}

LabOrdersPage.ɵfac = function LabOrdersPage_Factory(t) {
  return new (t || LabOrdersPage)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ModalController"]), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](src_generated_graphql__WEBPACK_IMPORTED_MODULE_6__["Orders_LGQL"]), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_7__["ActivatedRoute"]), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_7__["Router"]));
};

LabOrdersPage.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({
  type: LabOrdersPage,
  selectors: [["app-lab-orders"]],
  decls: 10,
  vars: 3,
  consts: [["translate", "", 1, "ion-text-center", 2, "color", "white"], [1, "ion-justify-content-center", "ion-padding-horizontal", "ion-padding-top"], ["size", "12", "size-lg", "8", 1, "ion-no-padding"], ["placeholder", "Search Patient"], ["class", "ion-justify-content-center ion-padding-horizontal", 4, "ngFor", "ngForOf"], [1, "ion-justify-content-center", "ion-padding-horizontal"], ["size", "12", "size-lg", "8", 1, "ion-text-center"], [3, "name", "img", "status", "date", "click"]],
  template: function LabOrdersPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "ion-header");
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "ion-toolbar");
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "ion-title", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](3, "Lab Orders");
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](4, "ion-content");
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](5, "ion-row", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "ion-col", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](7, "ion-searchbar", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](8, LabOrdersPage_ion_row_8_Template, 3, 4, "ion-row", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](9, "async");
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](8);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](9, 1, ctx.orders));
    }
  },
  directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonHeader"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonToolbar"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonTitle"], _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__["TranslateDirective"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonContent"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonRow"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonCol"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonSearchbar"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["TextValueAccessor"], _angular_common__WEBPACK_IMPORTED_MODULE_9__["NgForOf"], _order_card_order_card_component__WEBPACK_IMPORTED_MODULE_10__["OrderCardComponent"]],
  pipes: [_angular_common__WEBPACK_IMPORTED_MODULE_9__["AsyncPipe"]],
  styles: ["ion-toolbar[_ngcontent-%COMP%] {\n  --background: #0000ff;\n}\n\nion-content[_ngcontent-%COMP%] {\n  --background:#f2f2f7;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uL2xhYi1vcmRlcnMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UscUJBQUE7QUFDRjs7QUFFQTtFQUNFLG9CQUFBO0FBQ0YiLCJmaWxlIjoibGFiLW9yZGVycy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tdG9vbGJhciB7XG4gIC0tYmFja2dyb3VuZDogIzAwMDBmZjtcbn1cblxuaW9uLWNvbnRlbnR7XG4gIC0tYmFja2dyb3VuZDojZjJmMmY3O1xufVxuIl19 */"]
});

/***/ }),

/***/ "zmPX":
/*!*********************************************************!*\
  !*** ./src/app/lab-orders/lab-orders-routing.module.ts ***!
  \*********************************************************/
/*! exports provided: LabOrdersPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LabOrdersPageRoutingModule", function() { return LabOrdersPageRoutingModule; });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _lab_orders_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./lab-orders.page */ "WkQ7");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");




const routes = [
    {
        path: '',
        component: _lab_orders_page__WEBPACK_IMPORTED_MODULE_1__["LabOrdersPage"]
    }
];
class LabOrdersPageRoutingModule {
}
LabOrdersPageRoutingModule.ɵfac = function LabOrdersPageRoutingModule_Factory(t) { return new (t || LabOrdersPageRoutingModule)(); };
LabOrdersPageRoutingModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineNgModule"]({ type: LabOrdersPageRoutingModule });
LabOrdersPageRoutingModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({ imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"].forChild(routes)], _angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsetNgModuleScope"](LabOrdersPageRoutingModule, { imports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]], exports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]] }); })();


/***/ })

}]);
//# sourceMappingURL=lab-orders-lab-orders-module.js.map