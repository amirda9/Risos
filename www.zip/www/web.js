(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["web"],{

/***/ "B5q2":
/*!************************************************************!*\
  !*** ./node_modules/@capacitor/filesystem/dist/esm/web.js ***!
  \************************************************************/
/*! exports provided: FilesystemWeb */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FilesystemWeb", function() { return FilesystemWeb; });
/* harmony import */ var _home_mohammad_Work_RisosFront_Risos_node_modules_angular_devkit_build_angular_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@angular-devkit/build-angular/node_modules/@babel/runtime/helpers/esm/asyncToGenerator */ "20ZU");
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @capacitor/core */ "FUe0");



function resolve(path) {
  const posix = path.split('/').filter(item => item !== '.');
  const newPosix = [];
  posix.forEach(item => {
    if (item === '..' && newPosix.length > 0 && newPosix[newPosix.length - 1] !== '..') {
      newPosix.pop();
    } else {
      newPosix.push(item);
    }
  });
  return newPosix.join('/');
}

function isPathParent(parent, children) {
  parent = resolve(parent);
  children = resolve(children);
  const pathsA = parent.split('/');
  const pathsB = children.split('/');
  return parent !== children && pathsA.every((value, index) => value === pathsB[index]);
}

class FilesystemWeb extends _capacitor_core__WEBPACK_IMPORTED_MODULE_1__["WebPlugin"] {
  constructor() {
    super(...arguments);
    this.DB_VERSION = 1;
    this.DB_NAME = 'Disc';
    this._writeCmds = ['add', 'put', 'delete'];
  }

  initDb() {
    var _this = this;

    return Object(_home_mohammad_Work_RisosFront_Risos_node_modules_angular_devkit_build_angular_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (_this._db !== undefined) {
        return _this._db;
      }

      if (!('indexedDB' in window)) {
        throw _this.unavailable("This browser doesn't support IndexedDB");
      }

      return new Promise((resolve, reject) => {
        const request = indexedDB.open(_this.DB_NAME, _this.DB_VERSION);
        request.onupgradeneeded = FilesystemWeb.doUpgrade;

        request.onsuccess = () => {
          _this._db = request.result;
          resolve(request.result);
        };

        request.onerror = () => reject(request.error);

        request.onblocked = () => {
          console.warn('db blocked');
        };
      });
    })();
  }

  static doUpgrade(event) {
    const eventTarget = event.target;
    const db = eventTarget.result;

    switch (event.oldVersion) {
      case 0:
      case 1:
      default:
        {
          if (db.objectStoreNames.contains('FileStorage')) {
            db.deleteObjectStore('FileStorage');
          }

          const store = db.createObjectStore('FileStorage', {
            keyPath: 'path'
          });
          store.createIndex('by_folder', 'folder');
        }
    }
  }

  dbRequest(cmd, args) {
    var _this2 = this;

    return Object(_home_mohammad_Work_RisosFront_Risos_node_modules_angular_devkit_build_angular_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const readFlag = _this2._writeCmds.indexOf(cmd) !== -1 ? 'readwrite' : 'readonly';
      return _this2.initDb().then(conn => {
        return new Promise((resolve, reject) => {
          const tx = conn.transaction(['FileStorage'], readFlag);
          const store = tx.objectStore('FileStorage');
          const req = store[cmd](...args);

          req.onsuccess = () => resolve(req.result);

          req.onerror = () => reject(req.error);
        });
      });
    })();
  }

  dbIndexRequest(indexName, cmd, args) {
    var _this3 = this;

    return Object(_home_mohammad_Work_RisosFront_Risos_node_modules_angular_devkit_build_angular_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const readFlag = _this3._writeCmds.indexOf(cmd) !== -1 ? 'readwrite' : 'readonly';
      return _this3.initDb().then(conn => {
        return new Promise((resolve, reject) => {
          const tx = conn.transaction(['FileStorage'], readFlag);
          const store = tx.objectStore('FileStorage');
          const index = store.index(indexName);
          const req = index[cmd](...args);

          req.onsuccess = () => resolve(req.result);

          req.onerror = () => reject(req.error);
        });
      });
    })();
  }

  getPath(directory, uriPath) {
    const cleanedUriPath = uriPath !== undefined ? uriPath.replace(/^[/]+|[/]+$/g, '') : '';
    let fsPath = '';
    if (directory !== undefined) fsPath += '/' + directory;
    if (uriPath !== '') fsPath += '/' + cleanedUriPath;
    return fsPath;
  }

  clear() {
    var _this4 = this;

    return Object(_home_mohammad_Work_RisosFront_Risos_node_modules_angular_devkit_build_angular_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const conn = yield _this4.initDb();
      const tx = conn.transaction(['FileStorage'], 'readwrite');
      const store = tx.objectStore('FileStorage');
      store.clear();
    })();
  }
  /**
   * Read a file from disk
   * @param options options for the file read
   * @return a promise that resolves with the read file data result
   */


  readFile(options) {
    var _this5 = this;

    return Object(_home_mohammad_Work_RisosFront_Risos_node_modules_angular_devkit_build_angular_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const path = _this5.getPath(options.directory, options.path); // const encoding = options.encoding;


      const entry = yield _this5.dbRequest('get', [path]);
      if (entry === undefined) throw Error('File does not exist.');
      return {
        data: entry.content ? entry.content : ''
      };
    })();
  }
  /**
   * Write a file to disk in the specified location on device
   * @param options options for the file write
   * @return a promise that resolves with the file write result
   */


  writeFile(options) {
    var _this6 = this;

    return Object(_home_mohammad_Work_RisosFront_Risos_node_modules_angular_devkit_build_angular_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const path = _this6.getPath(options.directory, options.path);

      const data = options.data;
      const doRecursive = options.recursive;
      const occupiedEntry = yield _this6.dbRequest('get', [path]);
      if (occupiedEntry && occupiedEntry.type === 'directory') throw 'The supplied path is a directory.';
      const encoding = options.encoding;
      const parentPath = path.substr(0, path.lastIndexOf('/'));
      const parentEntry = yield _this6.dbRequest('get', [parentPath]);

      if (parentEntry === undefined) {
        const subDirIndex = parentPath.indexOf('/', 1);

        if (subDirIndex !== -1) {
          const parentArgPath = parentPath.substr(subDirIndex);
          yield _this6.mkdir({
            path: parentArgPath,
            directory: options.directory,
            recursive: doRecursive
          });
        }
      }

      const now = Date.now();
      const pathObj = {
        path: path,
        folder: parentPath,
        type: 'file',
        size: data.length,
        ctime: now,
        mtime: now,
        content: !encoding && data.indexOf(',') >= 0 ? data.split(',')[1] : data
      };
      yield _this6.dbRequest('put', [pathObj]);
      return {
        uri: pathObj.path
      };
    })();
  }
  /**
   * Append to a file on disk in the specified location on device
   * @param options options for the file append
   * @return a promise that resolves with the file write result
   */


  appendFile(options) {
    var _this7 = this;

    return Object(_home_mohammad_Work_RisosFront_Risos_node_modules_angular_devkit_build_angular_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const path = _this7.getPath(options.directory, options.path);

      let data = options.data; // const encoding = options.encoding;

      const parentPath = path.substr(0, path.lastIndexOf('/'));
      const now = Date.now();
      let ctime = now;
      const occupiedEntry = yield _this7.dbRequest('get', [path]);
      if (occupiedEntry && occupiedEntry.type === 'directory') throw 'The supplied path is a directory.';
      const parentEntry = yield _this7.dbRequest('get', [parentPath]);

      if (parentEntry === undefined) {
        const subDirIndex = parentPath.indexOf('/', 1);

        if (subDirIndex !== -1) {
          const parentArgPath = parentPath.substr(subDirIndex);
          yield _this7.mkdir({
            path: parentArgPath,
            directory: options.directory,
            recursive: true
          });
        }
      }

      if (occupiedEntry !== undefined) {
        data = occupiedEntry.content + data;
        ctime = occupiedEntry.ctime;
      }

      const pathObj = {
        path: path,
        folder: parentPath,
        type: 'file',
        size: data.length,
        ctime: ctime,
        mtime: now,
        content: data
      };
      yield _this7.dbRequest('put', [pathObj]);
    })();
  }
  /**
   * Delete a file from disk
   * @param options options for the file delete
   * @return a promise that resolves with the deleted file data result
   */


  deleteFile(options) {
    var _this8 = this;

    return Object(_home_mohammad_Work_RisosFront_Risos_node_modules_angular_devkit_build_angular_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const path = _this8.getPath(options.directory, options.path);

      const entry = yield _this8.dbRequest('get', [path]);
      if (entry === undefined) throw Error('File does not exist.');
      const entries = yield _this8.dbIndexRequest('by_folder', 'getAllKeys', [IDBKeyRange.only(path)]);
      if (entries.length !== 0) throw Error('Folder is not empty.');
      yield _this8.dbRequest('delete', [path]);
    })();
  }
  /**
   * Create a directory.
   * @param options options for the mkdir
   * @return a promise that resolves with the mkdir result
   */


  mkdir(options) {
    var _this9 = this;

    return Object(_home_mohammad_Work_RisosFront_Risos_node_modules_angular_devkit_build_angular_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const path = _this9.getPath(options.directory, options.path);

      const doRecursive = options.recursive;
      const parentPath = path.substr(0, path.lastIndexOf('/'));
      const depth = (path.match(/\//g) || []).length;
      const parentEntry = yield _this9.dbRequest('get', [parentPath]);
      const occupiedEntry = yield _this9.dbRequest('get', [path]);
      if (depth === 1) throw Error('Cannot create Root directory');
      if (occupiedEntry !== undefined) throw Error('Current directory does already exist.');
      if (!doRecursive && depth !== 2 && parentEntry === undefined) throw Error('Parent directory must exist');

      if (doRecursive && depth !== 2 && parentEntry === undefined) {
        const parentArgPath = parentPath.substr(parentPath.indexOf('/', 1));
        yield _this9.mkdir({
          path: parentArgPath,
          directory: options.directory,
          recursive: doRecursive
        });
      }

      const now = Date.now();
      const pathObj = {
        path: path,
        folder: parentPath,
        type: 'directory',
        size: 0,
        ctime: now,
        mtime: now
      };
      yield _this9.dbRequest('put', [pathObj]);
    })();
  }
  /**
   * Remove a directory
   * @param options the options for the directory remove
   */


  rmdir(options) {
    var _this10 = this;

    return Object(_home_mohammad_Work_RisosFront_Risos_node_modules_angular_devkit_build_angular_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const {
        path,
        directory,
        recursive
      } = options;

      const fullPath = _this10.getPath(directory, path);

      const entry = yield _this10.dbRequest('get', [fullPath]);
      if (entry === undefined) throw Error('Folder does not exist.');
      if (entry.type !== 'directory') throw Error('Requested path is not a directory');
      const readDirResult = yield _this10.readdir({
        path,
        directory
      });
      if (readDirResult.files.length !== 0 && !recursive) throw Error('Folder is not empty');

      for (const entry of readDirResult.files) {
        const entryPath = `${path}/${entry}`;
        const entryObj = yield _this10.stat({
          path: entryPath,
          directory
        });

        if (entryObj.type === 'file') {
          yield _this10.deleteFile({
            path: entryPath,
            directory
          });
        } else {
          yield _this10.rmdir({
            path: entryPath,
            directory,
            recursive
          });
        }
      }

      yield _this10.dbRequest('delete', [fullPath]);
    })();
  }
  /**
   * Return a list of files from the directory (not recursive)
   * @param options the options for the readdir operation
   * @return a promise that resolves with the readdir directory listing result
   */


  readdir(options) {
    var _this11 = this;

    return Object(_home_mohammad_Work_RisosFront_Risos_node_modules_angular_devkit_build_angular_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const path = _this11.getPath(options.directory, options.path);

      const entry = yield _this11.dbRequest('get', [path]);
      if (options.path !== '' && entry === undefined) throw Error('Folder does not exist.');
      const entries = yield _this11.dbIndexRequest('by_folder', 'getAllKeys', [IDBKeyRange.only(path)]);
      const names = entries.map(e => {
        return e.substring(path.length + 1);
      });
      return {
        files: names
      };
    })();
  }
  /**
   * Return full File URI for a path and directory
   * @param options the options for the stat operation
   * @return a promise that resolves with the file stat result
   */


  getUri(options) {
    var _this12 = this;

    return Object(_home_mohammad_Work_RisosFront_Risos_node_modules_angular_devkit_build_angular_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const path = _this12.getPath(options.directory, options.path);

      let entry = yield _this12.dbRequest('get', [path]);

      if (entry === undefined) {
        entry = yield _this12.dbRequest('get', [path + '/']);
      }

      return {
        uri: (entry === null || entry === void 0 ? void 0 : entry.path) || path
      };
    })();
  }
  /**
   * Return data about a file
   * @param options the options for the stat operation
   * @return a promise that resolves with the file stat result
   */


  stat(options) {
    var _this13 = this;

    return Object(_home_mohammad_Work_RisosFront_Risos_node_modules_angular_devkit_build_angular_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const path = _this13.getPath(options.directory, options.path);

      let entry = yield _this13.dbRequest('get', [path]);

      if (entry === undefined) {
        entry = yield _this13.dbRequest('get', [path + '/']);
      }

      if (entry === undefined) throw Error('Entry does not exist.');
      return {
        type: entry.type,
        size: entry.size,
        ctime: entry.ctime,
        mtime: entry.mtime,
        uri: entry.path
      };
    })();
  }
  /**
   * Rename a file or directory
   * @param options the options for the rename operation
   * @return a promise that resolves with the rename result
   */


  rename(options) {
    var _this14 = this;

    return Object(_home_mohammad_Work_RisosFront_Risos_node_modules_angular_devkit_build_angular_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return _this14._copy(options, true);
    })();
  }
  /**
   * Copy a file or directory
   * @param options the options for the copy operation
   * @return a promise that resolves with the copy result
   */


  copy(options) {
    var _this15 = this;

    return Object(_home_mohammad_Work_RisosFront_Risos_node_modules_angular_devkit_build_angular_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return _this15._copy(options, false);
    })();
  }

  requestPermissions() {
    return Object(_home_mohammad_Work_RisosFront_Risos_node_modules_angular_devkit_build_angular_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return {
        publicStorage: 'granted'
      };
    })();
  }

  checkPermissions() {
    return Object(_home_mohammad_Work_RisosFront_Risos_node_modules_angular_devkit_build_angular_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      return {
        publicStorage: 'granted'
      };
    })();
  }
  /**
   * Function that can perform a copy or a rename
   * @param options the options for the rename operation
   * @param doRename whether to perform a rename or copy operation
   * @return a promise that resolves with the result
   */


  _copy(options, doRename = false) {
    var _this16 = this;

    return Object(_home_mohammad_Work_RisosFront_Risos_node_modules_angular_devkit_build_angular_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      let {
        toDirectory
      } = options;
      const {
        to,
        from,
        directory: fromDirectory
      } = options;

      if (!to || !from) {
        throw Error('Both to and from must be provided');
      } // If no "to" directory is provided, use the "from" directory


      if (!toDirectory) {
        toDirectory = fromDirectory;
      }

      const fromPath = _this16.getPath(fromDirectory, from);

      const toPath = _this16.getPath(toDirectory, to); // Test that the "to" and "from" locations are different


      if (fromPath === toPath) {
        return;
      }

      if (isPathParent(fromPath, toPath)) {
        throw Error('To path cannot contain the from path');
      } // Check the state of the "to" location


      let toObj;

      try {
        toObj = yield _this16.stat({
          path: to,
          directory: toDirectory
        });
      } catch (e) {
        // To location does not exist, ensure the directory containing "to" location exists and is a directory
        const toPathComponents = to.split('/');
        toPathComponents.pop();
        const toPath = toPathComponents.join('/'); // Check the containing directory of the "to" location exists

        if (toPathComponents.length > 0) {
          const toParentDirectory = yield _this16.stat({
            path: toPath,
            directory: toDirectory
          });

          if (toParentDirectory.type !== 'directory') {
            throw new Error('Parent directory of the to path is a file');
          }
        }
      } // Cannot overwrite a directory


      if (toObj && toObj.type === 'directory') {
        throw new Error('Cannot overwrite a directory with a file');
      } // Ensure the "from" object exists


      const fromObj = yield _this16.stat({
        path: from,
        directory: fromDirectory
      }); // Set the mtime/ctime of the supplied path

      const updateTime = /*#__PURE__*/function () {
        var _ref = Object(_home_mohammad_Work_RisosFront_Risos_node_modules_angular_devkit_build_angular_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (path, ctime, mtime) {
          const fullPath = _this16.getPath(toDirectory, path);

          const entry = yield _this16.dbRequest('get', [fullPath]);
          entry.ctime = ctime;
          entry.mtime = mtime;
          yield _this16.dbRequest('put', [entry]);
        });

        return function updateTime(_x, _x2, _x3) {
          return _ref.apply(this, arguments);
        };
      }();

      const ctime = fromObj.ctime ? fromObj.ctime : Date.now();

      switch (fromObj.type) {
        // The "from" object is a file
        case 'file':
          {
            // Read the file
            const file = yield _this16.readFile({
              path: from,
              directory: fromDirectory
            }); // Optionally remove the file

            if (doRename) {
              yield _this16.deleteFile({
                path: from,
                directory: fromDirectory
              });
            } // Write the file to the new location


            yield _this16.writeFile({
              path: to,
              directory: toDirectory,
              data: file.data
            }); // Copy the mtime/ctime of a renamed file

            if (doRename) {
              yield updateTime(to, ctime, fromObj.mtime);
            } // Resolve promise


            return;
          }

        case 'directory':
          {
            if (toObj) {
              throw Error('Cannot move a directory over an existing object');
            }

            try {
              // Create the to directory
              yield _this16.mkdir({
                path: to,
                directory: toDirectory,
                recursive: false
              }); // Copy the mtime/ctime of a renamed directory

              if (doRename) {
                yield updateTime(to, ctime, fromObj.mtime);
              }
            } catch (e) {// ignore
            } // Iterate over the contents of the from location


            const contents = (yield _this16.readdir({
              path: from,
              directory: fromDirectory
            })).files;

            for (const filename of contents) {
              // Move item from the from directory to the to directory
              yield _this16._copy({
                from: `${from}/${filename}`,
                to: `${to}/${filename}`,
                directory: fromDirectory,
                toDirectory
              }, doRename);
            } // Optionally remove the original from directory


            if (doRename) {
              yield _this16.rmdir({
                path: from,
                directory: fromDirectory
              });
            }
          }
      }
    })();
  }

}
FilesystemWeb._debug = true; //# sourceMappingURL=web.js.map

/***/ }),

/***/ "wzPO":
/*!********************************************************!*\
  !*** ./node_modules/@capacitor/camera/dist/esm/web.js ***!
  \********************************************************/
/*! exports provided: CameraWeb, Camera */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CameraWeb", function() { return CameraWeb; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Camera", function() { return Camera; });
/* harmony import */ var _home_mohammad_Work_RisosFront_Risos_node_modules_angular_devkit_build_angular_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@angular-devkit/build-angular/node_modules/@babel/runtime/helpers/esm/asyncToGenerator */ "20ZU");
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @capacitor/core */ "FUe0");
/* harmony import */ var _definitions__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./definitions */ "dTEF");



class CameraWeb extends _capacitor_core__WEBPACK_IMPORTED_MODULE_1__["WebPlugin"] {
  getPhoto(options) {
    var _this = this;

    return Object(_home_mohammad_Work_RisosFront_Risos_node_modules_angular_devkit_build_angular_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      // eslint-disable-next-line no-async-promise-executor
      return new Promise( /*#__PURE__*/function () {
        var _ref = Object(_home_mohammad_Work_RisosFront_Risos_node_modules_angular_devkit_build_angular_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (resolve, reject) {
          if (options.webUseInput || options.source === _definitions__WEBPACK_IMPORTED_MODULE_2__["CameraSource"].Photos) {
            _this.fileInputExperience(options, resolve);
          } else if (options.source === _definitions__WEBPACK_IMPORTED_MODULE_2__["CameraSource"].Prompt) {
            let actionSheet = document.querySelector('pwa-action-sheet');

            if (!actionSheet) {
              actionSheet = document.createElement('pwa-action-sheet');
              document.body.appendChild(actionSheet);
            }

            actionSheet.header = options.promptLabelHeader || 'Photo';
            actionSheet.cancelable = false;
            actionSheet.options = [{
              title: options.promptLabelPhoto || 'From Photos'
            }, {
              title: options.promptLabelPicture || 'Take Picture'
            }];
            actionSheet.addEventListener('onSelection', /*#__PURE__*/function () {
              var _ref2 = Object(_home_mohammad_Work_RisosFront_Risos_node_modules_angular_devkit_build_angular_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (e) {
                const selection = e.detail;

                if (selection === 0) {
                  _this.fileInputExperience(options, resolve);
                } else {
                  _this.cameraExperience(options, resolve, reject);
                }
              });

              return function (_x3) {
                return _ref2.apply(this, arguments);
              };
            }());
          } else {
            _this.cameraExperience(options, resolve, reject);
          }
        });

        return function (_x, _x2) {
          return _ref.apply(this, arguments);
        };
      }());
    })();
  }

  cameraExperience(options, resolve, reject) {
    var _this2 = this;

    return Object(_home_mohammad_Work_RisosFront_Risos_node_modules_angular_devkit_build_angular_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (customElements.get('pwa-camera-modal')) {
        const cameraModal = document.createElement('pwa-camera-modal');
        document.body.appendChild(cameraModal);

        try {
          yield cameraModal.componentOnReady();
          cameraModal.addEventListener('onPhoto', /*#__PURE__*/function () {
            var _ref3 = Object(_home_mohammad_Work_RisosFront_Risos_node_modules_angular_devkit_build_angular_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (e) {
              const photo = e.detail;

              if (photo === null) {
                reject(new _capacitor_core__WEBPACK_IMPORTED_MODULE_1__["CapacitorException"]('User cancelled photos app'));
              } else if (photo instanceof Error) {
                reject(photo);
              } else {
                resolve(yield _this2._getCameraPhoto(photo, options));
              }

              cameraModal.dismiss();
              document.body.removeChild(cameraModal);
            });

            return function (_x4) {
              return _ref3.apply(this, arguments);
            };
          }());
          cameraModal.present();
        } catch (e) {
          _this2.fileInputExperience(options, resolve);
        }
      } else {
        console.error(`Unable to load PWA Element 'pwa-camera-modal'. See the docs: https://capacitorjs.com/docs/pwa-elements.`);

        _this2.fileInputExperience(options, resolve);
      }
    })();
  }

  fileInputExperience(options, resolve) {
    let input = document.querySelector('#_capacitor-camera-input');

    const cleanup = () => {
      var _a;

      (_a = input.parentNode) === null || _a === void 0 ? void 0 : _a.removeChild(input);
    };

    if (!input) {
      input = document.createElement('input');
      input.id = '_capacitor-camera-input';
      input.type = 'file';
      input.hidden = true;
      document.body.appendChild(input);
      input.addEventListener('change', _e => {
        const file = input.files[0];
        let format = 'jpeg';

        if (file.type === 'image/png') {
          format = 'png';
        } else if (file.type === 'image/gif') {
          format = 'gif';
        }

        if (options.resultType === 'dataUrl' || options.resultType === 'base64') {
          const reader = new FileReader();
          reader.addEventListener('load', () => {
            if (options.resultType === 'dataUrl') {
              resolve({
                dataUrl: reader.result,
                format
              });
            } else if (options.resultType === 'base64') {
              const b64 = reader.result.split(',')[1];
              resolve({
                base64String: b64,
                format
              });
            }

            cleanup();
          });
          reader.readAsDataURL(file);
        } else {
          resolve({
            webPath: URL.createObjectURL(file),
            format: format
          });
          cleanup();
        }
      });
    }

    input.accept = 'image/*';
    input.capture = true;

    if (options.source === _definitions__WEBPACK_IMPORTED_MODULE_2__["CameraSource"].Photos || options.source === _definitions__WEBPACK_IMPORTED_MODULE_2__["CameraSource"].Prompt) {
      input.removeAttribute('capture');
    } else if (options.direction === _definitions__WEBPACK_IMPORTED_MODULE_2__["CameraDirection"].Front) {
      input.capture = 'user';
    } else if (options.direction === _definitions__WEBPACK_IMPORTED_MODULE_2__["CameraDirection"].Rear) {
      input.capture = 'environment';
    }

    input.click();
  }

  _getCameraPhoto(photo, options) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      const format = photo.type.split('/')[1];

      if (options.resultType === 'uri') {
        resolve({
          webPath: URL.createObjectURL(photo),
          format: format
        });
      } else {
        reader.readAsDataURL(photo);

        reader.onloadend = () => {
          const r = reader.result;

          if (options.resultType === 'dataUrl') {
            resolve({
              dataUrl: r,
              format: format
            });
          } else {
            resolve({
              base64String: r.split(',')[1],
              format: format
            });
          }
        };

        reader.onerror = e => {
          reject(e);
        };
      }
    });
  }

  checkPermissions() {
    var _this3 = this;

    return Object(_home_mohammad_Work_RisosFront_Risos_node_modules_angular_devkit_build_angular_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (typeof navigator === 'undefined' || !navigator.permissions) {
        throw _this3.unavailable('Permissions API not available in this browser');
      }

      try {
        // https://developer.mozilla.org/en-US/docs/Web/API/Permissions/query
        // the specific permissions that are supported varies among browsers that implement the
        // permissions API, so we need a try/catch in case 'camera' is invalid
        const permission = yield window.navigator.permissions.query({
          name: 'camera'
        });
        return {
          camera: permission.state,
          photos: 'granted'
        };
      } catch (_a) {
        throw _this3.unavailable('Camera permissions are not available in this browser');
      }
    })();
  }

  requestPermissions() {
    var _this4 = this;

    return Object(_home_mohammad_Work_RisosFront_Risos_node_modules_angular_devkit_build_angular_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      throw _this4.unimplemented('Not implemented on web.');
    })();
  }

}
const Camera = new CameraWeb();
 //# sourceMappingURL=web.js.map

/***/ })

}]);
//# sourceMappingURL=web.js.map