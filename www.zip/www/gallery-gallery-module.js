(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["gallery-gallery-module"],{

/***/ "3ros":
/*!*******************************************!*\
  !*** ./src/app/gallery/gallery.module.ts ***!
  \*******************************************/
/*! exports provided: GalleryPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GalleryPageModule", function() { return GalleryPageModule; });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _gallery_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./gallery-routing.module */ "Fjtg");
/* harmony import */ var _gallery_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./gallery.page */ "vl1N");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngx-translate/core */ "sYmb");
/* harmony import */ var ngx_photo_editor__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ngx-photo-editor */ "kUS0");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ "fXoL");








class GalleryPageModule {
}
GalleryPageModule.ɵfac = function GalleryPageModule_Factory(t) { return new (t || GalleryPageModule)(); };
GalleryPageModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineNgModule"]({ type: GalleryPageModule });
GalleryPageModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineInjector"]({ imports: [[
            _angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["IonicModule"],
            _gallery_routing_module__WEBPACK_IMPORTED_MODULE_3__["GalleryPageRoutingModule"],
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__["TranslateModule"],
            ngx_photo_editor__WEBPACK_IMPORTED_MODULE_6__["NgxPhotoEditorModule"],
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵsetNgModuleScope"](GalleryPageModule, { declarations: [_gallery_page__WEBPACK_IMPORTED_MODULE_4__["GalleryPage"]], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"],
        _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormsModule"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["IonicModule"],
        _gallery_routing_module__WEBPACK_IMPORTED_MODULE_3__["GalleryPageRoutingModule"],
        _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__["TranslateModule"],
        ngx_photo_editor__WEBPACK_IMPORTED_MODULE_6__["NgxPhotoEditorModule"]] }); })();


/***/ }),

/***/ "Fjtg":
/*!***************************************************!*\
  !*** ./src/app/gallery/gallery-routing.module.ts ***!
  \***************************************************/
/*! exports provided: GalleryPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GalleryPageRoutingModule", function() { return GalleryPageRoutingModule; });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _gallery_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./gallery.page */ "vl1N");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");




const routes = [
    {
        path: '',
        component: _gallery_page__WEBPACK_IMPORTED_MODULE_1__["GalleryPage"]
    }
];
class GalleryPageRoutingModule {
}
GalleryPageRoutingModule.ɵfac = function GalleryPageRoutingModule_Factory(t) { return new (t || GalleryPageRoutingModule)(); };
GalleryPageRoutingModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineNgModule"]({ type: GalleryPageRoutingModule });
GalleryPageRoutingModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({ imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"].forChild(routes)], _angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsetNgModuleScope"](GalleryPageRoutingModule, { imports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]], exports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]] }); })();


/***/ }),

/***/ "vl1N":
/*!*****************************************!*\
  !*** ./src/app/gallery/gallery.page.ts ***!
  \*****************************************/
/*! exports provided: GalleryPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GalleryPage", function() { return GalleryPage; });
/* harmony import */ var _home_mohammad_Work_RisosFront_Risos_node_modules_angular_devkit_build_angular_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@angular-devkit/build-angular/node_modules/@babel/runtime/helpers/esm/asyncToGenerator */ "20ZU");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _generated_graphql__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../generated/graphql */ "FJRG");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngx-translate/core */ "sYmb");
/* harmony import */ var ngx_photo_editor__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ngx-photo-editor */ "kUS0");







class GalleryPage {
  constructor(update_pic, delpic, alertcontroller, route, router, patientgql) {
    this.update_pic = update_pic;
    this.delpic = delpic;
    this.alertcontroller = alertcontroller;
    this.route = route;
    this.router = router;
    this.patientgql = patientgql;
    this.route.queryParams.subscribe(params => {
      if (this.router.getCurrentNavigation().extras.state) {
        this.id = this.router.getCurrentNavigation().extras.state.id; // console.log(this.id);

        this.patientgql.watch({
          id: "Patient:" + this.id
        }).valueChanges.subscribe(res => {
          if (res.data.Patient.patientPic.fullSmileImage) {
            this.fullimg = res.data.Patient.patientPic.fullSmileImage;
          } else {
            this.fullimg = "profile/default-profile.jpg";
          }

          if (res.data.Patient.patientPic.smileImage) {
            this.smileimg = res.data.Patient.patientPic.smileImage;
          } else {
            this.smileimg = "profile/default-profile.jpg";
          }

          if (res.data.Patient.patientPic.sideImage) {
            this.sideimg = res.data.Patient.patientPic.sideImage;
          } else {
            this.sideimg = "profile/default-profile.jpg";
          }

          if (res.data.Patient.patientPic.optionalImage) {
            this.optimg = res.data.Patient.patientPic.sideImage;
          } else {
            this.optimg = "profile/default-profile.jpg";
          } // console.log(this.smileimg)

        });
      }
    });
  }

  ngOnInit() {}

  heavy() {
    var _this = this;

    return Object(_home_mohammad_Work_RisosFront_Risos_node_modules_angular_devkit_build_angular_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const alert = yield _this.alertcontroller.create({
        cssClass: 'my-custom-class',
        // header: 'Alert',
        // subHeader: 'Subtitle',
        message: 'File is too heavy',
        buttons: [{
          text: 'Try Again!',
          cssClass: 'my-custom-class',
          handler: blah => {}
        }]
      });
      yield alert.present();
    })();
  }

  confirm(e) {
    var _this2 = this;

    return Object(_home_mohammad_Work_RisosFront_Risos_node_modules_angular_devkit_build_angular_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const alert = yield _this2.alertcontroller.create({
        cssClass: 'my-custom-class',
        // header: 'Alert',
        // subHeader: 'Subtitle',
        message: 'Are you sure ?',
        buttons: [{
          text: 'Yes',
          cssClass: 'my-custom-class',
          handler: blah => {
            _this2.delete(e);
          }
        }, {
          text: 'No',
          cssClass: 'my-custom-class',
          handler: blah => {}
        }]
      });
      yield alert.present();
    })();
  } // frontUP(){
  //   console.log("front triggered")
  // }


  fileChangeEvent(event) {
    this.imageChangedEvent = event;
    console.log("here"); // this.imageCropped(event)
  }

  imageCropped(event) {
    console.log(event.file.size);

    if (event.file.size > 4000000) {
      this.heavy();
    } else {
      this.img1 = event.file; // this.base64 = event.base64;
      // this.fullimg = event.base64;

      var my = +this.id;
      this.update_pic.mutate({
        id: my,
        pics: {
          fullSmileImage: this.img1
        }
      }).subscribe(res => {
        console.log(res.data.updatePatientPic.status);
        this.patientgql.watch({
          id: "Patient:" + this.id
        }).valueChanges.subscribe(res => {
          if (res.data.Patient.patientPic.fullSmileImage) {
            this.fullimg = res.data.Patient.patientPic.fullSmileImage;
          } else {
            this.fullimg = "profile/default-profile.jpg";
          } // console.log(this.smileimg)

        });
      });
    }
  }

  delete(e) {
    console.log("delete", this.id);
    var my = +this.id; // console.log(e)

    if (e == 1) {
      this.delpic.mutate({
        id: my,
        selectedFields: {
          fullSmileImage: true
        }
      }).subscribe(res => {
        console.log("fullsmile img", res.data.deletePatientPic.status);
        this.patientgql.watch({
          id: "Patient:" + this.id
        }).valueChanges.subscribe(res => {
          if (res.data.Patient.patientPic.fullSmileImage) {
            this.fullimg = res.data.Patient.patientPic.fullSmileImage;
          } else {
            this.fullimg = "profile/default-profile.jpg";
          }

          if (res.data.Patient.patientPic.smileImage) {
            this.smileimg = res.data.Patient.patientPic.smileImage;
          } else {
            this.smileimg = "profile/default-profile.jpg";
          }

          if (res.data.Patient.patientPic.sideImage) {
            this.sideimg = res.data.Patient.patientPic.sideImage;
          } else {
            this.sideimg = "profile/default-profile.jpg";
          }

          if (res.data.Patient.patientPic.optionalImage) {
            this.optimg = res.data.Patient.patientPic.sideImage;
          } else {
            this.optimg = "profile/default-profile.jpg";
          } // console.log(this.smileimg)

        });
      });
    }

    if (e == 2) {
      this.delpic.mutate({
        id: my,
        selectedFields: {
          smileImage: true
        }
      }).subscribe(res => {
        console.log("smile img", res.data.deletePatientPic.status);
        this.patientgql.watch({
          id: "Patient:" + this.id
        }).valueChanges.subscribe(res => {
          if (res.data.Patient.patientPic.fullSmileImage) {
            this.fullimg = res.data.Patient.patientPic.fullSmileImage;
          } else {
            this.fullimg = "profile/default-profile.jpg";
          }

          if (res.data.Patient.patientPic.smileImage) {
            this.smileimg = res.data.Patient.patientPic.smileImage;
          } else {
            this.smileimg = "profile/default-profile.jpg";
          }

          if (res.data.Patient.patientPic.sideImage) {
            this.sideimg = res.data.Patient.patientPic.sideImage;
          } else {
            this.sideimg = "profile/default-profile.jpg";
          }

          if (res.data.Patient.patientPic.optionalImage) {
            this.optimg = res.data.Patient.patientPic.sideImage;
          } else {
            this.optimg = "profile/default-profile.jpg";
          } // console.log(this.smileimg)

        });
      });
    }

    if (e == 3) {
      this.delpic.mutate({
        id: my,
        selectedFields: {
          sideImage: true
        }
      }).subscribe(res => {
        console.log("side img", res.data.deletePatientPic.status);
        this.patientgql.watch({
          id: "Patient:" + this.id
        }).valueChanges.subscribe(res => {
          if (res.data.Patient.patientPic.fullSmileImage) {
            this.fullimg = res.data.Patient.patientPic.fullSmileImage;
          } else {
            this.fullimg = "profile/default-profile.jpg";
          }

          if (res.data.Patient.patientPic.smileImage) {
            this.smileimg = res.data.Patient.patientPic.smileImage;
          } else {
            this.smileimg = "profile/default-profile.jpg";
          }

          if (res.data.Patient.patientPic.sideImage) {
            this.sideimg = res.data.Patient.patientPic.sideImage;
          } else {
            this.sideimg = "profile/default-profile.jpg";
          }

          if (res.data.Patient.patientPic.optionalImage) {
            this.optimg = res.data.Patient.patientPic.sideImage;
          } else {
            this.optimg = "profile/default-profile.jpg";
          } // console.log(this.smileimg)

        });
      });
    }

    if (e == 4) {
      this.delpic.mutate({
        id: my,
        selectedFields: {
          optionalImage: true
        }
      }).subscribe(res => {
        console.log("opt img", res.data.deletePatientPic.status);
        this.patientgql.watch({
          id: "Patient:" + this.id
        }).valueChanges.subscribe(res => {
          if (res.data.Patient.patientPic.fullSmileImage) {
            this.fullimg = res.data.Patient.patientPic.fullSmileImage;
          } else {
            this.fullimg = "profile/default-profile.jpg";
          }

          if (res.data.Patient.patientPic.smileImage) {
            this.smileimg = res.data.Patient.patientPic.smileImage;
          } else {
            this.smileimg = "profile/default-profile.jpg";
          }

          if (res.data.Patient.patientPic.sideImage) {
            this.sideimg = res.data.Patient.patientPic.sideImage;
          } else {
            this.sideimg = "profile/default-profile.jpg";
          }

          if (res.data.Patient.patientPic.optionalImage) {
            this.optimg = res.data.Patient.patientPic.sideImage;
          } else {
            this.optimg = "profile/default-profile.jpg";
          } // console.log(this.smileimg)

        });
      });
    }
  }

  fileChangeEvent2(event) {
    // console.log('hi');
    this.imageChangedEvent2 = event;
  }

  imageCropped2(event) {
    console.log(event.file.size);

    if (event.file.size > 4000000) {
      this.heavy();
    } else {
      this.img2 = event.file; // this.base64 = event.base64;
      // this.fullimg = event.base64;

      var my = +this.id;
      this.update_pic.mutate({
        id: my,
        pics: {
          smileImage: this.img2
        }
      }).subscribe(res => {
        console.log(res.data.updatePatientPic.status);
        this.patientgql.watch({
          id: "Patient:" + this.id
        }).valueChanges.subscribe(res => {
          if (res.data.Patient.patientPic.smileImage) {
            this.smileimg = res.data.Patient.patientPic.smileImage;
          } else {
            this.smileimg = "profile/default-profile.jpg";
          } // console.log(this.smileimg)

        });
      });
    }
  }

  fileChangeEvent3(event) {
    // console.log('hi');
    this.imageChangedEvent3 = event;
  }

  imageCropped3(event) {
    console.log(event.file.size);

    if (event.file.size > 4000000) {
      this.heavy();
    } else {
      this.img3 = event.file; // this.base64 = event.base64;
      // this.fullimg = event.base64;

      var my = +this.id;
      this.update_pic.mutate({
        id: my,
        pics: {
          sideImage: this.img3
        }
      }).subscribe(res => {
        console.log(res.data.updatePatientPic.status);
        this.patientgql.watch({
          id: "Patient:" + this.id
        }).valueChanges.subscribe(res => {
          if (res.data.Patient.patientPic.smileImage) {
            this.sideimg = res.data.Patient.patientPic.sideImage;
          } else {
            this.sideimg = "profile/default-profile.jpg";
          } // console.log(this.smileimg)

        });
      });
    }
  }

  fileChangeEvent4(event) {
    // console.log('hi');
    this.imageChangedEvent4 = event;
  }

  imageCropped4(event) {
    console.log(event.file.size);

    if (event.file.size > 4000000) {
      this.heavy();
    } else {
      this.img4 = event.file; // this.base64 = event.base64;
      // this.fullimg = event.base64;

      var my = +this.id;
      this.update_pic.mutate({
        id: my,
        pics: {
          optionalImage: this.img4
        }
      }).subscribe(res => {
        console.log(res.data.updatePatientPic.status);
        this.patientgql.watch({
          id: "Patient:" + this.id
        }).valueChanges.subscribe(res => {
          if (res.data.Patient.patientPic.smileImage) {
            this.optimg = res.data.Patient.patientPic.optionalImage;
          } else {
            this.optimg = "profile/default-profile.jpg";
          } // console.log(this.smileimg)

        });
      });
    }
  }

}

GalleryPage.ɵfac = function GalleryPage_Factory(t) {
  return new (t || GalleryPage)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_generated_graphql__WEBPACK_IMPORTED_MODULE_2__["Update_PicGQL"]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_generated_graphql__WEBPACK_IMPORTED_MODULE_2__["DelpatientpicGQL"]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_generated_graphql__WEBPACK_IMPORTED_MODULE_2__["PatientGQL"]));
};

GalleryPage.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
  type: GalleryPage,
  selectors: [["app-gallery"]],
  decls: 64,
  vars: 14,
  consts: [["translate", "", 1, "ion-text-center", 2, "color", "white"], [1, "ion-padding"], ["size", "6", 1, "ion-text-center"], ["id", "getFile", "type", "file", "accept", "image/png, image/jpg, image/jpeg", 2, "display", "none", 3, "change"], ["onclick", "document.getElementById('getFile').click()", 2, "height", "20vh", 3, "src"], [3, "imageChanedEvent", "viewMode", "imageCropped"], [1, "my_Overlay"], ["translate", ""], ["translate", "", 2, "color", "red", 3, "click"], ["id", "getFile2", "type", "file", "accept", "image/png, image/jpg, image/jpeg", 2, "display", "none", 3, "change"], ["onclick", "document.getElementById('getFile2').click()", 2, "height", "20vh", 3, "src"], ["id", "getFile3", "type", "file", "accept", "image/png, image/jpg, image/jpeg", 2, "display", "none", 3, "change"], ["onclick", "document.getElementById('getFile3').click()", 2, "height", "20vh", 3, "src"], ["id", "getFile4", "type", "file", "accept", "image/png, image/jpg, image/jpeg", 2, "display", "none", 3, "change"], ["onclick", "document.getElementById('getFile4').click()", 2, "height", "20vh", 3, "src"], ["translate", "", 2, "margin-bottom", "-1em"], [2, "height", "20vh", 3, "src"]],
  template: function GalleryPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "ion-header");
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "ion-toolbar");
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](2, "ion-title", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](3, "Gallery");
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](4, "ion-content");
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "ion-row", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](6, "ion-col", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](7, "ion-slide");
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](8, "input", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("change", function GalleryPage_Template_input_change_8_listener($event) {
        return ctx.fileChangeEvent($event);
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](9, "img", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](10, "ngx-photo-editor", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("imageCropped", function GalleryPage_Template_ngx_photo_editor_imageCropped_10_listener($event) {
        return ctx.imageCropped($event);
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](11, "div", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](12, "ion-label", 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](13, " Frontal Image");
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](14, "br");
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](15, "ion-label", 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function GalleryPage_Template_ion_label_click_15_listener() {
        return ctx.confirm(1);
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](16, "Delete");
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](17, "ion-col", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](18, "ion-slide");
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](19, "input", 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("change", function GalleryPage_Template_input_change_19_listener($event) {
        return ctx.fileChangeEvent2($event);
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](20, "img", 10);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](21, "ngx-photo-editor", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("imageCropped", function GalleryPage_Template_ngx_photo_editor_imageCropped_21_listener($event) {
        return ctx.imageCropped2($event);
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](22, "div", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](23, "ion-label", 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](24, " Smile Image");
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](25, "br");
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](26, "ion-label", 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function GalleryPage_Template_ion_label_click_26_listener() {
        return ctx.confirm(2);
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](27, "Delete");
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](28, "ion-row", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](29, "ion-col", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](30, "ion-slide");
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](31, "input", 11);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("change", function GalleryPage_Template_input_change_31_listener($event) {
        return ctx.fileChangeEvent3($event);
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](32, "img", 12);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](33, "ngx-photo-editor", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("imageCropped", function GalleryPage_Template_ngx_photo_editor_imageCropped_33_listener($event) {
        return ctx.imageCropped3($event);
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](34, "div", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](35, "ion-label", 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](36, " Side Image");
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](37, "br");
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](38, "ion-label", 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function GalleryPage_Template_ion_label_click_38_listener() {
        return ctx.confirm(3);
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](39, "Delete");
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](40, "ion-col", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](41, "ion-slide");
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](42, "input", 13);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("change", function GalleryPage_Template_input_change_42_listener($event) {
        return ctx.fileChangeEvent4($event);
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](43, "img", 14);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](44, "ngx-photo-editor", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("imageCropped", function GalleryPage_Template_ngx_photo_editor_imageCropped_44_listener($event) {
        return ctx.imageCropped4($event);
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](45, "div", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](46, "ion-label", 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](47, " Optional Image");
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](48, "br");
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](49, "ion-label", 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function GalleryPage_Template_ion_label_click_49_listener() {
        return ctx.confirm(4);
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](50, "Delete");
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](51, "ion-row", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](52, "ion-col", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](53, "ion-slide");
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](54, "img", 12);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](55, "div", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](56, "ion-label", 15);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](57, " Smile Design 1");
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](58, "ion-col", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](59, "ion-slide");
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](60, "img", 16);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](61, "div", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](62, "ion-label", 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](63, " Smile Design 2");
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](9);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpropertyInterpolate1"]("src", "https://api.risos.ir/mediafiles/", ctx.fullimg, "", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsanitizeUrl"]);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("imageChanedEvent", ctx.imageChangedEvent)("viewMode", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](10);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpropertyInterpolate1"]("src", "https://api.risos.ir/mediafiles/", ctx.smileimg, "", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsanitizeUrl"]);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("imageChanedEvent", ctx.imageChangedEvent2)("viewMode", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](11);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpropertyInterpolate1"]("src", "https://api.risos.ir/mediafiles/", ctx.sideimg, "", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsanitizeUrl"]);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("imageChanedEvent", ctx.imageChangedEvent3)("viewMode", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](10);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpropertyInterpolate1"]("src", "https://api.risos.ir/mediafiles/", ctx.optimg, "", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsanitizeUrl"]);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("imageChanedEvent", ctx.imageChangedEvent4)("viewMode", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](10);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpropertyInterpolate1"]("src", "https://api.risos.ir/mediafiles/", ctx.sideimg, "", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsanitizeUrl"]);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](6);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpropertyInterpolate1"]("src", "https://api.risos.ir/mediafiles/", ctx.optimg, "", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsanitizeUrl"]);
    }
  },
  directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonHeader"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonToolbar"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonTitle"], _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__["TranslateDirective"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonContent"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonRow"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonCol"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonSlide"], ngx_photo_editor__WEBPACK_IMPORTED_MODULE_6__["NgxPhotoEditorComponent"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonLabel"]],
  styles: ["ion-toolbar[_ngcontent-%COMP%] {\n  --background:#0000ff;\n}\n\nion-content[_ngcontent-%COMP%] {\n  --background:#f2f2f7;\n}\n\nion-button[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 2em;\n  font-size: 1.2em;\n  border-radius: 20px 20px 20px 20px;\n  border: 1px solid #e5e5ea;\n  box-shadow: 0px 1px 2px #000000;\n}\n\n.my_Overlay[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 30%;\n  text-align: center;\n  position: absolute;\n  z-index: 99;\n  bottom: 30%;\n  top: 70%;\n  opacity: 1;\n  color: black;\n  font-weight: bold;\n  background-color: white;\n  border-radius: 0px 0px 0px 0px;\n  font-size: 0.8em;\n  margin-bottom: 0;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uL2dhbGxlcnkucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0Usb0JBQUE7QUFDRjs7QUFFQTtFQUNFLG9CQUFBO0FBQ0Y7O0FBR0E7RUFDRSxXQUFBO0VBQ0EsV0FBQTtFQUNBLGdCQUFBO0VBQ0Esa0NBQUE7RUFDQSx5QkFBQTtFQUNBLCtCQUFBO0FBQUY7O0FBR0E7RUFDRSxXQUFBO0VBQ0EsV0FBQTtFQUVBLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EsV0FBQTtFQUNBLFFBQUE7RUFDQSxVQUFBO0VBQ0EsWUFBQTtFQUNBLGlCQUFBO0VBQ0EsdUJBQUE7RUFDQSw4QkFBQTtFQUNBLGdCQUFBO0VBRUEsZ0JBQUE7QUFGRiIsImZpbGUiOiJnYWxsZXJ5LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi10b29sYmFye1xuICAtLWJhY2tncm91bmQ6IzAwMDBmZjtcbn1cblxuaW9uLWNvbnRlbnR7XG4gIC0tYmFja2dyb3VuZDojZjJmMmY3O1xufVxuXG5cbmlvbi1idXR0b257XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6MmVtO1xuICBmb250LXNpemU6IDEuMmVtO1xuICBib3JkZXItcmFkaXVzOiAyMHB4IDIwcHggMjBweCAyMHB4O1xuICBib3JkZXI6MXB4IHNvbGlkICNlNWU1ZWE7XG4gIGJveC1zaGFkb3c6IDBweCAxcHggMnB4ICMwMDAwMDA7XG59XG5cbi5teV9PdmVybGF5e1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiAzMCU7XG4gIC8vIHBhZGRpbmctdG9wOjUlO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgei1pbmRleDogOTk7XG4gIGJvdHRvbTogMzAlO1xuICB0b3A6NzAlO1xuICBvcGFjaXR5OiAxO1xuICBjb2xvcjogYmxhY2s7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcbiAgYm9yZGVyLXJhZGl1czogMHB4IDBweCAwcHggMHB4O1xuICBmb250LXNpemU6IDAuOGVtO1xuICAvLyBiYWNrZHJvcC1maWx0ZXI6IHBlcmNlbnRhZ2UoJG51bWJlcjogNTApO1xuICBtYXJnaW4tYm90dG9tOiAwO1xufVxuIl19 */"]
});

/***/ })

}]);
//# sourceMappingURL=gallery-gallery-module.js.map