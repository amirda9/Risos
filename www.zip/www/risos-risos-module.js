(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["risos-risos-module"],{

/***/ "Rh6K":
/*!***********************************************!*\
  !*** ./src/app/risos/risos-routing.module.ts ***!
  \***********************************************/
/*! exports provided: RisosPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RisosPageRoutingModule", function() { return RisosPageRoutingModule; });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _risos_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./risos.page */ "idLi");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");




const routes = [
    {
        path: '',
        component: _risos_page__WEBPACK_IMPORTED_MODULE_1__["RisosPage"]
    }
];
class RisosPageRoutingModule {
}
RisosPageRoutingModule.ɵfac = function RisosPageRoutingModule_Factory(t) { return new (t || RisosPageRoutingModule)(); };
RisosPageRoutingModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineNgModule"]({ type: RisosPageRoutingModule });
RisosPageRoutingModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({ imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"].forChild(routes)], _angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsetNgModuleScope"](RisosPageRoutingModule, { imports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]], exports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]] }); })();


/***/ }),

/***/ "gJKh":
/*!***************************************!*\
  !*** ./src/app/risos/risos.module.ts ***!
  \***************************************/
/*! exports provided: RisosPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RisosPageModule", function() { return RisosPageModule; });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _risos_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./risos-routing.module */ "Rh6K");
/* harmony import */ var _risos_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./risos.page */ "idLi");
/* harmony import */ var _shared_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../shared.module */ "d2mR");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ "fXoL");







class RisosPageModule {
}
RisosPageModule.ɵfac = function RisosPageModule_Factory(t) { return new (t || RisosPageModule)(); };
RisosPageModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineNgModule"]({ type: RisosPageModule });
RisosPageModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineInjector"]({ imports: [[
            _angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["IonicModule"],
            _risos_routing_module__WEBPACK_IMPORTED_MODULE_3__["RisosPageRoutingModule"],
            _shared_module__WEBPACK_IMPORTED_MODULE_5__["SharedModule"]
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵsetNgModuleScope"](RisosPageModule, { declarations: [_risos_page__WEBPACK_IMPORTED_MODULE_4__["RisosPage"]], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"],
        _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormsModule"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["IonicModule"],
        _risos_routing_module__WEBPACK_IMPORTED_MODULE_3__["RisosPageRoutingModule"],
        _shared_module__WEBPACK_IMPORTED_MODULE_5__["SharedModule"]] }); })();


/***/ }),

/***/ "idLi":
/*!*************************************!*\
  !*** ./src/app/risos/risos.page.ts ***!
  \*************************************/
/*! exports provided: RisosPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RisosPage", function() { return RisosPage; });
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../constants */ "l207");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var src_generated_graphql__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/generated/graphql */ "FJRG");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");





class RisosPage {
    constructor(renderer, route, router, patientgql, servicegql) {
        this.renderer = renderer;
        this.route = route;
        this.router = router;
        this.patientgql = patientgql;
        this.servicegql = servicegql;
        this.rec = document.getElementById('rec');
        this.image = document.getElementById('image');
        this.drag = false;
        this.route.queryParams.subscribe(params => {
            if (this.router.getCurrentNavigation().extras.state) {
                this._id = this.router.getCurrentNavigation().extras.state._id;
                // console.log("smile _id")
                // console.log(this._id);
            }
        });
    }
    ngOnInit() {
        var myid = "Patient:" + this._id;
        // console.log(id)
        this.patientgql.watch({
            id: myid
        }).valueChanges.subscribe(res => {
            this.smileImage = res.data.Patient.patientPic.smileImage;
            console.log(this.smileImage);
        });
        var image = document.getElementById('image');
        image.style.background = 'http://37.152.185.177:8000/mediafiles/IMG_6031_eueyw3O.jpeg';
        var rec = document.getElementById('rec');
        var rec2 = document.getElementById('rec2');
        // var rec3 = document.getElementById('rec3');
        var dr;
        var dr2;
        // var dr3: boolean ;
        // var dragStart;
        // var dragEnd;
        var rec_tr = document.getElementById('rec_tr');
        var rec_tl = document.getElementById('rec_tl');
        var rec_bl = document.getElementById('rec_bl');
        var rec_br = document.getElementById('rec_br');
        var resize = false;
        var pos1;
        var pos2;
        var pos3;
        var pos4;
        var pos12;
        var pos22;
        var pos32;
        var pos42;
        rec.addEventListener('mousedown', function (event) {
            console.log("down");
            event.preventDefault();
            dr = true;
            pos3 = rec.offsetLeft - event.clientX;
            pos4 = rec.offsetTop - event.clientY;
            // document.appendChild(rec)
        });
        rec.addEventListener('touchstart', function (event) {
            console.log("down");
            event.preventDefault();
            dr = true;
            pos3 = rec.offsetLeft - event.changedTouches[0].clientX;
            pos4 = rec.offsetTop - event.changedTouches[0].clientY;
            // document.appendChild(rec)
        });
        // rec2.addEventListener('mousedown', function (event) {
        //   console.log("down2");
        //   event.preventDefault();
        //   dr2 = true;
        //   pos32 = rec2.offsetLeft- event.clientX;
        //   pos42 = rec2.offsetTop - event.clientY;
        // });
        // rec3.addEventListener('mousedown', function (event) {
        //   console.log("down3");
        //   var off_l = document.getElementById("rec3").offsetLeft;
        //   var off_t = document.getElementById("rec3").offsetTop;
        //   dr3 = true;
        // });
        rec_tr.addEventListener('mousedown', function (event) {
            resize = true;
            event.preventDefault();
            window.addEventListener('mousemove', resize_f);
            window.addEventListener('mouseup', stopResize);
            // console.log("tr is clicked")
        });
        rec_tr.addEventListener('touchstart', function (event) {
            resize = true;
            console.log("tr touched");
            // event.changedTouches[0].pa
            event.preventDefault();
            window.addEventListener('touchmove', resize_ft);
            window.addEventListener('touchend', stopResizet);
            // console.log("tr is clicked")
        });
        rec_tl.addEventListener('mousedown', function (event) {
            resize = true;
            event.preventDefault();
            window.addEventListener('mousemove', resize_tl);
            window.addEventListener('mouseup', stopResize_tl);
            // console.log("tr is clicked")
        });
        rec_tl.addEventListener('touchstart', function (event) {
            resize = true;
            event.preventDefault();
            window.addEventListener('touchmove', resize_tlt);
            window.addEventListener('touchend', stopResize_tlt);
            // console.log("tr is clicked")
        });
        rec_bl.addEventListener('mousedown', function (event) {
            // resize=true;
            // event.preventDefault()
            window.addEventListener('mousemove', resize_bl);
            window.addEventListener('mouseup', stopResize_bl);
            // console.log("tr is clicked")
        });
        rec_bl.addEventListener('touchstart', function (event) {
            resize = true;
            event.preventDefault();
            window.addEventListener('touchmove', resize_blt);
            window.addEventListener('touchend', stopResize_blt);
            // console.log("tr is clicked")
        });
        rec_br.addEventListener('mousedown', function (event) {
            resize = true;
            event.preventDefault();
            window.addEventListener('mousemove', resize_br);
            window.addEventListener('mouseup', stopResize_br);
            // console.log("tr is clicked")
        });
        rec_br.addEventListener('touchstart', function (event) {
            resize = true;
            event.preventDefault();
            window.addEventListener('touchmove', resize_brt);
            window.addEventListener('touchend', stopResize_brt);
            // console.log("tr is clicked")
        });
        function resize_f(e) {
            if (resize) {
                rec.style.width = e.pageX - rec.getBoundingClientRect().left + 'px';
                rec.style.height = e.pageY - rec.getBoundingClientRect().top + 'px';
            }
        }
        function resize_ft(e) {
            if (resize) {
                rec.style.width = e.changedTouches[0].pageX - rec.getBoundingClientRect().left + 'px';
                rec.style.height = e.changedTouches[0].pageY - rec.getBoundingClientRect().top + 'px';
            }
        }
        function resize_tl(e) {
            if (resize) {
                rec.style.width = e.pageX - rec.getBoundingClientRect().left + 'px';
                rec.style.height = e.pageY - rec.getBoundingClientRect().top + 'px';
            }
        }
        function resize_tlt(e) {
            if (resize) {
                rec.style.width = e.changedTouches[0].pageX - rec.getBoundingClientRect().left + 'px';
                rec.style.height = e.changedTouches[0].pageY - rec.getBoundingClientRect().top + 'px';
            }
        }
        function resize_bl(e) {
            if (resize) {
                rec.style.width = e.pageX - rec.getBoundingClientRect().left + 'px';
                rec.style.height = e.pageY - rec.getBoundingClientRect().top + 'px';
            }
        }
        function resize_blt(e) {
            if (resize) {
                rec.style.width = e.changedTouches[0].pageX - rec.getBoundingClientRect().left + 'px';
                rec.style.height = e.changedTouches[0].pageY - rec.getBoundingClientRect().top + 'px';
            }
        }
        function resize_br(e) {
            if (resize) {
                rec.style.width = e.pageX - rec.getBoundingClientRect().left + 'px';
                rec.style.height = e.pageY - rec.getBoundingClientRect().top + 'px';
            }
        }
        function resize_brt(e) {
            if (resize) {
                rec.style.width = e.changedTouches[0].pageX - rec.getBoundingClientRect().left + 'px';
                rec.style.height = e.changedTouches[0].pageY - rec.getBoundingClientRect().top + 'px';
            }
        }
        function stopResize() {
            window.removeEventListener('mousemove', resize_f);
            resize = false;
        }
        function stopResizet() {
            window.removeEventListener('mousemove', resize_ft);
            resize = false;
        }
        function stopResize_tl() {
            window.removeEventListener('mousemove', resize_tl);
            resize = false;
        }
        function stopResize_tlt() {
            window.removeEventListener('mousemove', resize_tlt);
            resize = false;
        }
        function stopResize_bl() {
            window.removeEventListener('mousemove', resize_bl);
            resize = false;
        }
        function stopResize_blt() {
            window.removeEventListener('mousemove', resize_blt);
            resize = false;
        }
        function stopResize_br() {
            window.removeEventListener('mousemove', resize_br);
            resize = false;
        }
        function stopResize_brt() {
            window.removeEventListener('mousemove', resize_brt);
            resize = false;
        }
        // rec_tr.addEventListener('mousemove', function (event) {
        //   // dr=false;
        //   // console.log("tr_move")
        // });
        // rec_tr.addEventListener('mouseup', function (event) {
        //   resize = false;
        //   // console.log(tr)
        // });
        rec.addEventListener('mousemove', function (event) {
            // console.log("moving")
            // event = event || window.event;
            console.log(dr && !resize);
            event.preventDefault();
            if (dr && !resize) {
                // rec.style.left = event.pageX - rec.offsetWidth / 2 + 'px';
                // rec.style.top = event.pageY - rec.offsetHeight / 2 + 'px';
                pos1 = pos3 - event.clientX;
                pos2 = pos4 - event.clientY;
                rec.style.left = (event.clientX + pos3) + "px";
                rec.style.top = (event.clientY + pos4) + "px";
            }
        });
        rec.addEventListener('touchmove', function (event) {
            // console.log("moving")
            // event = event || window.event;
            console.log(dr && !resize);
            event.preventDefault();
            if (dr && !resize) {
                // rec.style.left = event.pageX - rec.offsetWidth / 2 + 'px';
                // rec.style.top = event.pageY - rec.offsetHeight / 2 + 'px';
                pos1 = pos3 - event.changedTouches[0].clientX;
                pos2 = pos4 - event.changedTouches[0].clientY;
                rec.style.left = (event.changedTouches[0].clientX + pos3) + "px";
                rec.style.top = (event.changedTouches[0].clientY + pos4) + "px";
            }
        });
        rec.addEventListener('mouseout', function (event) {
            dr = false;
        });
        rec.addEventListener('touchend', function (event) {
            dr = false;
        });
        // rec2.addEventListener('mouseout', function (event) {
        //   dr2 = false;
        // });
        // rec3.addEventListener('mouseout', function (event) {
        //   dr3 = false;
        // });
        // rec4.addEventListener('mouseout', function (event) {
        //   dr4 = false;
        // });
        // rec2.addEventListener('mousemove', function (event){
        //   // console.log("moving2")
        //   // event = event || window.event;
        //   event.preventDefault();
        //   if (dr2) {
        //     // rec.style.left = event.pageX - rec.offsetWidth / 2 + 'px';
        //     // rec.style.top = event.pageY - rec.offsetHeight / 2 + 'px';
        //     pos12 = pos32 - event.clientX;
        //     pos22 = pos42 - event.clientY;
        //     rec2.style.left = (event.clientX + pos32) + "px";
        //     rec2.style.top = (event.clientY + pos42) + "px";
        //   }
        // });
        // rec3.addEventListener('mousemove', function (event) {
        //   // console.log(event.pageY - rec.offsetHeight / 2 + 'px)
        //   // console.log((event.pageY - rec.offsetHeight / 2 + 'px'))
        //     if(dr3){
        //     // console.log("here" , rec.style.left);
        //     var off_l = document.getElementById("rec3").offsetLeft;
        //     var off_t = document.getElementById("rec3").offsetTop;
        //     // dragEnd = {
        //     //   x: event.pageX - off_l,
        //     //   y: event.pageY - off_t
        //     // }
        //     rec3.style.left = event.pageX - rec3.offsetWidth / 2 + 'px';
        //     rec3.style.top = event.pageY - rec3.offsetHeight / 2 + 'px';
        //     // drag = false;
        //   }
        // });
        rec.addEventListener('mouseup', function (event) {
            dr = false;
            console.log("mouseup");
        });
        // rec2.addEventListener('mouseup', function (event){
        //   dr2= false;
        //   console.log("mouseup")
        //  });
        //  rec3.addEventListener('mouseup', function (event) {
        //   dr3 = false;
        //   console.log("mouseup");
        // });
    }
    mousedown(event) {
        console.log("mousedown");
        this.drag = true;
        var rec = document.getElementById('rec');
        rec.style.position = 'absolute';
        rec.style.zIndex = "1000";
        document.body.append(this.rec);
        // centers the ball at (pageX, pageY) coordinates
        // move our absolutely positioned ball under the pointer
        // this.moveAt(event.pageX, event.pageY);
        // (2) move the ball on mousemove
        // rec.addEventListener('mousemove', this.onMouseMove);
        // (3) drop the ball, remove unneeded handlers
        // rec.onmouseup = function() {
        //   document.removeEventListener('mousemove', onmousemove);
        //   rec.onmouseup = null;
        // };;
    }
    evaluate() {
        var rec = document.getElementById('rec');
        rec.style.background = "none";
        rec.style.backgroundImage = "url('http://37.152.185.177:8000/mediafiles/profile/teeth.png')";
        rec.style.opacity = "0.9";
        rec.style.backgroundSize = "cover";
        rec.style.backgroundRepeat = "no-repeat";
        // rec.style.height = "100%";
        // rec.style.width = "100%";
    }
    fullwhite() {
        const mask = document.getElementById('rec');
        this.renderer.setStyle(mask, 'filter', `invert(100%) sepia(100%) saturate(0%) hue-rotate(206deg) brightness(103%) contrast(101%)`);
        // mask.style.filter = invert(99%) sepia(1%) saturate(6054%) hue-rotate(265deg) brightness(128%) contrast(94%);
    }
    white() {
        const mask = document.getElementById('rec');
        this.renderer.setStyle(mask, 'filter', `invert(98%) sepia(0%) saturate(0%) hue-rotate(180deg) brightness(93%) contrast(91%)`);
        // mask.style.filter = invert(99%) sepia(1%) saturate(6054%) hue-rotate(265deg) brightness(128%) contrast(94%);
    }
    finish() {
        console.log("go");
        console.log(this._id);
        this.servicegql.mutate({
            p_id: "3",
            d_id: localStorage.getItem(_constants__WEBPACK_IMPORTED_MODULE_0__["ID"])
        }).subscribe(res => {
            // this.s_id=res.data.createService.service.id;
            // console.log(res.data.createService.service.id);
            this.s_id = res.data.createService.service.id;
            console.log(this.s_id);
            let navigationExtras = {
                state: {
                    s_id: this.s_id
                }
            };
            // console.log(this.s_id);
            this.router.navigate(['/lab-c'], navigationExtras);
        });
    }
    mouseup() {
        // var rec = document.getElementById('rec');
        // document.removeEventListener('mousemove', onmousemove);
        // rec.onmouseup = null;
        this.drag = false;
        console.log("mouseup");
    }
    moveAt(pageX, pageY) {
        var rec = document.getElementById('rec');
        rec.style.left = pageX - rec.offsetWidth / 2 + 'px';
        rec.style.top = pageY - rec.offsetHeight / 2 + 'px';
    }
    onMouseMove(event) {
        console.log("mousemove");
        var rec = document.getElementById('rec');
        if (this.drag) {
            // this.moveAt(event.pageX, event.pageY);
            rec.style.left = event.pageX - rec.offsetWidth / 2 + 'px';
            rec.style.top = event.pageY - rec.offsetHeight / 2 + 'px';
        }
    }
}
RisosPage.ɵfac = function RisosPage_Factory(t) { return new (t || RisosPage)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer2"]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_generated_graphql__WEBPACK_IMPORTED_MODULE_3__["PatientGQL"]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_generated_graphql__WEBPACK_IMPORTED_MODULE_3__["ServiceGQL"])); };
RisosPage.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({ type: RisosPage, selectors: [["app-risos"]], decls: 28, vars: 0, consts: [[1, "ion-text-center", 2, "color", "white"], ["id", "image", 2, "position", "relative"], ["src", "https://api.risos.ir/mediafiles/IMG_6031_eueyw3O.jpeg", 2, "position", "absolute"], ["id", "rec", 1, "rec", 2, "position", "absolute"], [1, "resizers"], ["id", "rec_tl", 1, "resizer", "top-left"], ["id", "rec_tr", 1, "resizer", "top-right"], ["id", "rec_bl", 1, "resizer", "bottom-left"], ["id", "rec_br", 1, "resizer", "bottom-right"], [1, "ion-justify-content-center", "ion-padding", 2, "padding-top", "20em"], ["size", "12", "size-lg", "8", 1, "ion-text-center"], ["shape", "round", 2, "text-transform", "none", "width", "100%", "color", "black", "--background", "#3abff8", "height", "2em", "font-size", "1em", "border-radius", "20px 20px 20px 20px", "border", "1px solid #e5e5ea", "box-shadow", "0px 1px 2px #000000", "font-weight", "lighter", 3, "click"], [3, "click"], [1, "ion-justify-content-center", "ion-padding"]], template: function RisosPage_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "ion-header");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "ion-toolbar");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](2, "ion-title", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](3, "Risos");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](4, "ion-content");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "div", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](6, "img", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](7, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](8, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](9, "div", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](10, "div", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](11, "div", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](12, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](13, "ion-row", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](14, "ion-col", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](15, "ion-button", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function RisosPage_Template_ion_button_click_15_listener() { return ctx.evaluate(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](16, " Evaluate ");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](17, "ion-row");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](18, "ion-col");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](19, "ion-segment");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](20, "ion-segment-button", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function RisosPage_Template_ion_segment_button_click_20_listener() { return ctx.fullwhite(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](21, "Fashion");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](22, "ion-segment-button", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function RisosPage_Template_ion_segment_button_click_22_listener() { return ctx.white(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](23, "Natural");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](24, "ion-row", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](25, "ion-col", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](26, "ion-button", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function RisosPage_Template_ion_button_click_26_listener() { return ctx.finish(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](27, " Finish ");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    } }, directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonHeader"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonToolbar"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonTitle"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonContent"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonRow"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonCol"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonButton"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonSegment"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["SelectValueAccessor"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonSegmentButton"]], styles: ["ion-toolbar[_ngcontent-%COMP%] {\n  --background: #0000ff;\n}\n\nion-content[_ngcontent-%COMP%] {\n  --background: #f2f2f7;\n}\n\n.rec[_ngcontent-%COMP%] {\n  background: cyan;\n  width: 5vh;\n  height: 5vh;\n  cursor: move;\n  position: relative;\n  z-index: 1;\n  opacity: 0.5;\n}\n\n.rec[_ngcontent-%COMP%]   .resizers[_ngcontent-%COMP%]   .resizer[_ngcontent-%COMP%] {\n  width: 10px;\n  height: 10px;\n  border-radius: 50%;\n  opacity: 1;\n  background: white;\n  border: 3px solid #4286f4;\n  position: absolute;\n}\n\n.rec[_ngcontent-%COMP%]   .resizers[_ngcontent-%COMP%]   .resizer.top-left[_ngcontent-%COMP%] {\n  left: -5px;\n  top: -5px;\n  cursor: nwse-resize;\n  \n}\n\n.rec[_ngcontent-%COMP%]   .resizers[_ngcontent-%COMP%]   .resizer.top-right[_ngcontent-%COMP%] {\n  right: -5px;\n  top: -5px;\n  cursor: nesw-resize;\n}\n\n.rec[_ngcontent-%COMP%]   .resizers[_ngcontent-%COMP%]   .resizer.bottom-left[_ngcontent-%COMP%] {\n  left: -5px;\n  bottom: -5px;\n  cursor: nesw-resize;\n}\n\n.rec[_ngcontent-%COMP%]   .resizers[_ngcontent-%COMP%]   .resizer.bottom-right[_ngcontent-%COMP%] {\n  right: -5px;\n  bottom: -5px;\n  cursor: nwse-resize;\n}\n\n.example-box[_ngcontent-%COMP%] {\n  background: cyan;\n  cursor: move;\n}\n\n.example-box[_ngcontent-%COMP%]:active {\n  box-shadow: 0 5px 5px -3px rgba(0, 0, 0, 0.2), 0 8px 10px 1px rgba(0, 0, 0, 0.14), 0 3px 14px 2px rgba(0, 0, 0, 0.12);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uL3Jpc29zLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHFCQUFBO0FBQ0Y7O0FBRUE7RUFDRSxxQkFBQTtBQUNGOztBQUVBO0VBQ0UsZ0JBQUE7RUFDQSxVQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLFVBQUE7RUFDQSxZQUFBO0FBQ0Y7O0FBRUE7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsVUFBQTtFQUNBLGlCQUFBO0VBQ0EseUJBQUE7RUFDQSxrQkFBQTtBQUNGOztBQUNBO0VBQ0UsVUFBQTtFQUNBLFNBQUE7RUFDQSxtQkFBQTtFQUFxQixpQkFBQTtBQUd2Qjs7QUFEQTtFQUNFLFdBQUE7RUFDQSxTQUFBO0VBQ0EsbUJBQUE7QUFJRjs7QUFGQTtFQUNFLFVBQUE7RUFDQSxZQUFBO0VBQ0EsbUJBQUE7QUFLRjs7QUFIQTtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0EsbUJBQUE7QUFNRjs7QUFIQTtFQXFCRSxnQkFBQTtFQUNBLFlBQUE7QUFkRjs7QUFpQkE7RUFDRSxxSEFBQTtBQWRGIiwiZmlsZSI6InJpc29zLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi10b29sYmFyIHtcbiAgLS1iYWNrZ3JvdW5kOiAjMDAwMGZmO1xufVxuXG5pb24tY29udGVudCB7XG4gIC0tYmFja2dyb3VuZDogI2YyZjJmNztcbn1cblxuLnJlYyB7XG4gIGJhY2tncm91bmQ6IGN5YW47XG4gIHdpZHRoOiA1dmg7XG4gIGhlaWdodDogNXZoO1xuICBjdXJzb3I6IG1vdmU7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgei1pbmRleDogMTtcbiAgb3BhY2l0eTogMC41O1xufVxuXG4ucmVjIC5yZXNpemVycyAucmVzaXplcntcbiAgd2lkdGg6IDEwcHg7XG4gIGhlaWdodDogMTBweDtcbiAgYm9yZGVyLXJhZGl1czogNTAlO1xuICBvcGFjaXR5OiAxO1xuICBiYWNrZ3JvdW5kOiB3aGl0ZTtcbiAgYm9yZGVyOiAzcHggc29saWQgIzQyODZmNDtcbiAgcG9zaXRpb246IGFic29sdXRlO1xufVxuLnJlYyAucmVzaXplcnMgLnJlc2l6ZXIudG9wLWxlZnQge1xuICBsZWZ0OiAtNXB4O1xuICB0b3A6IC01cHg7XG4gIGN1cnNvcjogbndzZS1yZXNpemU7IC8qcmVzaXplciBjdXJzb3IqL1xufVxuLnJlYyAucmVzaXplcnMgLnJlc2l6ZXIudG9wLXJpZ2h0IHtcbiAgcmlnaHQ6IC01cHg7XG4gIHRvcDogLTVweDtcbiAgY3Vyc29yOiBuZXN3LXJlc2l6ZTtcbn1cbi5yZWMgLnJlc2l6ZXJzIC5yZXNpemVyLmJvdHRvbS1sZWZ0IHtcbiAgbGVmdDogLTVweDtcbiAgYm90dG9tOiAtNXB4O1xuICBjdXJzb3I6IG5lc3ctcmVzaXplO1xufVxuLnJlYyAucmVzaXplcnMgLnJlc2l6ZXIuYm90dG9tLXJpZ2h0IHtcbiAgcmlnaHQ6IC01cHg7XG4gIGJvdHRvbTogLTVweDtcbiAgY3Vyc29yOiBud3NlLXJlc2l6ZTtcbn1cblxuLmV4YW1wbGUtYm94IHtcbiAgLy8gd2lkdGg6IDEwMHB4O1xuICAvLyBoZWlnaHQ6IDEwMHB4O1xuICAvLyBib3JkZXI6IHNvbGlkIDFweCAjY2NjO1xuICAvLyBjb2xvcjogcmdiYSgwLCAwLCAwLCAwLjg3KTtcbiAgLy8gY3Vyc29yOiBtb3ZlO1xuICAvLyAvLyBkaXNwbGF5OiBpbmxpbmUtZmxleDtcbiAgLy8ganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIC8vIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIC8vIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgLy8gYmFja2dyb3VuZDogY3lhbjtcbiAgLy8gLy8gYm9yZGVyLXJhZGl1czogNHB4O1xuICAvLyAvLyBtYXJnaW4tcmlnaHQ6IDI1cHg7XG4gIC8vIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgLy8gei1pbmRleDogMTtcbiAgLy8gLy8gYm94LXNpemluZzogYm9yZGVyLWJveDtcbiAgLy8gLy8gcGFkZGluZzogMTBweDtcbiAgLy8gLy8gdHJhbnNpdGlvbjogYm94LXNoYWRvdyAyMDBtcyBjdWJpYy1iZXppZXIoMCwgMCwgMC4yLCAxKTtcbiAgLy8gYm94LXNoYWRvdzogMCAzcHggMXB4IC0ycHggcmdiYSgwLCAwLCAwLCAwLjIpLFxuICAvLyAgICAgICAgICAgICAwIDJweCAycHggMCByZ2JhKDAsIDAsIDAsIDAuMTQpLFxuICAvLyAgICAgICAgICAgICAwIDFweCA1cHggMCByZ2JhKDAsIDAsIDAsIDAuMTIpO1xuICBiYWNrZ3JvdW5kOiBjeWFuO1xuICBjdXJzb3I6IG1vdmU7XG59XG5cbi5leGFtcGxlLWJveDphY3RpdmUge1xuICBib3gtc2hhZG93OiAwIDVweCA1cHggLTNweCByZ2JhKDAsIDAsIDAsIDAuMiksXG4gICAgMCA4cHggMTBweCAxcHggcmdiYSgwLCAwLCAwLCAwLjE0KSwgMCAzcHggMTRweCAycHggcmdiYSgwLCAwLCAwLCAwLjEyKTtcbn1cblxuLy8gLmV4YW1wbGUtYm91bmRhcnkge1xuLy8gICB3aWR0aDogNDAwcHg7XG4vLyAgIGhlaWdodDogNDAwcHg7XG4vLyAgIG1heC13aWR0aDogMTAwJTtcbi8vICAgYm9yZGVyOiBkb3R0ZWQgI2NjYyAycHg7XG4vLyB9XG4iXX0= */"] });


/***/ })

}]);
//# sourceMappingURL=risos-risos-module.js.map