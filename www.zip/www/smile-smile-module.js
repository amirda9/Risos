(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["smile-smile-module"],{

/***/ "Jqk/":
/*!***************************************!*\
  !*** ./src/app/smile/smile.module.ts ***!
  \***************************************/
/*! exports provided: SmilePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SmilePageModule", function() { return SmilePageModule; });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _smile_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./smile-routing.module */ "OE31");
/* harmony import */ var _smile_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./smile.page */ "oqbd");
/* harmony import */ var _shared_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../shared.module */ "d2mR");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ "fXoL");







class SmilePageModule {
}
SmilePageModule.ɵfac = function SmilePageModule_Factory(t) { return new (t || SmilePageModule)(); };
SmilePageModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineNgModule"]({ type: SmilePageModule });
SmilePageModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineInjector"]({ imports: [[
            _angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["IonicModule"],
            _smile_routing_module__WEBPACK_IMPORTED_MODULE_3__["SmilePageRoutingModule"],
            _shared_module__WEBPACK_IMPORTED_MODULE_5__["SharedModule"],
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵsetNgModuleScope"](SmilePageModule, { declarations: [_smile_page__WEBPACK_IMPORTED_MODULE_4__["SmilePage"]], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"],
        _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormsModule"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["IonicModule"],
        _smile_routing_module__WEBPACK_IMPORTED_MODULE_3__["SmilePageRoutingModule"],
        _shared_module__WEBPACK_IMPORTED_MODULE_5__["SharedModule"]] }); })();


/***/ }),

/***/ "OE31":
/*!***********************************************!*\
  !*** ./src/app/smile/smile-routing.module.ts ***!
  \***********************************************/
/*! exports provided: SmilePageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SmilePageRoutingModule", function() { return SmilePageRoutingModule; });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _smile_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./smile.page */ "oqbd");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");




const routes = [
    {
        path: '',
        component: _smile_page__WEBPACK_IMPORTED_MODULE_1__["SmilePage"]
    }
];
class SmilePageRoutingModule {
}
SmilePageRoutingModule.ɵfac = function SmilePageRoutingModule_Factory(t) { return new (t || SmilePageRoutingModule)(); };
SmilePageRoutingModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineNgModule"]({ type: SmilePageRoutingModule });
SmilePageRoutingModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({ imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"].forChild(routes)], _angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsetNgModuleScope"](SmilePageRoutingModule, { imports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]], exports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]] }); })();


/***/ }),

/***/ "oqbd":
/*!*************************************!*\
  !*** ./src/app/smile/smile.page.ts ***!
  \*************************************/
/*! exports provided: SmilePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SmilePage", function() { return SmilePage; });
/* harmony import */ var _home_mohammad_Work_RisosFront_Risos_node_modules_angular_devkit_build_angular_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@angular-devkit/build-angular/node_modules/@babel/runtime/helpers/esm/asyncToGenerator */ "20ZU");
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../constants */ "l207");
/* harmony import */ var konva__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! konva */ "Ni3L");
/* harmony import */ var _dentalShades_dentalShades__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./dentalShades/dentalShades */ "3A1g");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngx-translate/core */ "sYmb");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _generated_graphql__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../generated/graphql */ "FJRG");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common */ "ofXK");











function SmilePage_ion_segment_button_11_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "ion-segment-button", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](2, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    const model_r3 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpropertyInterpolate"]("value", model_r3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](2, 2, model_r3), " ");
  }
}

function SmilePage_ion_segment_12_ion_segment_button_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "ion-segment-button", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    const teeth_r5 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpropertyInterpolate"]("value", teeth_r5);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", teeth_r5, " ");
  }
}

function SmilePage_ion_segment_12_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "ion-segment", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("ionChange", function SmilePage_ion_segment_12_Template_ion_segment_ionChange_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r7);
      const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
      return ctx_r6.choseTeethPerModel($event);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "ion-segment-button", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](3, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](4, SmilePage_ion_segment_12_ion_segment_button_4_Template, 2, 2, "ion-segment-button", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpropertyInterpolate"]("value", ctx_r1.chosenTeeth);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](3, 3, ctx_r1.string1), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngForOf", ctx_r1.teethsPerModel);
  }
}

function SmilePage_ion_segment_13_ion_segment_button_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "ion-segment-button", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    const color_r9 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpropertyInterpolate"]("value", color_r9);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", color_r9, " ");
  }
}

function SmilePage_ion_segment_13_Template(rf, ctx) {
  if (rf & 1) {
    const _r11 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "ion-segment", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("ionChange", function SmilePage_ion_segment_13_Template_ion_segment_ionChange_0_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r11);
      const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
      return ctx_r10.choseColor($event);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "ion-segment-button", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](3, "translate");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](4, SmilePage_ion_segment_13_ion_segment_button_4_Template, 2, 2, "ion-segment-button", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpropertyInterpolate"]("value", ctx_r2.chosenColor);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"](" ", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](3, 3, ctx_r2.string2), " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngForOf", ctx_r2.teethColors);
  }
}

class SmilePage {
  constructor(translateserv, loadingController, servicegql, route, router, renderer, smile_design, patientgql) {
    this.translateserv = translateserv;
    this.loadingController = loadingController;
    this.servicegql = servicegql;
    this.route = route;
    this.router = router;
    this.renderer = renderer;
    this.smile_design = smile_design;
    this.patientgql = patientgql;
    this.status = true;
    this.test_img = new Image();
    this.type = 0;
    this.degree = 0;
    this.left = 80;
    this.top = 250;
    this.height = 20;
    this.width = 20;
    this.img = new Image();
    this.isDown = false;
    this.imageObj3 = new Image();
    this.string1 = "all teeth";
    this.string2 = "no color";
  }

  ngOnInit() {
    var imageObj = new Image();

    if (this.router.getCurrentNavigation().extras.state) {
      this.route.queryParams.subscribe(params => {
        if (this.router.getCurrentNavigation().extras.state) {
          this._id = this.router.getCurrentNavigation().extras.state._id;
          this.ratio = this.router.getCurrentNavigation().extras.state.ratio; // console.log("ratio is :" + this.router.getCurrentNavigation().extras.state.ratio)
          // console.log("your id is :" +this._id)

          this.patientgql.watch({
            id: "Patient:" + localStorage.getItem(_constants__WEBPACK_IMPORTED_MODULE_1__["P_ID"])
          }).valueChanges.subscribe(res => {
            this.smileimg = res.data.Patient.patientPic.smileImage; // var file=new Image();
            // file.src = 'https://api.risos.ir/mediafiles/'+String(this.smileimg);
            // reader.readAsDataURL( 'https://api.risos.ir/mediafiles/'+String(this.smileimg) );
            // localStorage.setItem("smileIMG", file.);

            imageObj.src = 'https://api.risos.ir/mediafiles/' + String(this.smileimg); //  this.width__ =  imageObj.naturalWidth;
            //  this.height__ =  imageObj.naturalHeight;
            // imageObj = file;
            //  imageObj.src = "https://api.risos.ir/mediafiles/82_74.png";
            //  imageObj.src = 'https://api.risos.ir/mediafiles/'+String(this.smileimg);

            imageObj.crossOrigin = "anonymous";
          }); // console.log("smile _id")
          // console.log(this._id);
        }
      });
    } else {
      console.log("url is : " + this.route.snapshot.paramMap.get("id"));
      this._id = this.route.snapshot.paramMap.get("id");
      this.ratio = 1;
      this.patientgql.watch({
        id: "Patient:" + localStorage.getItem(_constants__WEBPACK_IMPORTED_MODULE_1__["P_ID"])
      }).valueChanges.subscribe(res => {
        this.smileimg = res.data.Patient.patientPic.smileImage;
        imageObj.src = 'https://api.risos.ir/mediafiles/' + String(this.smileimg);
        imageObj.crossOrigin = "anonymous";
      });
    }

    this.teethModel = Object.keys(_dentalShades_dentalShades__WEBPACK_IMPORTED_MODULE_3__["teethImg"]); // console.log(this.translateserv.currentLang)

    this.teethColors = Object.keys(_dentalShades_dentalShades__WEBPACK_IMPORTED_MODULE_3__["dentalShades"]); // this.teethsPerModel = teethImg["rectangle"];

    var width = 400;
    var height = 600;
    this.teeth = [];
    this.teethKi = [];
    konva__WEBPACK_IMPORTED_MODULE_2__["default"].pixelRatio = 1;
    this.stage = new konva__WEBPACK_IMPORTED_MODULE_2__["default"].Stage({
      container: 'container',
      width: 400,
      height: 400 * this.ratio
    });
    this.teethPositionX = 50;
    this.teethPositionY = 50;
    this.backgroundLayer = new konva__WEBPACK_IMPORTED_MODULE_2__["default"].Layer();
    this.stage.add(this.backgroundLayer); // console.log(this.translateserv.instant(JSON.stringify(this.teethModel)))
    // console.log(this.smileimg + "is ready")
    // main API:

    var yoda = new konva__WEBPACK_IMPORTED_MODULE_2__["default"].Image({
      name: 'person',
      x: 0,
      y: 0,
      image: imageObj,
      width: 400,
      height: 400 * this.ratio,
      draggable: false
    });

    imageObj.onload = () => {
      // add the shape to the layer
      this.backgroundLayer.add(yoda);
      yoda.zIndex(0);
    };

    this.teethLayer = new konva__WEBPACK_IMPORTED_MODULE_2__["default"].Layer();
    this.stage.add(this.teethLayer); // if(this.translateserv.currentLang=="fa"){
    //   this.teethModel = Object.keys(teethImg);
    // }
    // else{
    //   this.teethModel = Object.keys(teethImg);
    // }
    // console.log(this.teethless)
    // this._id = this.router.getCurrentNavigation().extras.state._id;

    this.smile_design.watch({
      d_id: localStorage.getItem(_constants__WEBPACK_IMPORTED_MODULE_1__["ID"]),
      p_id: localStorage.getItem(_constants__WEBPACK_IMPORTED_MODULE_1__["P_ID"])
    }).valueChanges.subscribe(res => {
      console.log(res.data.allSmiledesignservice.edges[0].node.status);
      this.teethless = res.data.allSmiledesignservice.edges[0].node.teethLessImage; // console.log(this.teethless);

      this.imageObj3.src = 'https://api.risos.ir/mediafiles/' + String(this.teethless); // imageObj3.src = "https://api.risos.ir/mediafiles/82_74.png";

      this.imageObj3.crossOrigin = "anonymous";
    });
  }

  result(e) {
    // console.log(this.focus, e.target.value)
    this.focus = e.target.value; // console.log(this.focus, e.target.value)

    let val = e.target.value; // console.log(val)

    let tooths = this.teeth; // console.log("hii")

    this.transform.detach();

    for (let j = 0; j < tooths.length; j++) {
      if (j == val) {
        this.teethKi[j].setAttr("opacity", 1);
        this.transform.nodes([this.teethKi[j]]);
        this.teethKi[j].setAttr("draggable", true);
        this.teethKi[j].zIndex(20);
      } else {
        this.teethKi[j].setAttr("opacity", 0.5);
        this.teethKi[j].setAttr("draggable", false);
        this.teethKi[j].zIndex(2);
      }
    }
  }

  choseTeethModel(ev) {
    var _this = this;

    return Object(_home_mohammad_Work_RisosFront_Risos_node_modules_angular_devkit_build_angular_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      // console.log('Segment changed', ev.detail.value);
      _this.t_model = ev.detail.value;
      console.log("model is :", _this.t_model);

      if (_this.chosenModel != ev.detail.value) {
        _this.chosenTeeth = "0";
        _this.chosenColor = "0";

        if (_this.teethLayer.hasChildren()) {
          _this.teethPositionX = _this.teethLayer.getChildren()[0].getPosition()["x"];
          _this.teethPositionY = _this.teethLayer.getChildren()[0].getPosition()["y"];
        }

        _this.teethLayer.destroyChildren();

        _this.teeth = [];
        _this.teethKi = [];
        _this.chosenModel = ev.detail.value;
        _this.teethsPerModel = _dentalShades_dentalShades__WEBPACK_IMPORTED_MODULE_3__["teethImg"][_this.chosenModel];
        _this.layerCount = 1;
        const loading = yield _this.loadingController.create({
          message: 'Please Wait',
          duration: 2000,
          spinner: 'bubbles'
        });
        yield loading.present();

        _this.teethsPerModel.forEach(value => {
          let tooth = new Image();
          tooth.src = '../assets/' + _this.chosenModel + '/' + value + '.png';
          let toothKI = new konva__WEBPACK_IMPORTED_MODULE_2__["default"].Image({
            name: value,
            x: _this.teethPositionX,
            y: _this.teethPositionY,
            image: tooth,
            draggable: true
          });

          _this.teeth.push(tooth);

          _this.teethKi.push(toothKI);

          tooth.onload = () => {
            // add the shape to the layer
            toothKI.zIndex(_this.layerCount);
            toothKI.width(196);
            toothKI.height(196 / tooth.width * tooth.height);

            _this.teethLayer.add(toothKI);

            _this.layerCount = _this.layerCount + 1; // toothKI.cache();
            // toothKI.filters([Konva.Filters.RGBA]);
            // toothKI.red(dentalShades["A1"].red).blue(dentalShades["A1"].blue).green(dentalShades["A1"].green).alpha(0.4);
          };
        });

        loading.dismiss();
        _this.transform = new konva__WEBPACK_IMPORTED_MODULE_2__["default"].Transformer({
          centeredScaling: true,
          enabledAnchors: ['bottom-right'],
          anchorSize: 15
        });

        _this.teethLayer.add(_this.transform);

        _this.transform.nodes(_this.teethKi);

        _this.transform.zIndex(_this.layerCount);
      }
    })();
  }

  choseTeethPerModel(ev) {
    this.t_model = ev.detail.value;
    console.log(ev.detail.value);

    if (this.chosenTeeth != ev.detail.value) {
      this.chosenTeeth = ev.detail.value;

      if (this.chosenTeeth != "0") {
        this.transform.detach();
        this.chosenTeeth = ev.detail.value;
        this.teethKi.forEach(value => {
          console.log(value.getAttr("name"));

          if (value.getAttr("name") == this.chosenTeeth) {
            // console.log("I am here");
            value.setAttr("opacity", 1);
            this.transform.nodes([value]);
            value.setAttr("draggable", true);
            value.zIndex(this.layerCount - 1);
          } else {
            value.setAttr("opacity", 0.7);
            value.setAttr("draggable", false);
            value.zIndex(2);
          }
        });
      } else {
        this.transform.detach();
        this.layerCount = 1;
        this.teethKi.forEach(value => {
          value.setAttr("opacity", 1);
          value.setAttr("draggable", true);
          value.zIndex(this.layerCount);
          this.layerCount = this.layerCount + 1;
        });
        this.transform.nodes(this.teethKi);
        this.transform.zIndex(this.layerCount);
      }
    }
  }

  choseColor(ev) {
    this.t_color = ev.detail.value;
    console.log(ev.detail.value);

    if (this.chosenColor != ev.detail.value) {
      this.chosenColor = ev.detail.value;

      if (this.chosenColor != "0") {
        this.teethKi.forEach(value => {
          value.cache();
          value.filters([konva__WEBPACK_IMPORTED_MODULE_2__["default"].Filters.RGBA]);
          value.red(_dentalShades_dentalShades__WEBPACK_IMPORTED_MODULE_3__["dentalShades"][this.chosenColor].red).blue(_dentalShades_dentalShades__WEBPACK_IMPORTED_MODULE_3__["dentalShades"][this.chosenColor].blue).green(_dentalShades_dentalShades__WEBPACK_IMPORTED_MODULE_3__["dentalShades"][this.chosenColor].green).alpha(0.4);
        });
      } else {
        this.teethKi.forEach(value => {
          value.clearCache();
          value.filters([]);
        });
      }
    }
  }

  finalize() {
    var _this2 = this;

    return Object(_home_mohammad_Work_RisosFront_Risos_node_modules_angular_devkit_build_angular_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      // const loading = await this.loadingController.create({
      //   message: 'Loading',
      //   spinner: 'bubbles'
      // });
      // await loading.present();
      let tooths = _this2.teeth;
      _this2.status = false;
      console.log(_this2.backgroundLayer.getChildren()[0]);

      _this2.backgroundLayer.getChildren()[0].setAttrs({
        image: _this2.imageObj3,
        zIndex: 3
      });

      for (let j = 0; j < tooths.length; j++) {
        _this2.teethKi[j].setAttr("opacity", 1); // this.teethKi[j].setAttr("draggable", false)


        _this2.teethKi[j].zIndex(1);
      }
    })();
  }

  design() {
    let navigationExtras = {
      state: {
        _id: this._id
      }
    };
    this.router.navigate(['/risos'], navigationExtras);
  }

  circle() {}

  go() {
    // console.log("go")
    // console.log(this._id)
    this.servicegql.mutate({
      p_id: this._id,
      d_id: localStorage.getItem(_constants__WEBPACK_IMPORTED_MODULE_1__["ID"])
    }).subscribe(res => {
      // this.s_id=res.data.createService.service.id;
      // console.log(res.data.createService.service.id);
      this.s_id = res.data.createService.service.id; // console.log(this.s_id)

      let navigationExtras = {
        state: {
          s_id: this.s_id
        }
      }; // console.log(this.s_id);

      this.router.navigate(['/lab-c'], navigationExtras);
    });
  }

  reload() {
    location.reload();
  }

  export() {
    this.backgroundLayer.zIndex(99);
    this.transform.remove(); //TODO: remove teeth from background image and change the z index of the teeth

    var data = this.stage.toDataURL();
    var data = atob(data.substring("data:image/png;base64,".length)),
        asArray = new Uint8Array(data.length);

    for (var i = 0, len = data.length; i < len; ++i) {
      asArray[i] = data.charCodeAt(i);
    }

    var blob = new Blob([asArray.buffer], {
      type: "image/png"
    });
    let navigationExtras = {
      state: {
        image: blob,
        _id: this._id,
        ratio: this.ratio,
        color: this.t_color,
        model: this.t_model
      }
    };
    this.router.navigate(['/comparison'], navigationExtras); // console.log(blob)
  }

}

SmilePage.ɵfac = function SmilePage_Factory(t) {
  return new (t || SmilePage)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__["TranslateService"]), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_6__["LoadingController"]), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_generated_graphql__WEBPACK_IMPORTED_MODULE_7__["ServiceGQL"]), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_8__["ActivatedRoute"]), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_8__["Router"]), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["Renderer2"]), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_generated_graphql__WEBPACK_IMPORTED_MODULE_7__["AllsmileGQL"]), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_generated_graphql__WEBPACK_IMPORTED_MODULE_7__["PatientGQL"]));
};

SmilePage.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({
  type: SmilePage,
  selectors: [["app-smile"]],
  decls: 26,
  vars: 4,
  consts: [["translate", "", 1, "ion-text-center", 2, "color", "white"], ["scrollY", "true"], ["id", "container"], ["size", "12"], ["scrollable", "", "value", "", 3, "ionChange"], [3, "value", 4, "ngFor", "ngForOf"], ["scrollable", "", 3, "value", "ionChange", 4, "ngIf"], [1, "ion-justify-content-center", "ion-padding-horizontal"], ["size", "10", "size-lg", "6", 1, "ion-text-center"], ["shape", "round", "translate", "", 2, "text-transform", "none", "width", "100%", "color", "black", "--background", "#3abff8", "height", "2em", "font-size", "1em", "border-radius", "20px 20px 20px 20px", "border", "1px solid #e5e5ea", "box-shadow", "0px 1px 2px #000000", "font-weight", "lighter", 3, "click"], ["shape", "round", "translate", "", 2, "text-transform", "none", "width", "100%", "color", "black", "--background", "#73cf09", "height", "2em", "font-size", "1em", "border-radius", "20px 20px 20px 20px", "border", "1px solid #e5e5ea", "box-shadow", "0px 1px 2px #000000", "font-weight", "lighter", 3, "hidden", "click"], [3, "value"], ["scrollable", "", 3, "value", "ionChange"], ["value", "0"]],
  template: function SmilePage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "ion-header");
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "ion-toolbar");
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "ion-title", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](3, "Smile Design");
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](4, "ion-content", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](5, "ion-grid");
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "ion-row");
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](7, "div", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](8, "ion-row");
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](9, "ion-col", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](10, "ion-segment", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("ionChange", function SmilePage_Template_ion_segment_ionChange_10_listener($event) {
        return ctx.choseTeethModel($event);
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](11, SmilePage_ion_segment_button_11_Template, 3, 4, "ion-segment-button", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](12, SmilePage_ion_segment_12_Template, 5, 5, "ion-segment", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](13, SmilePage_ion_segment_13_Template, 5, 5, "ion-segment", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](14, "ion-row", 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](15, "ion-col", 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](16, "ion-button", 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function SmilePage_Template_ion_button_click_16_listener() {
        return ctx.reload();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](17, " Reload ");
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](18, "ion-row", 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](19, "ion-col", 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](20, "ion-button", 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function SmilePage_Template_ion_button_click_20_listener() {
        return ctx.finalize();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](21, " Show Result ");
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](22, "ion-row", 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](23, "ion-col", 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](24, "ion-button", 10);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function SmilePage_Template_ion_button_click_24_listener() {
        return ctx.export();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](25, " Go ");
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](11);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngForOf", ctx.teethModel);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.chosenModel);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.chosenModel);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](11);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("hidden", ctx.status);
    }
  },
  directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_6__["IonHeader"], _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["IonToolbar"], _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["IonTitle"], _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__["TranslateDirective"], _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["IonContent"], _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["IonGrid"], _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["IonRow"], _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["IonCol"], _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["IonSegment"], _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["SelectValueAccessor"], _angular_common__WEBPACK_IMPORTED_MODULE_9__["NgForOf"], _angular_common__WEBPACK_IMPORTED_MODULE_9__["NgIf"], _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["IonButton"], _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["IonSegmentButton"]],
  pipes: [_ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__["TranslatePipe"]],
  styles: ["ion-toolbar[_ngcontent-%COMP%] {\n  --background: #0000ff;\n}\n\nion-content[_ngcontent-%COMP%] {\n  --background: #f2f2f7;\n}\n\nion-button[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 2em;\n  font-size: 1.2em;\n  border-radius: 20px 20px 20px 20px;\n  border: 1px solid #e5e5ea;\n  box-shadow: 0px 1px 2px #000000;\n}\n\nion-segment[_ngcontent-%COMP%] {\n  --background: #dcdbd7;\n  --border-checked: 0px;\n}\n\nion-segment-button[_ngcontent-%COMP%] {\n  --color-checked: #000000;\n  font-size: 0.5em;\n}\n\n.pic[_ngcontent-%COMP%] {\n  position: relative;\n  height: 70vh;\n}\n\n.mask[_ngcontent-%COMP%] {\n  position: absolute;\n}\n\n.c[_ngcontent-%COMP%] {\n  --background: wheat;\n}\n\n.cd-project-mask[_ngcontent-%COMP%] {\n  position: relative;\n  height: 100vh;\n  width: 100%;\n  overflow: hidden;\n}\n\n.cd-project-mask[_ngcontent-%COMP%]   .featured-image[_ngcontent-%COMP%] {\n  \n  position: absolute;\n  left: 50%;\n  top: 50%;\n  bottom: auto;\n  right: auto;\n  transform: translateX(-50%) translateY(-50%);\n  height: 50%;\n  width: 50%;\n  background: url('lab2.jpg') no-repeat center center;\n  background-size: cover;\n}\n\n.cd-project-mask[_ngcontent-%COMP%]   .mask[_ngcontent-%COMP%] {\n  position: absolute;\n  left: 50%;\n  top: 50%;\n  bottom: auto;\n  right: auto;\n  transform: translateX(-50%) translateY(-50%);\n  width: 300px;\n  height: 300px;\n}\n\n.cd-project-mask[_ngcontent-%COMP%]   .mask[_ngcontent-%COMP%]   .mask-border[_ngcontent-%COMP%] {\n  \n  position: absolute;\n}\n\n.cd-project-mask[_ngcontent-%COMP%]   .mask[_ngcontent-%COMP%]   .mask-border-top[_ngcontent-%COMP%], .cd-project-mask[_ngcontent-%COMP%]   .mask[_ngcontent-%COMP%]   .mask-border-bottom[_ngcontent-%COMP%] {\n  \n  height: calc(50vh - 150px + 10px);\n  width: 100vw;\n  left: 50%;\n  right: auto;\n  transform: translateX(-50%);\n}\n\n.cd-project-mask[_ngcontent-%COMP%]   .mask[_ngcontent-%COMP%]   .mask-border-top[_ngcontent-%COMP%] {\n  bottom: calc(100% - 10px);\n}\n\n.cd-project-mask[_ngcontent-%COMP%]   .mask[_ngcontent-%COMP%]   .mask-border-bottom[_ngcontent-%COMP%] {\n  top: calc(100% - 10px);\n}\n\n.cd-project-mask[_ngcontent-%COMP%]   .mask[_ngcontent-%COMP%]   .mask-border-left[_ngcontent-%COMP%], .cd-project-mask[_ngcontent-%COMP%]   .mask[_ngcontent-%COMP%]   .mask-border-right[_ngcontent-%COMP%] {\n  \n  height: 100vh;\n  width: calc(50vw - 150px + 10px);\n  top: 50%;\n  bottom: auto;\n  transform: translateY(-50%);\n}\n\n.cd-project-mask[_ngcontent-%COMP%]   .mask[_ngcontent-%COMP%]   .mask-border-left[_ngcontent-%COMP%] {\n  left: calc(100% - 10px);\n}\n\n.cd-project-mask[_ngcontent-%COMP%]   .mask[_ngcontent-%COMP%]   .mask-border-right[_ngcontent-%COMP%] {\n  right: calc(100% - 10px);\n}\n\n#wrapper[_ngcontent-%COMP%] {\n  border: solid 1px black;\n  resize: both;\n  overflow: hidden;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uL3NtaWxlLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHFCQUFBO0FBQ0Y7O0FBRUE7RUFDRSxxQkFBQTtBQUNGOztBQUVBO0VBQ0UsV0FBQTtFQUNBLFdBQUE7RUFDQSxnQkFBQTtFQUNBLGtDQUFBO0VBQ0EseUJBQUE7RUFDQSwrQkFBQTtBQUNGOztBQUVBO0VBQ0UscUJBQUE7RUFFQSxxQkFBQTtBQUFGOztBQUdBO0VBRUUsd0JBQUE7RUFFQSxnQkFBQTtBQUZGOztBQU1BO0VBQ0Usa0JBQUE7RUFDQSxZQUFBO0FBSEY7O0FBT0E7RUFDRSxrQkFBQTtBQUpGOztBQVFBO0VBQ0UsbUJBQUE7QUFMRjs7QUFRQTtFQUNFLGtCQUFBO0VBQ0EsYUFBQTtFQUNBLFdBQUE7RUFDQSxnQkFBQTtBQUxGOztBQVFBO0VBQ0Usd0JBQUE7RUFDQSxrQkFBQTtFQUNBLFNBQUE7RUFDQSxRQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7RUFDQSw0Q0FBQTtFQUNBLFdBQUE7RUFDQSxVQUFBO0VBQ0EsbURBQUE7RUFDQSxzQkFBQTtBQUxGOztBQVFBO0VBQ0Usa0JBQUE7RUFDQSxTQUFBO0VBQ0EsUUFBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0VBQ0EsNENBQUE7RUFDQSxZQUFBO0VBQ0EsYUFBQTtBQUxGOztBQVFBO0VBQ0UsbURBQUE7RUFDQSxrQkFBQTtBQUxGOztBQVFBOztFQUVFLG1EQUFBO0VBQ0EsaUNBQUE7RUFDQSxZQUFBO0VBQ0EsU0FBQTtFQUNBLFdBQUE7RUFDQSwyQkFBQTtBQUxGOztBQVFBO0VBQ0UseUJBQUE7QUFMRjs7QUFRQTtFQUNFLHNCQUFBO0FBTEY7O0FBUUE7O0VBRUUsbURBQUE7RUFDQSxhQUFBO0VBQ0EsZ0NBQUE7RUFDQSxRQUFBO0VBQ0EsWUFBQTtFQUNBLDJCQUFBO0FBTEY7O0FBUUE7RUFDRSx1QkFBQTtBQUxGOztBQVFBO0VBQ0Usd0JBQUE7QUFMRjs7QUFTQTtFQUNFLHVCQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0FBTkYiLCJmaWxlIjoic21pbGUucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLXRvb2xiYXIge1xuICAtLWJhY2tncm91bmQ6ICMwMDAwZmY7XG59XG5cbmlvbi1jb250ZW50IHtcbiAgLS1iYWNrZ3JvdW5kOiAjZjJmMmY3O1xufVxuXG5pb24tYnV0dG9uIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogMmVtO1xuICBmb250LXNpemU6IDEuMmVtO1xuICBib3JkZXItcmFkaXVzOiAyMHB4IDIwcHggMjBweCAyMHB4O1xuICBib3JkZXI6IDFweCBzb2xpZCAjZTVlNWVhO1xuICBib3gtc2hhZG93OiAwcHggMXB4IDJweCAjMDAwMDAwO1xufVxuXG5pb24tc2VnbWVudCB7XG4gIC0tYmFja2dyb3VuZDogI2RjZGJkNztcbiAgLy8gYm9yZGVyLXJhZGl1czogMjBweCAyMHB4IDIwcHggMjBweDtcbiAgLS1ib3JkZXItY2hlY2tlZCA6IDBweDtcbn1cblxuaW9uLXNlZ21lbnQtYnV0dG9ue1xuICAvLyAtLWJhY2tncm91bmQtY2hlY2tlZDogIzNhYmZmODtcbiAgLS1jb2xvci1jaGVja2VkOiAjMDAwMDAwO1xuICAvLyBib3JkZXItcmFkaXVzOiAyMHB4IDIwcHggMjBweCAyMHB4O1xuICBmb250LXNpemU6IDAuNWVtO1xufVxuXG5cbi5waWMge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIGhlaWdodDogNzB2aDtcbiAgLy8gdG9wOiAwO1xuICAvLyBsZWZ0OiAwO1xufVxuLm1hc2sge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIC8vIHRvcDogNjBweDtcbiAgLy8gbGVmdDogMzBweDtcbn1cbi5jIHtcbiAgLS1iYWNrZ3JvdW5kOiB3aGVhdDtcbn1cblxuLmNkLXByb2plY3QtbWFzayB7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgaGVpZ2h0OiAxMDB2aDtcbiAgd2lkdGg6IDEwMCU7XG4gIG92ZXJmbG93OiBoaWRkZW47XG59XG5cbi5jZC1wcm9qZWN0LW1hc2sgLmZlYXR1cmVkLWltYWdlIHtcbiAgLyogcHJvamVjdCBpbnRybyBpbWFnZSAqL1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIGxlZnQ6IDUwJTtcbiAgdG9wOiA1MCU7XG4gIGJvdHRvbTogYXV0bztcbiAgcmlnaHQ6IGF1dG87XG4gIHRyYW5zZm9ybTogdHJhbnNsYXRlWCgtNTAlKSB0cmFuc2xhdGVZKC01MCUpO1xuICBoZWlnaHQ6IDUwJTtcbiAgd2lkdGg6IDUwJTtcbiAgYmFja2dyb3VuZDogdXJsKC4uLy4uL2Fzc2V0cy9sYWIyLmpwZykgbm8tcmVwZWF0IGNlbnRlciBjZW50ZXI7XG4gIGJhY2tncm91bmQtc2l6ZTogY292ZXI7XG59XG5cbi5jZC1wcm9qZWN0LW1hc2sgLm1hc2sge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIGxlZnQ6IDUwJTtcbiAgdG9wOiA1MCU7XG4gIGJvdHRvbTogYXV0bztcbiAgcmlnaHQ6IGF1dG87XG4gIHRyYW5zZm9ybTogdHJhbnNsYXRlWCgtNTAlKSB0cmFuc2xhdGVZKC01MCUpO1xuICB3aWR0aDogMzAwcHg7XG4gIGhlaWdodDogMzAwcHg7XG59XG5cbi5jZC1wcm9qZWN0LW1hc2sgLm1hc2sgLm1hc2stYm9yZGVyIHtcbiAgLyogdGhpcyBpcyB1c2VkIHRvIGNyZWF0ZSBhIGZyYW1lIGFyb3VuZCB0aGUgbWFzayAqL1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG59XG5cbi5jZC1wcm9qZWN0LW1hc2sgLm1hc2sgLm1hc2stYm9yZGVyLXRvcCxcbi5jZC1wcm9qZWN0LW1hc2sgLm1hc2sgLm1hc2stYm9yZGVyLWJvdHRvbSB7XG4gIC8qIHRoaXMgaXMgdXNlZCB0byBjcmVhdGUgYSBmcmFtZSBhcm91bmQgdGhlIG1hc2sgKi9cbiAgaGVpZ2h0OiBjYWxjKDUwdmggLSAxNTBweCArIDEwcHgpO1xuICB3aWR0aDogMTAwdnc7XG4gIGxlZnQ6IDUwJTtcbiAgcmlnaHQ6IGF1dG87XG4gIHRyYW5zZm9ybTogdHJhbnNsYXRlWCgtNTAlKTtcbn1cblxuLmNkLXByb2plY3QtbWFzayAubWFzayAubWFzay1ib3JkZXItdG9wIHtcbiAgYm90dG9tOiBjYWxjKDEwMCUgLSAxMHB4KTtcbn1cblxuLmNkLXByb2plY3QtbWFzayAubWFzayAubWFzay1ib3JkZXItYm90dG9tIHtcbiAgdG9wOiBjYWxjKDEwMCUgLSAxMHB4KTtcbn1cblxuLmNkLXByb2plY3QtbWFzayAubWFzayAubWFzay1ib3JkZXItbGVmdCxcbi5jZC1wcm9qZWN0LW1hc2sgLm1hc2sgLm1hc2stYm9yZGVyLXJpZ2h0IHtcbiAgLyogdGhpcyBpcyB1c2VkIHRvIGNyZWF0ZSBhIGZyYW1lIGFyb3VuZCB0aGUgbWFzayAqL1xuICBoZWlnaHQ6IDEwMHZoO1xuICB3aWR0aDogY2FsYyg1MHZ3IC0gMTUwcHggKyAxMHB4KTtcbiAgdG9wOiA1MCU7XG4gIGJvdHRvbTogYXV0bztcbiAgdHJhbnNmb3JtOiB0cmFuc2xhdGVZKC01MCUpO1xufVxuXG4uY2QtcHJvamVjdC1tYXNrIC5tYXNrIC5tYXNrLWJvcmRlci1sZWZ0IHtcbiAgbGVmdDogY2FsYygxMDAlIC0gMTBweCk7XG59XG5cbi5jZC1wcm9qZWN0LW1hc2sgLm1hc2sgLm1hc2stYm9yZGVyLXJpZ2h0IHtcbiAgcmlnaHQ6IGNhbGMoMTAwJSAtIDEwcHgpO1xufVxuXG5cbiN3cmFwcGVyIHtcbiAgYm9yZGVyOiBzb2xpZCAxcHggYmxhY2s7XG4gIHJlc2l6ZTogYm90aDtcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbn1cbiJdfQ== */"]
});

/***/ })

}]);
//# sourceMappingURL=smile-smile-module.js.map