(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["p-detail-p-detail-module"],{

/***/ "0kBo":
/*!*********************************************!*\
  !*** ./src/app/p-detail/p-detail.module.ts ***!
  \*********************************************/
/*! exports provided: PDetailPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PDetailPageModule", function() { return PDetailPageModule; });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _p_detail_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./p-detail-routing.module */ "6XCE");
/* harmony import */ var _p_detail_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./p-detail.page */ "gO2P");
/* harmony import */ var ngx_photo_editor__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ngx-photo-editor */ "kUS0");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngx-translate/core */ "sYmb");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ "fXoL");








class PDetailPageModule {
}
PDetailPageModule.ɵfac = function PDetailPageModule_Factory(t) { return new (t || PDetailPageModule)(); };
PDetailPageModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineNgModule"]({ type: PDetailPageModule });
PDetailPageModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineInjector"]({ imports: [[
            _angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["IonicModule"],
            _p_detail_routing_module__WEBPACK_IMPORTED_MODULE_3__["PDetailPageRoutingModule"],
            ngx_photo_editor__WEBPACK_IMPORTED_MODULE_5__["NgxPhotoEditorModule"],
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__["TranslateModule"]
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵsetNgModuleScope"](PDetailPageModule, { declarations: [_p_detail_page__WEBPACK_IMPORTED_MODULE_4__["PDetailPage"]], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"],
        _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormsModule"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["IonicModule"],
        _p_detail_routing_module__WEBPACK_IMPORTED_MODULE_3__["PDetailPageRoutingModule"],
        ngx_photo_editor__WEBPACK_IMPORTED_MODULE_5__["NgxPhotoEditorModule"],
        _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__["TranslateModule"]] }); })();


/***/ }),

/***/ "6XCE":
/*!*****************************************************!*\
  !*** ./src/app/p-detail/p-detail-routing.module.ts ***!
  \*****************************************************/
/*! exports provided: PDetailPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PDetailPageRoutingModule", function() { return PDetailPageRoutingModule; });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _p_detail_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./p-detail.page */ "gO2P");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");




const routes = [
    {
        path: '',
        component: _p_detail_page__WEBPACK_IMPORTED_MODULE_1__["PDetailPage"]
    }
];
class PDetailPageRoutingModule {
}
PDetailPageRoutingModule.ɵfac = function PDetailPageRoutingModule_Factory(t) { return new (t || PDetailPageRoutingModule)(); };
PDetailPageRoutingModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineNgModule"]({ type: PDetailPageRoutingModule });
PDetailPageRoutingModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({ imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"].forChild(routes)], _angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsetNgModuleScope"](PDetailPageRoutingModule, { imports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]], exports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]] }); })();


/***/ }),

/***/ "gO2P":
/*!*******************************************!*\
  !*** ./src/app/p-detail/p-detail.page.ts ***!
  \*******************************************/
/*! exports provided: PDetailPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PDetailPage", function() { return PDetailPage; });
/* harmony import */ var _home_mohammad_Work_RisosFront_Risos_node_modules_angular_devkit_build_angular_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@angular-devkit/build-angular/node_modules/@babel/runtime/helpers/esm/asyncToGenerator */ "20ZU");
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../constants */ "l207");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _generated_graphql__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../generated/graphql */ "FJRG");
/* harmony import */ var _services_data_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/data.service */ "EnSQ");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngx-translate/core */ "sYmb");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var ngx_photo_editor__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ngx-photo-editor */ "kUS0");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/forms */ "3Pt+");












function PDetailPage_img_9_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](0, "img", 25);
  }

  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("src", ctx_r0.base64, _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsanitizeUrl"]);
  }
}

function PDetailPage_img_10_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](0, "img", 26);
  }

  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpropertyInterpolate1"]("src", "https://api.risos.ir/mediafiles/", ctx_r1.pro_file, "", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsanitizeUrl"]);
  }
}

const _c0 = function () {
  return ["/home"];
};

class PDetailPage {
  constructor(servicegql, dataService, alertcontroller, smile_design, route, router, loadingcontroller, patientgql, pro_picgql) {
    this.servicegql = servicegql;
    this.dataService = dataService;
    this.alertcontroller = alertcontroller;
    this.smile_design = smile_design;
    this.route = route;
    this.router = router;
    this.loadingcontroller = loadingcontroller;
    this.patientgql = patientgql;
    this.pro_picgql = pro_picgql;
    this.pro_status = false;
    this.edit = true;
    this.route.queryParams.subscribe(params => {
      if (this.router.getCurrentNavigation().extras.state) {
        this.id = this.router.getCurrentNavigation().extras.state.id;
        var id_s = "Patient:" + this.id;
        console.log(this.id);
        this.patientgql.watch({
          id: id_s
        }).valueChanges.subscribe(res => {
          this.name = res.data.Patient.relatedProfile.firstName;
          this._id = res.data.Patient._id;
          this.pro_id = res.data.Patient.relatedProfile._id;
          this.pro_file = res.data.Patient.relatedProfile.profilePic;
          this.mobile = res.data.Patient.relatedProfile.phoneNumber;
          this.age = res.data.Patient.relatedProfile.age; // console.log("p_detail - _id");
          // console.log(this._id)
        });
      }
    });
  }

  ngOnInit() {// console.log(this.name)
  }

  ngAfterViewInit() {
    document.getElementById("getFile").onchange = e => {
      var files = e.target.files[0]; //   console.log(files);

      this.img = files; // localStorage.setItem(Pic,files);
    };
  }

  gallery() {
    let navigationExtras = {
      state: {
        id: this.id
      }
    };
    this.router.navigate(['/gallery'], navigationExtras);
  }

  labs() {
    var navigationExtras;
    this.router.navigate(['/labs'], navigationExtras);
  }

  fileChangeEvent(event) {
    this.pro_status = true;
    this.imageChangedEvent = event;
  }

  imageCropped(event) {
    var _this = this;

    return Object(_home_mohammad_Work_RisosFront_Risos_node_modules_angular_devkit_build_angular_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const loading = yield _this.loadingcontroller.create({
        message: 'Loading ...',
        duration: 2000
      });
      loading.present();
      _this.base64 = event.base64;
      let my_img = event.file;
      console.log(_this._id);

      _this.pro_picgql.mutate({
        id: _this.pro_id,
        profilePic: my_img
      }).subscribe(res => {
        console.log(res.data.updateProfile.status);
        loading.dismiss();
      }); // console.log(this.base64)

    })();
  }

  order() {
    this.servicegql.mutate({
      p_id: this._id,
      d_id: localStorage.getItem(_constants__WEBPACK_IMPORTED_MODULE_1__["ID"])
    }).subscribe(res => {
      // this.s_id=res.data.createService.service.id;
      // console.log(res.data.createService.service.id);
      let sid = res.data.createService.service.id; // console.log(this.s_id)

      let navigationExtras = {
        state: {
          s_id: sid
        }
      }; // console.log(this.s_id);
      // this.router.navigate(['/'], navigationExtras);

      this.router.navigateByUrl('/create-order/' + this._id, navigationExtras);
    });
  }

  go() {
    var _this2 = this;

    return Object(_home_mohammad_Work_RisosFront_Risos_node_modules_angular_devkit_build_angular_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const loading = yield _this2.loadingcontroller.create({
        message: 'Loading ...'
      });
      loading.present();

      _this2.smile_design.watch({
        d_id: localStorage.getItem(_constants__WEBPACK_IMPORTED_MODULE_1__["ID"]),
        p_id: localStorage.getItem(_constants__WEBPACK_IMPORTED_MODULE_1__["P_ID"])
      }).valueChanges.subscribe( /*#__PURE__*/function () {
        var _ref = Object(_home_mohammad_Work_RisosFront_Risos_node_modules_angular_devkit_build_angular_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (res) {
          console.log(res.data.allSmiledesignservice.edges[0].node.status, res.data.allSmiledesignservice.edges[0].node); // console.log(res.data.allSmiledesignservice.edges[0].node.)

          if (res.data.allSmiledesignservice.edges[0].node.status == "READY") {
            loading.dismiss(); // let navigationExtras: NavigationExtras = {
            //   state: {
            //     _id: this._id,
            //     ratio:res.data.allSmiledesignservice.edges[0].node.heigth/res.data.allSmiledesignservice.edges[0].node.width
            //   }
            // };
            // this.router.navigate(['/smile'], navigationExtras);

            _this2.dataService.setData(_this2._id);

            _this2.dataService.setRatio(res.data.allSmiledesignservice.edges[0].node.heigth / res.data.allSmiledesignservice.edges[0].node.width);

            _this2.router.navigateByUrl('/smile/' + _this2._id);
          } else if (res.data.allSmiledesignservice.edges[0].node.status == "IMPROPER_IMAGE") {
            const alert = yield _this2.alertcontroller.create({
              cssClass: 'my-custom-class',
              // header: 'Alert',
              // subHeader: 'Subtitle',
              message: 'Your Picture is not good enough to process , Please delete this patient !',
              buttons: [{
                text: 'Try Again!',
                cssClass: 'my-custom-class',
                handler: blah => {
                  _this2.router.navigate(['/tabs/patients']);
                }
              }]
            });
            loading.dismiss();
            yield alert.present();
          } else {
            // console.log("amir")
            const alert = yield _this2.alertcontroller.create({
              cssClass: 'my-custom-class',
              // header: 'Alert',
              // subHeader: 'Subtitle',
              message: 'Artificial Intelligence has not responded yet!',
              buttons: [{
                text: 'Try Again!',
                cssClass: 'my-custom-class',
                handler: blah => {
                  _this2.router.navigate(['/tabs/patients']);
                }
              }]
            });
            loading.dismiss();
            yield alert.present();
          }
        });

        return function (_x) {
          return _ref.apply(this, arguments);
        };
      }(), error => {
        console.log(error);
      });
    })();
  }

}

PDetailPage.ɵfac = function PDetailPage_Factory(t) {
  return new (t || PDetailPage)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_generated_graphql__WEBPACK_IMPORTED_MODULE_3__["ServiceGQL"]), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_services_data_service__WEBPACK_IMPORTED_MODULE_4__["DataService"]), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_5__["AlertController"]), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_generated_graphql__WEBPACK_IMPORTED_MODULE_3__["AllsmileGQL"]), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_6__["ActivatedRoute"]), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_6__["Router"]), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_5__["LoadingController"]), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_generated_graphql__WEBPACK_IMPORTED_MODULE_3__["PatientGQL"]), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_generated_graphql__WEBPACK_IMPORTED_MODULE_3__["ProfilePicGQL"]));
};

PDetailPage.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({
  type: PDetailPage,
  selectors: [["app-p-detail"]],
  decls: 70,
  vars: 18,
  consts: [["translate", "", 1, "ion-text-center", 2, "color", "white"], [1, "ion-justify-content-center", "ion-padding-horizontal", "ion-padding-top"], ["size", "5"], [1, "ion-justify-content-center"], [1, "vertical-align-content"], ["alt", "", "style", "border-radius: 50%; height: 12vh; ", 3, "src", 4, "ngIf"], ["alt", "", "style", "display: flex;\n      align-items: center;\n      justify-content: center;border-radius: 50%; height: 12vh; ", 3, "src", 4, "ngIf"], [1, "ion-text-center", "ion-no-padding"], ["onclick", "document.getElementById('getFile').click()", 2, "font-size", "0.7em", "color", "#3eb5df"], ["id", "getFile", "type", "file", 2, "display", "none", 3, "change"], [3, "imageChanedEvent", "viewMode", "imageCropped"], ["size", "7", 1, "ion-padding-left"], [1, "ion-justify-content-center", "ion-padding-bottom"], ["size", "12", "size-lg", "8", 1, "ion-text-left", "ion-no-padding"], [2, "margin-bottom", "-0.6em"], ["translate", "", 1, "ion-padding-horizontal", "ion-no-padding", 2, "font-size", "16px", "padding-right", "4px", "padding-left", "4px", "margin-left", "8px", "color", "#aaaaaa", "background", "#f2f2f7", "z-index", "2"], [2, "z-index", "1", 3, "disabled", "ngModel", "ngModelChange"], [1, "ion-justify-content-center", "ion-padding-horizontal", "ion-padding-vertical"], ["placeholder", "Valiasr Sq - Tehran ", 2, "height", "4em", "z-index", "1", 3, "disabled", "ngModel", "ngModelChange"], [1, "ion-justify-content-center", "ion-padding-horizontal"], ["size", "12", "size-lg", "8", 1, "ion-text-center"], ["shape", "round", "translate", "", 2, "text-transform", "none", "width", "100%", "color", "black", "--background", "#3abff8", "height", "2em", "font-size", "1em", "border-radius", "20px 20px 20px 20px", "border", "1px solid #e5e5ea", "box-shadow", "0px 1px 2px #000000", "font-weight", "lighter", 3, "click"], ["size", "6"], ["shape", "round", "routerDirection", "forward", "translate", "", 2, "color", "black", "--background", "#ffffff", 3, "routerLink", "click"], ["shape", "round", "translate", "", 2, "color", "black", "--background", "#ffffff", 3, "click"], ["alt", "", 2, "border-radius", "50%", "height", "12vh", 3, "src"], ["alt", "", 2, "display", "flex", "align-items", "center", "justify-content", "center", "border-radius", "50%", "height", "12vh", 3, "src"]],
  template: function PDetailPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "ion-header");
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "ion-toolbar");
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](2, "ion-title", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](3, "Patient document");
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](4, "ion-content");
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](5, "ion-row", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](6, "ion-col", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](7, "ion-row", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](8, "ion-col", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](9, PDetailPage_img_9_Template, 1, 1, "img", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](10, PDetailPage_img_10_Template, 1, 1, "img", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](11, "ion-row");
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](12, "ion-col", 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](13, "div");
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](14, "ion-label", 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](15, " Change profile photo ");
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](16, "input", 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("change", function PDetailPage_Template_input_change_16_listener($event) {
        return ctx.fileChangeEvent($event);
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](17, "ngx-photo-editor", 10);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("imageCropped", function PDetailPage_Template_ngx_photo_editor_imageCropped_17_listener($event) {
        return ctx.imageCropped($event);
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](18, "ion-col", 11);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](19, "ion-row", 12);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](20, "ion-col", 13);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](21, "ion-row", 14);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](22, "ion-label", 15);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](23, " First name ");
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](24, "ion-input", 16);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("ngModelChange", function PDetailPage_Template_ion_input_ngModelChange_24_listener($event) {
        return ctx.name = $event;
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](25, "ion-row", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](26, "ion-col", 13);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](27, "ion-row", 14);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](28, "ion-label", 15);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](29, " Last name ");
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](30, "ion-input", 16);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("ngModelChange", function PDetailPage_Template_ion_input_ngModelChange_30_listener($event) {
        return ctx.last = $event;
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](31, "ion-row", 17);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](32, "ion-col", 13);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](33, "ion-row", 14);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](34, "ion-label", 15);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](35, " Mobile number ");
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](36, "ion-input", 16);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("ngModelChange", function PDetailPage_Template_ion_input_ngModelChange_36_listener($event) {
        return ctx.mobile = $event;
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](37, "ion-row", 17);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](38, "ion-col", 13);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](39, "ion-row", 14);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](40, "ion-label", 15);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](41, " Age ");
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](42, "ion-input", 16);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("ngModelChange", function PDetailPage_Template_ion_input_ngModelChange_42_listener($event) {
        return ctx.age = $event;
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](43, "ion-row", 17);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](44, "ion-col", 13);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](45, "ion-row", 14);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](46, "ion-label", 15);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](47, " Address ");
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](48, "ion-input", 18);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("ngModelChange", function PDetailPage_Template_ion_input_ngModelChange_48_listener($event) {
        return ctx.address = $event;
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](49, "ion-row", 17);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](50, "ion-col", 13);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](51, "ion-row", 14);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](52, "ion-label", 15);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](53, " Detail ");
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](54, "ion-input", 16);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("ngModelChange", function PDetailPage_Template_ion_input_ngModelChange_54_listener($event) {
        return ctx.detail = $event;
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](55, "ion-row", 19);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](56, "ion-col", 20);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](57, "ion-button", 21);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function PDetailPage_Template_ion_button_click_57_listener() {
        return ctx.go();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](58, " Smile Design ");
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](59, "ion-row", 19);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](60, "ion-col", 20);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](61, "ion-button", 21);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function PDetailPage_Template_ion_button_click_61_listener() {
        return ctx.order();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](62, " Order ");
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](63, "ion-row", 19);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](64, "ion-col", 22);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](65, "ion-button", 23);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function PDetailPage_Template_ion_button_click_65_listener() {
        return ctx.labs();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](66, " Laboratory ");
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](67, "ion-col", 22);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](68, "ion-button", 24);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("click", function PDetailPage_Template_ion_button_click_68_listener() {
        return ctx.gallery();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtext"](69, " Gallery ");
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](9);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ctx.pro_status);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", !ctx.pro_status);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](7);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("imageChanedEvent", ctx.imageChangedEvent)("viewMode", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](7);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("disabled", ctx.edit)("ngModel", ctx.name);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](6);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("disabled", ctx.edit)("ngModel", ctx.last);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](6);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("disabled", ctx.edit)("ngModel", ctx.mobile);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](6);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("disabled", ctx.edit)("ngModel", ctx.age);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](6);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("disabled", ctx.edit)("ngModel", ctx.address);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](6);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("disabled", ctx.edit)("ngModel", ctx.detail);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](11);
      _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("routerLink", _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵpureFunction0"](17, _c0));
    }
  },
  directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonHeader"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonToolbar"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonTitle"], _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__["TranslateDirective"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonContent"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonRow"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonCol"], _angular_common__WEBPACK_IMPORTED_MODULE_8__["NgIf"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonLabel"], ngx_photo_editor__WEBPACK_IMPORTED_MODULE_9__["NgxPhotoEditorComponent"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonInput"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["TextValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_10__["NgControlStatus"], _angular_forms__WEBPACK_IMPORTED_MODULE_10__["NgModel"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonButton"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["RouterLinkDelegate"], _angular_router__WEBPACK_IMPORTED_MODULE_6__["RouterLink"]],
  styles: ["ion-toolbar[_ngcontent-%COMP%] {\n  --background:#0000ff;\n}\n\nion-content[_ngcontent-%COMP%] {\n  --background:#f2f2f7;\n}\n\nion-input[_ngcontent-%COMP%] {\n  border: 1px solid #aaaaaa;\n  border-radius: 20px 20px 20px 20px;\n  --placeholder-color:#aaaaaa;\n  --background:#f8f7fa;\n  --padding-start:0.5em;\n  height: 3em;\n}\n\nion-button[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 2em;\n  font-size: 1.2em;\n  border-radius: 20px 20px 20px 20px;\n  border: 1px solid #e5e5ea;\n  box-shadow: 0px 1px 2px #000000;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uL3AtZGV0YWlsLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLG9CQUFBO0FBQ0Y7O0FBRUE7RUFDRSxvQkFBQTtBQUNGOztBQUVBO0VBQ0UseUJBQUE7RUFDQSxrQ0FBQTtFQUNBLDJCQUFBO0VBQ0Esb0JBQUE7RUFDQSxxQkFBQTtFQUNBLFdBQUE7QUFDRjs7QUFFQTtFQUNFLFdBQUE7RUFDQSxXQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQ0FBQTtFQUNBLHlCQUFBO0VBQ0EsK0JBQUE7QUFDRiIsImZpbGUiOiJwLWRldGFpbC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tdG9vbGJhcntcbiAgLS1iYWNrZ3JvdW5kOiMwMDAwZmY7XG59XG5cbmlvbi1jb250ZW50e1xuICAtLWJhY2tncm91bmQ6I2YyZjJmNztcbn1cblxuaW9uLWlucHV0e1xuICBib3JkZXI6MXB4IHNvbGlkICNhYWFhYWE7XG4gIGJvcmRlci1yYWRpdXM6IDIwcHggMjBweCAyMHB4IDIwcHg7XG4gIC0tcGxhY2Vob2xkZXItY29sb3I6I2FhYWFhYTtcbiAgLS1iYWNrZ3JvdW5kOiNmOGY3ZmE7XG4gIC0tcGFkZGluZy1zdGFydDowLjVlbTtcbiAgaGVpZ2h0OiAzZW07XG59XG5cbmlvbi1idXR0b257XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6MmVtO1xuICBmb250LXNpemU6IDEuMmVtO1xuICBib3JkZXItcmFkaXVzOiAyMHB4IDIwcHggMjBweCAyMHB4O1xuICBib3JkZXI6MXB4IHNvbGlkICNlNWU1ZWE7XG4gIGJveC1zaGFkb3c6IDBweCAxcHggMnB4ICMwMDAwMDA7XG59XG4iXX0= */"]
});

/***/ })

}]);
//# sourceMappingURL=p-detail-p-detail-module.js.map