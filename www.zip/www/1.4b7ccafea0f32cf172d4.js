(window.webpackJsonp=window.webpackJsonp||[]).push([[1],{FJRG:function(e,t,r){"use strict";r.d(t,"A",function(){return s}),r.d(t,"g",function(){return a}),r.d(t,"f",function(){return l}),r.d(t,"j",function(){return p}),r.d(t,"i",function(){return $}),r.d(t,"H",function(){return v}),r.d(t,"k",function(){return I}),r.d(t,"E",function(){return h}),r.d(t,"e",function(){return y}),r.d(t,"r",function(){return q}),r.d(t,"F",function(){return k}),r.d(t,"l",function(){return _}),r.d(t,"n",function(){return O}),r.d(t,"B",function(){return U}),r.d(t,"d",function(){return z}),r.d(t,"o",function(){return F}),r.d(t,"I",function(){return T}),r.d(t,"m",function(){return A}),r.d(t,"a",function(){return M}),r.d(t,"p",function(){return E}),r.d(t,"G",function(){return X}),r.d(t,"q",function(){return Q}),r.d(t,"s",function(){return W}),r.d(t,"t",function(){return Z}),r.d(t,"h",function(){return te}),r.d(t,"u",function(){return ne}),r.d(t,"v",function(){return ce}),r.d(t,"C",function(){return se}),r.d(t,"w",function(){return ae}),r.d(t,"x",function(){return le}),r.d(t,"c",function(){return pe}),r.d(t,"z",function(){return $e}),r.d(t,"y",function(){return ve}),r.d(t,"D",function(){return Ie}),r.d(t,"b",function(){return he}),r.d(t,"J",function(){return ye});var n=r("ALmS"),o=r("/IUn"),c=r("fXoL");const i=n.gql`
    mutation save_design($dr: Int!, $p_id: Int!, $images: SmileDesignImages, $model: String!, $color: String!) {
  updateSmileDesign(
    doctorId: $dr
    patientId: $p_id
    smileDesignImages: $images
    smileCategory: $model
    smileColor: $color
  ) {
    status
  }
}
    `;let s=(()=>{class e extends o.c{constructor(e){super(e),this.document=i}}return e.\u0275fac=function(t){return new(t||e)(c.ec(o.b))},e.\u0275prov=c.Nb({token:e,factory:e.\u0275fac,providedIn:"root"}),e})();const d=n.gql`
    mutation createpatient($Name: String!, $Pics: patientPics, $Phone_no: String!, $age: Int!, $id: Int!) {
  createPatient(
    name: $Name
    profileDoctorId: $id
    patientPics: $Pics
    age: $age
    phoneNumber: $Phone_no
  ) {
    token
  }
}
    `;let a=(()=>{class e extends o.c{constructor(e){super(e),this.document=d}}return e.\u0275fac=function(t){return new(t||e)(c.ec(o.b))},e.\u0275prov=c.Nb({token:e,factory:e.\u0275fac,providedIn:"root"}),e})();const u=n.gql`
    mutation createlab($Username: String!, $mobile: String!, $land: String!, $adress: String!, $description: String!) {
  createLab(
    name: $Username
    phoneNumber: $mobile
    telephoneNumber: $land
    address: $adress
    description: $description
  ) {
    token
  }
}
    `;let l=(()=>{class e extends o.c{constructor(e){super(e),this.document=u}}return e.\u0275fac=function(t){return new(t||e)(c.ec(o.b))},e.\u0275prov=c.Nb({token:e,factory:e.\u0275fac,providedIn:"root"}),e})();const f=n.gql`
    mutation forgetPass($phoneNumber: String!) {
  forgetPass(phoneNumber: $phoneNumber) {
    status
  }
}
    `;let p=(()=>{class e extends o.c{constructor(e){super(e),this.document=f}}return e.\u0275fac=function(t){return new(t||e)(c.ec(o.b))},e.\u0275prov=c.Nb({token:e,factory:e.\u0275fac,providedIn:"root"}),e})();const m=n.gql`
    mutation delpatientpic($id: Int!, $selectedFields: patientPicsDeletion) {
  deletePatientPic(patientId: $id, selectedFields: $selectedFields) {
    status
  }
}
    `;let $=(()=>{class e extends o.c{constructor(e){super(e),this.document=m}}return e.\u0275fac=function(t){return new(t||e)(c.ec(o.b))},e.\u0275prov=c.Nb({token:e,factory:e.\u0275fac,providedIn:"root"}),e})();const g=n.gql`
    mutation update_pic($id: Int!, $pics: patientPics!) {
  updatePatientPic(patientId: $id, patientPics: $pics) {
    status
  }
}
    `;let v=(()=>{class e extends o.c{constructor(e){super(e),this.document=g}}return e.\u0275fac=function(t){return new(t||e)(c.ec(o.b))},e.\u0275prov=c.Nb({token:e,factory:e.\u0275fac,providedIn:"root"}),e})();const b=n.gql`
    mutation invoice($s_id: ID!, $teeth: JSONString!, $central: String!) {
  toothMutationJson(
    relatedService: $s_id
    jsonObject: $teeth
    centralSize: $central
  ) {
    status
  }
}
    `;let I=(()=>{class e extends o.c{constructor(e){super(e),this.document=b}}return e.\u0275fac=function(t){return new(t||e)(c.ec(o.b))},e.\u0275prov=c.Nb({token:e,factory:e.\u0275fac,providedIn:"root"}),e})();const N=n.gql`
    query services {
  allToothsevice {
    edges {
      node {
        name
      }
    }
  }
}
    `;let h=(()=>{class e extends o.d{constructor(e){super(e),this.document=N}}return e.\u0275fac=function(t){return new(t||e)(c.ec(o.b))},e.\u0275prov=c.Nb({token:e,factory:e.\u0275fac,providedIn:"root"}),e})();const P=n.gql`
    mutation createOrder($sid: ID!, $lid: ID!, $date: Date) {
  createOrder(
    input: {relatedService: $sid, finalizedLab: $lid, status: "sent", expectedDate: $date}
  ) {
    order {
      id
    }
  }
}
    `;let y=(()=>{class e extends o.c{constructor(e){super(e),this.document=P}}return e.\u0275fac=function(t){return new(t||e)(c.ec(o.b))},e.\u0275prov=c.Nb({token:e,factory:e.\u0275fac,providedIn:"root"}),e})();const S=n.gql`
    query orders_l($dr: [String], $lab: [String]) {
  allOrder(doctorId: $dr, finalizedLab_In: $lab) {
    edges {
      node {
        _id
        id
        status
        expectedDate
        relatedService {
          relatedPatient {
            relatedProfile {
              firstName
              profilePic
            }
          }
        }
      }
    }
  }
}
    `;let q=(()=>{class e extends o.d{constructor(e){super(e),this.document=S}}return e.\u0275fac=function(t){return new(t||e)(c.ec(o.b))},e.\u0275prov=c.Nb({token:e,factory:e.\u0275fac,providedIn:"root"}),e})();const w=n.gql`
    mutation ticket($text: String!, $order: Int!, $send: Int!, $receive: Int!) {
  createTicker(
    message: $text
    relatedOrder: $order
    receiverProfile: $receive
    senderProfile: $send
  ) {
    status
  }
}
    `;let k=(()=>{class e extends o.c{constructor(e){super(e),this.document=w}}return e.\u0275fac=function(t){return new(t||e)(c.ec(o.b))},e.\u0275prov=c.Nb({token:e,factory:e.\u0275fac,providedIn:"root"}),e})();const x=n.gql`
    query lab($id: ID!) {
  Lab(id: $id) {
    relatedProfile {
      id
      _id
      firstName
      phoneNumber
      telephoneNumber
    }
    orderSet {
      expectedDate
      relatedService {
        relatedPatient {
          relatedProfile {
            firstName
            profilePic
          }
        }
      }
    }
  }
}
    `;let _=(()=>{class e extends o.d{constructor(e){super(e),this.document=x}}return e.\u0275fac=function(t){return new(t||e)(c.ec(o.b))},e.\u0275prov=c.Nb({token:e,factory:e.\u0275fac,providedIn:"root"}),e})();const D=n.gql`
    query labs {
  allLab {
    edges {
      node {
        id
        _id
        relatedProfile {
          firstName
        }
      }
    }
  }
}
    `;let O=(()=>{class e extends o.d{constructor(e){super(e),this.document=D}}return e.\u0275fac=function(t){return new(t||e)(c.ec(o.b))},e.\u0275prov=c.Nb({token:e,factory:e.\u0275fac,providedIn:"root"}),e})();const L=n.gql`
    query search_lab($name: String!) {
  allLab(searchByName: $name) {
    edges {
      node {
        id
        _id
        relatedProfile {
          firstName
        }
      }
    }
  }
}
    `;let U=(()=>{class e extends o.d{constructor(e){super(e),this.document=L}}return e.\u0275fac=function(t){return new(t||e)(c.ec(o.b))},e.\u0275prov=c.Nb({token:e,factory:e.\u0275fac,providedIn:"root"}),e})();const J=n.gql`
    mutation CreateDevice($ProfileId: ID!, $deviceId: String!) {
  createDevice(ProfileId: $ProfileId, deviceId: $deviceId) {
    status
  }
}
    `;let z=(()=>{class e extends o.c{constructor(e){super(e),this.document=J}}return e.\u0275fac=function(t){return new(t||e)(c.ec(o.b))},e.\u0275prov=c.Nb({token:e,factory:e.\u0275fac,providedIn:"root"}),e})();const B=n.gql`
    mutation login($username: String!, $password: String!) {
  tokenAuth(username: $username, password: $password) {
    token
    profile
  }
}
    `;let F=(()=>{class e extends o.c{constructor(e){super(e),this.document=B}}return e.\u0275fac=function(t){return new(t||e)(c.ec(o.b))},e.\u0275prov=c.Nb({token:e,factory:e.\u0275fac,providedIn:"root"}),e})();const C=n.gql`
    mutation verify($token: String!) {
  verifyToken(token: $token) {
    payload
  }
}
    `;let T=(()=>{class e extends o.c{constructor(e){super(e),this.document=C}}return e.\u0275fac=function(t){return new(t||e)(c.ec(o.b))},e.\u0275prov=c.Nb({token:e,factory:e.\u0275fac,providedIn:"root"}),e})();const j=n.gql`
    query labrated {
  allLab(sortByRate: "-rating") {
    edges {
      node {
        rating
        id
        relatedProfile {
          firstName
        }
      }
    }
  }
}
    `;let A=(()=>{class e extends o.d{constructor(e){super(e),this.document=j}}return e.\u0275fac=function(t){return new(t||e)(c.ec(o.b))},e.\u0275prov=c.Nb({token:e,factory:e.\u0275fac,providedIn:"root"}),e})();const G=n.gql`
    query allnotif($id: [String]) {
  allNotification(receivers_In: $id) {
    edges {
      node {
        id
        message
      }
    }
  }
}
    `;let M=(()=>{class e extends o.d{constructor(e){super(e),this.document=G}}return e.\u0275fac=function(t){return new(t||e)(c.ec(o.b))},e.\u0275prov=c.Nb({token:e,factory:e.\u0275fac,providedIn:"root"}),e})();const R=n.gql`
    query order($id: ID!) {
  Order(id: $id) {
    id
    status
    finalizedLab {
      relatedProfile {
        firstName
      }
    }
    ticketSet {
      edges {
        node {
          id
          message
          sender {
            _id
          }
        }
      }
    }
    invoice {
      price
      description
      actualDate
    }
    expectedDate
    relatedService {
      relatedPatient {
        relatedProfile {
          firstName
          lastName
          profilePic
        }
      }
    }
  }
}
    `;let E=(()=>{class e extends o.d{constructor(e){super(e),this.document=R}}return e.\u0275fac=function(t){return new(t||e)(c.ec(o.b))},e.\u0275prov=c.Nb({token:e,factory:e.\u0275fac,providedIn:"root"}),e})();const H=n.gql`
    mutation UpdateOrder($id: ID!, $status: String) {
  updateOrder(status: $status, orderId: $id) {
    status
  }
}
    `;let X=(()=>{class e extends o.c{constructor(e){super(e),this.document=H}}return e.\u0275fac=function(t){return new(t||e)(c.ec(o.b))},e.\u0275prov=c.Nb({token:e,factory:e.\u0275fac,providedIn:"root"}),e})();const K=n.gql`
    query orders($dr: [String]) {
  allOrder(doctorId: $dr) {
    edges {
      node {
        _id
        id
        status
        expectedDate
        relatedService {
          relatedPatient {
            relatedProfile {
              firstName
              profilePic
            }
          }
        }
      }
    }
  }
}
    `;let Q=(()=>{class e extends o.d{constructor(e){super(e),this.document=K}}return e.\u0275fac=function(t){return new(t||e)(c.ec(o.b))},e.\u0275prov=c.Nb({token:e,factory:e.\u0275fac,providedIn:"root"}),e})();const V=n.gql`
    query orders_s($name: String!) {
  allOrder(searchByName: $name) {
    edges {
      node {
        _id
        id
        status
        expectedDate
        relatedService {
          relatedPatient {
            relatedProfile {
              firstName
              profilePic
            }
          }
        }
      }
    }
  }
}
    `;let W=(()=>{class e extends o.d{constructor(e){super(e),this.document=V}}return e.\u0275fac=function(t){return new(t||e)(c.ec(o.b))},e.\u0275prov=c.Nb({token:e,factory:e.\u0275fac,providedIn:"root"}),e})();const Y=n.gql`
    query orders_state($name: String!) {
  allOrder(statusStartwith: $name) {
    edges {
      node {
        _id
        id
        status
        expectedDate
        relatedService {
          relatedPatient {
            relatedProfile {
              firstName
              profilePic
            }
          }
        }
      }
    }
  }
}
    `;let Z=(()=>{class e extends o.d{constructor(e){super(e),this.document=Y}}return e.\u0275fac=function(t){return new(t||e)(c.ec(o.b))},e.\u0275prov=c.Nb({token:e,factory:e.\u0275fac,providedIn:"root"}),e})();const ee=n.gql`
    mutation delPatient($id: Int!) {
  deletePatient(patientId: $id) {
    status
  }
}
    `;let te=(()=>{class e extends o.c{constructor(e){super(e),this.document=ee}}return e.\u0275fac=function(t){return new(t||e)(c.ec(o.b))},e.\u0275prov=c.Nb({token:e,factory:e.\u0275fac,providedIn:"root"}),e})();const re=n.gql`
    query patient($id: ID!) {
  Patient(id: $id) {
    _id
    patientPic {
      sideImage
      fullSmileImage
      optionalImage
      smileImage
    }
    relatedProfile {
      firstName
      lastName
      profilePic
      _id
      age
      phoneNumber
    }
  }
}
    `;let ne=(()=>{class e extends o.d{constructor(e){super(e),this.document=re}}return e.\u0275fac=function(t){return new(t||e)(c.ec(o.b))},e.\u0275prov=c.Nb({token:e,factory:e.\u0275fac,providedIn:"root"}),e})();const oe=n.gql`
    query patients($dr: [String]) {
  allPatient(doctor_In: $dr) {
    edges {
      node {
        id
        relatedProfile {
          id
          firstName
          lastName
          profilePic
        }
      }
    }
  }
}
    `;let ce=(()=>{class e extends o.d{constructor(e){super(e),this.document=oe}}return e.\u0275fac=function(t){return new(t||e)(c.ec(o.b))},e.\u0275prov=c.Nb({token:e,factory:e.\u0275fac,providedIn:"root"}),e})();const ie=n.gql`
    query search_p($id: [String]!, $name: String!) {
  allPatient(doctor_In: $id, searchByName: $name) {
    edges {
      node {
        id
        relatedProfile {
          id
          firstName
          lastName
          profilePic
        }
      }
    }
  }
}
    `;let se=(()=>{class e extends o.d{constructor(e){super(e),this.document=ie}}return e.\u0275fac=function(t){return new(t||e)(c.ec(o.b))},e.\u0275prov=c.Nb({token:e,factory:e.\u0275fac,providedIn:"root"}),e})();const de=n.gql`
    query profile($id: ID!) {
  Profile(id: $id) {
    id
    phoneNumber
    email
  }
}
    `;let ae=(()=>{class e extends o.d{constructor(e){super(e),this.document=de}}return e.\u0275fac=function(t){return new(t||e)(c.ec(o.b))},e.\u0275prov=c.Nb({token:e,factory:e.\u0275fac,providedIn:"root"}),e})();const ue=n.gql`
    mutation profilePic($id: ID!, $profilePic: Upload) {
  updateProfile(profilePic: $profilePic, id: $id) {
    status
  }
}
    `;let le=(()=>{class e extends o.c{constructor(e){super(e),this.document=ue}}return e.\u0275fac=function(t){return new(t||e)(c.ec(o.b))},e.\u0275prov=c.Nb({token:e,factory:e.\u0275fac,providedIn:"root"}),e})();const fe=n.gql`
    mutation changePass($new: String!, $user: String!) {
  changePassword(newPassword: $new, username: $user) {
    status
  }
}
    `;let pe=(()=>{class e extends o.c{constructor(e){super(e),this.document=fe}}return e.\u0275fac=function(t){return new(t||e)(c.ec(o.b))},e.\u0275prov=c.Nb({token:e,factory:e.\u0275fac,providedIn:"root"}),e})();const me=n.gql`
    mutation req_otp($username: String!) {
  requestOtp(username: $username) {
    status
  }
}
    `;let $e=(()=>{class e extends o.c{constructor(e){super(e),this.document=me}}return e.\u0275fac=function(t){return new(t||e)(c.ec(o.b))},e.\u0275prov=c.Nb({token:e,factory:e.\u0275fac,providedIn:"root"}),e})();const ge=n.gql`
    mutation register($username: String!, $password: String!, $email: String!) {
  createUser(username: $username, password: $password, email: $email) {
    token
  }
}
    `;let ve=(()=>{class e extends o.c{constructor(e){super(e),this.document=ge}}return e.\u0275fac=function(t){return new(t||e)(c.ec(o.b))},e.\u0275prov=c.Nb({token:e,factory:e.\u0275fac,providedIn:"root"}),e})();const be=n.gql`
    mutation service($p_id: ID!, $d_id: ID!) {
  createService(input: {relatedPatient: $p_id, relatedDoctor: $d_id}) {
    service {
      id
    }
  }
}
    `;let Ie=(()=>{class e extends o.c{constructor(e){super(e),this.document=be}}return e.\u0275fac=function(t){return new(t||e)(c.ec(o.b))},e.\u0275prov=c.Nb({token:e,factory:e.\u0275fac,providedIn:"root"}),e})();const Ne=n.gql`
    query allsmile($d_id: [String], $p_id: [String]) {
  allSmiledesignservice(doctor_In: $d_id, patient_In: $p_id) {
    edges {
      node {
        status
        teethLessImage
        width
        heigth
      }
    }
  }
}
    `;let he=(()=>{class e extends o.d{constructor(e){super(e),this.document=Ne}}return e.\u0275fac=function(t){return new(t||e)(c.ec(o.b))},e.\u0275prov=c.Nb({token:e,factory:e.\u0275fac,providedIn:"root"}),e})();n.gql`
    mutation OTP($user: String!) {
  requestOtp(username: $user) {
    status
  }
}
    `;const Pe=n.gql`
    mutation verify_user($Username: String!, $Otp: String!) {
  verifyUser(username: $Username, otpMessage: $Otp) {
    status
  }
}
    `;let ye=(()=>{class e extends o.c{constructor(e){super(e),this.document=Pe}}return e.\u0275fac=function(t){return new(t||e)(c.ec(o.b))},e.\u0275prov=c.Nb({token:e,factory:e.\u0275fac,providedIn:"root"}),e})()}}]);