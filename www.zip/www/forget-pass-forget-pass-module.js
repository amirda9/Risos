(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["forget-pass-forget-pass-module"],{

/***/ "R0qC":
/*!*************************************************!*\
  !*** ./src/app/forget-pass/forget-pass.page.ts ***!
  \*************************************************/
/*! exports provided: ForgetPassPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ForgetPassPage", function() { return ForgetPassPage; });
/* harmony import */ var _home_mohammad_Work_RisosFront_Risos_node_modules_angular_devkit_build_angular_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@angular-devkit/build-angular/node_modules/@babel/runtime/helpers/esm/asyncToGenerator */ "20ZU");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngx-translate/core */ "sYmb");
/* harmony import */ var _generated_graphql__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../generated/graphql */ "FJRG");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ "3Pt+");







class ForgetPassPage {
  constructor(translateservice, forgetpass_gql, alertcontroller, router) {
    this.translateservice = translateservice;
    this.forgetpass_gql = forgetpass_gql;
    this.alertcontroller = alertcontroller;
    this.router = router;
  }

  ngOnInit() {
    this.Pntrans = this.translateservice.instant('Phone Number');
  }

  forgetPass() {
    var _this = this;

    this.forgetpass_gql.mutate({
      phoneNumber: this.id
    }).subscribe( /*#__PURE__*/function () {
      var _ref = Object(_home_mohammad_Work_RisosFront_Risos_node_modules_angular_devkit_build_angular_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (res) {
        if (res.data.forgetPass.status == "Success") {
          // console.log(this.id)
          let navigationExtras = {
            state: {
              s_id: _this.id,
              trans_state: 1
            }
          };

          _this.router.navigate(['/verify'], navigationExtras);
        } else {
          const alert = yield _this.alertcontroller.create({
            cssClass: 'my-custom-class',
            // header: 'Alert',
            // subHeader: 'Subtitle',
            message: 'You have to sign up first!',
            buttons: [{
              text: 'Try Again!',
              cssClass: 'my-custom-class'
            }]
          });
          yield alert.present();
        }
      });

      return function (_x) {
        return _ref.apply(this, arguments);
      };
    }());
  }

}

ForgetPassPage.ɵfac = function ForgetPassPage_Factory(t) {
  return new (t || ForgetPassPage)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__["TranslateService"]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_generated_graphql__WEBPACK_IMPORTED_MODULE_3__["ForgetPassGQL"]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"]));
};

ForgetPassPage.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
  type: ForgetPassPage,
  selectors: [["app-forget-pass"]],
  decls: 21,
  vars: 2,
  consts: [["translate", "", 1, "ion-text-center", 2, "color", "white"], ["slot", "start"], ["color", "light", "defaultHref", "login"], [2, "margin-top", "7em"], [1, "ion-justify-content-center", "ion-padding-horizontal", 2, "padding-top", "0.3em"], ["size", "10", "size-md", "10", "size-lg", "8", 1, "ion-text-center"], ["translate", ""], [1, "ion-justify-content-center", "ion-padding-horizontal", "ion-padding-top"], ["size", "12", "size-md", "10", "size-lg", "8", 1, "ion-text-left"], ["translate", "", 3, "ngModel", "placeholder", "ngModelChange"], [1, "footer"], [1, "ion-justify-content-center", "ion-padding-horizontal"], ["size", "12", "size-lg", "8", 1, "ion-text-center"], ["shape", "round", "translate", "", 2, "text-transform", "none", "width", "100%", "color", "black", "--background", "#3abff8", 3, "click"]],
  template: function ForgetPassPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "ion-header");
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "ion-toolbar");
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](2, "ion-title", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](3, "Forgot Password");
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](4, "ion-buttons", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](5, "ion-back-button", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](6, "ion-content");
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](7, "div", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](8, "ion-grid");
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](9, "ion-row", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](10, "ion-col", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](11, "ion-label", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](12, " Please enter your phone number to receive verification code ");
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](13, "ion-row", 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](14, "ion-col", 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](15, "ion-input", 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ngModelChange", function ForgetPassPage_Template_ion_input_ngModelChange_15_listener($event) {
        return ctx.id = $event;
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](16, "div", 10);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](17, "ion-row", 11);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](18, "ion-col", 12);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](19, "ion-button", 13);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function ForgetPassPage_Template_ion_button_click_19_listener() {
        return ctx.forgetPass();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](20, " Submit ");
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](15);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngModel", ctx.id)("placeholder", ctx.Pntrans);
    }
  },
  directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonHeader"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonToolbar"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonTitle"], _ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__["TranslateDirective"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonButtons"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonBackButton"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonBackButtonDelegate"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonContent"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonGrid"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonRow"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonCol"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonLabel"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonInput"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["TextValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_6__["NgControlStatus"], _angular_forms__WEBPACK_IMPORTED_MODULE_6__["NgModel"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonButton"]],
  styles: ["ion-content[_ngcontent-%COMP%] {\n  --background:#f2f2f7;\n}\n\nion-toolbar[_ngcontent-%COMP%] {\n  --background:#6754a0;\n}\n\nion-input[_ngcontent-%COMP%] {\n  border: 1px solid #aaaaaa;\n  border-radius: 20px 20px 20px 20px;\n  --placeholder-color:#aaaaaa;\n  --background:#ffffff;\n}\n\n.footer[_ngcontent-%COMP%] {\n  position: fixed;\n  bottom: 4em;\n  width: 100%;\n}\n\nion-button[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 2em;\n  font-size: 1.2em;\n  border-radius: 20px 20px 20px 20px;\n  border: 1px solid #e5e5ea;\n  box-shadow: 0px 1px 2px #000000;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uL2ZvcmdldC1wYXNzLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLG9CQUFBO0FBQ0Y7O0FBRUE7RUFDRSxvQkFBQTtBQUNGOztBQUVBO0VBQ0UseUJBQUE7RUFDQSxrQ0FBQTtFQUNBLDJCQUFBO0VBQ0Esb0JBQUE7QUFDRjs7QUFHQTtFQUNFLGVBQUE7RUFDQSxXQUFBO0VBQ0EsV0FBQTtBQUFGOztBQUdBO0VBQ0UsV0FBQTtFQUNBLFdBQUE7RUFDQSxnQkFBQTtFQUNBLGtDQUFBO0VBQ0EseUJBQUE7RUFDQSwrQkFBQTtBQUFGIiwiZmlsZSI6ImZvcmdldC1wYXNzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1jb250ZW50e1xuICAtLWJhY2tncm91bmQ6I2YyZjJmNztcbn1cblxuaW9uLXRvb2xiYXJ7XG4gIC0tYmFja2dyb3VuZDojNjc1NGEwO1xufVxuXG5pb24taW5wdXR7XG4gIGJvcmRlcjoxcHggc29saWQgI2FhYWFhYTtcbiAgYm9yZGVyLXJhZGl1czogMjBweCAyMHB4IDIwcHggMjBweDtcbiAgLS1wbGFjZWhvbGRlci1jb2xvcjojYWFhYWFhO1xuICAtLWJhY2tncm91bmQ6I2ZmZmZmZjtcbn1cblxuXG4uZm9vdGVye1xuICBwb3NpdGlvbjogZml4ZWQ7XG4gIGJvdHRvbTogNGVtO1xuICB3aWR0aDogMTAwJTtcbn1cblxuaW9uLWJ1dHRvbntcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDoyZW07XG4gIGZvbnQtc2l6ZTogMS4yZW07XG4gIGJvcmRlci1yYWRpdXM6IDIwcHggMjBweCAyMHB4IDIwcHg7XG4gIGJvcmRlcjoxcHggc29saWQgI2U1ZTVlYTtcbiAgYm94LXNoYWRvdzogMHB4IDFweCAycHggIzAwMDAwMDtcbn1cbiJdfQ== */"]
});

/***/ }),

/***/ "gcE3":
/*!***************************************************!*\
  !*** ./src/app/forget-pass/forget-pass.module.ts ***!
  \***************************************************/
/*! exports provided: ForgetPassPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ForgetPassPageModule", function() { return ForgetPassPageModule; });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _forget_pass_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./forget-pass-routing.module */ "vHxN");
/* harmony import */ var _forget_pass_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./forget-pass.page */ "R0qC");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngx-translate/core */ "sYmb");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ "fXoL");







class ForgetPassPageModule {
}
ForgetPassPageModule.ɵfac = function ForgetPassPageModule_Factory(t) { return new (t || ForgetPassPageModule)(); };
ForgetPassPageModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineNgModule"]({ type: ForgetPassPageModule });
ForgetPassPageModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineInjector"]({ imports: [[
            _angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["IonicModule"],
            _forget_pass_routing_module__WEBPACK_IMPORTED_MODULE_3__["ForgetPassPageRoutingModule"],
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__["TranslateModule"]
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵsetNgModuleScope"](ForgetPassPageModule, { declarations: [_forget_pass_page__WEBPACK_IMPORTED_MODULE_4__["ForgetPassPage"]], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"],
        _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormsModule"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["IonicModule"],
        _forget_pass_routing_module__WEBPACK_IMPORTED_MODULE_3__["ForgetPassPageRoutingModule"],
        _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__["TranslateModule"]] }); })();


/***/ }),

/***/ "vHxN":
/*!***********************************************************!*\
  !*** ./src/app/forget-pass/forget-pass-routing.module.ts ***!
  \***********************************************************/
/*! exports provided: ForgetPassPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ForgetPassPageRoutingModule", function() { return ForgetPassPageRoutingModule; });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _forget_pass_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./forget-pass.page */ "R0qC");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");




const routes = [
    {
        path: '',
        component: _forget_pass_page__WEBPACK_IMPORTED_MODULE_1__["ForgetPassPage"]
    }
];
class ForgetPassPageRoutingModule {
}
ForgetPassPageRoutingModule.ɵfac = function ForgetPassPageRoutingModule_Factory(t) { return new (t || ForgetPassPageRoutingModule)(); };
ForgetPassPageRoutingModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineNgModule"]({ type: ForgetPassPageRoutingModule });
ForgetPassPageRoutingModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({ imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"].forChild(routes)], _angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsetNgModuleScope"](ForgetPassPageRoutingModule, { imports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]], exports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]] }); })();


/***/ })

}]);
//# sourceMappingURL=forget-pass-forget-pass-module.js.map