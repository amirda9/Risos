(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["process-process-module"],{

/***/ "/4kd":
/*!*******************************************!*\
  !*** ./src/app/process/process.module.ts ***!
  \*******************************************/
/*! exports provided: ProcessPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProcessPageModule", function() { return ProcessPageModule; });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _process_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./process-routing.module */ "aF+Q");
/* harmony import */ var _process_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./process.page */ "Zkag");
/* harmony import */ var _shared_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../shared.module */ "d2mR");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngx-translate/core */ "sYmb");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ "fXoL");








class ProcessPageModule {
}
ProcessPageModule.ɵfac = function ProcessPageModule_Factory(t) { return new (t || ProcessPageModule)(); };
ProcessPageModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineNgModule"]({ type: ProcessPageModule });
ProcessPageModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineInjector"]({ imports: [[
            _angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["IonicModule"],
            _process_routing_module__WEBPACK_IMPORTED_MODULE_3__["ProcessPageRoutingModule"],
            _shared_module__WEBPACK_IMPORTED_MODULE_5__["SharedModule"],
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__["TranslateModule"]
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵsetNgModuleScope"](ProcessPageModule, { declarations: [_process_page__WEBPACK_IMPORTED_MODULE_4__["ProcessPage"]], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"],
        _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormsModule"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["IonicModule"],
        _process_routing_module__WEBPACK_IMPORTED_MODULE_3__["ProcessPageRoutingModule"],
        _shared_module__WEBPACK_IMPORTED_MODULE_5__["SharedModule"],
        _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__["TranslateModule"]] }); })();


/***/ }),

/***/ "Zkag":
/*!*****************************************!*\
  !*** ./src/app/process/process.page.ts ***!
  \*****************************************/
/*! exports provided: ProcessPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProcessPage", function() { return ProcessPage; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _photoeditor_photoeditor_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../photoeditor/photoeditor.component */ "VfRE");


class ProcessPage {
    constructor() { }
    ngOnInit() {
    }
}
ProcessPage.ɵfac = function ProcessPage_Factory(t) { return new (t || ProcessPage)(); };
ProcessPage.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: ProcessPage, selectors: [["app-process"]], decls: 1, vars: 0, template: function ProcessPage_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "app-photoeditor");
    } }, directives: [_photoeditor_photoeditor_component__WEBPACK_IMPORTED_MODULE_1__["PhotoeditorComponent"]], styles: ["\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJwcm9jZXNzLnBhZ2Uuc2NzcyJ9 */"] });


/***/ }),

/***/ "aF+Q":
/*!***************************************************!*\
  !*** ./src/app/process/process-routing.module.ts ***!
  \***************************************************/
/*! exports provided: ProcessPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProcessPageRoutingModule", function() { return ProcessPageRoutingModule; });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _process_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./process.page */ "Zkag");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");




const routes = [
    {
        path: '',
        component: _process_page__WEBPACK_IMPORTED_MODULE_1__["ProcessPage"]
    }
];
class ProcessPageRoutingModule {
}
ProcessPageRoutingModule.ɵfac = function ProcessPageRoutingModule_Factory(t) { return new (t || ProcessPageRoutingModule)(); };
ProcessPageRoutingModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineNgModule"]({ type: ProcessPageRoutingModule });
ProcessPageRoutingModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({ imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"].forChild(routes)], _angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsetNgModuleScope"](ProcessPageRoutingModule, { imports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]], exports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]] }); })();


/***/ })

}]);
//# sourceMappingURL=process-process-module.js.map