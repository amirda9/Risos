(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["verify-verify-module"],{

/***/ "JqDU":
/*!*****************************************!*\
  !*** ./src/app/verify/verify.module.ts ***!
  \*****************************************/
/*! exports provided: VerifyPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VerifyPageModule", function() { return VerifyPageModule; });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _verify_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./verify-routing.module */ "qOy3");
/* harmony import */ var _verify_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./verify.page */ "ycC/");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ "fXoL");






class VerifyPageModule {
}
VerifyPageModule.ɵfac = function VerifyPageModule_Factory(t) { return new (t || VerifyPageModule)(); };
VerifyPageModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineNgModule"]({ type: VerifyPageModule });
VerifyPageModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineInjector"]({ imports: [[
            _angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["IonicModule"],
            _verify_routing_module__WEBPACK_IMPORTED_MODULE_3__["VerifyPageRoutingModule"]
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵsetNgModuleScope"](VerifyPageModule, { declarations: [_verify_page__WEBPACK_IMPORTED_MODULE_4__["VerifyPage"]], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"],
        _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormsModule"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["IonicModule"],
        _verify_routing_module__WEBPACK_IMPORTED_MODULE_3__["VerifyPageRoutingModule"]] }); })();


/***/ }),

/***/ "qOy3":
/*!*************************************************!*\
  !*** ./src/app/verify/verify-routing.module.ts ***!
  \*************************************************/
/*! exports provided: VerifyPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VerifyPageRoutingModule", function() { return VerifyPageRoutingModule; });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _verify_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./verify.page */ "ycC/");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");




const routes = [
    {
        path: '',
        component: _verify_page__WEBPACK_IMPORTED_MODULE_1__["VerifyPage"]
    }
];
class VerifyPageRoutingModule {
}
VerifyPageRoutingModule.ɵfac = function VerifyPageRoutingModule_Factory(t) { return new (t || VerifyPageRoutingModule)(); };
VerifyPageRoutingModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineNgModule"]({ type: VerifyPageRoutingModule });
VerifyPageRoutingModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({ imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"].forChild(routes)], _angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsetNgModuleScope"](VerifyPageRoutingModule, { imports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]], exports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]] }); })();


/***/ }),

/***/ "ycC/":
/*!***************************************!*\
  !*** ./src/app/verify/verify.page.ts ***!
  \***************************************/
/*! exports provided: VerifyPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VerifyPage", function() { return VerifyPage; });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ "qCKp");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var src_generated_graphql__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/generated/graphql */ "FJRG");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ "ofXK");







function VerifyPage_ion_label_18_Template(rf, ctx) { if (rf & 1) {
    const _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "ion-label", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function VerifyPage_ion_label_18_Template_ion_label_click_0_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r3); const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](); return ctx_r2.resend(); });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](1, " Resend Code");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} }
function VerifyPage_ion_label_19_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "ion-label", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" ", ctx_r1.time, " seconds");
} }
class VerifyPage {
    constructor(verify_userGQL, router, route, Req_otp) {
        this.verify_userGQL = verify_userGQL;
        this.router = router;
        this.route = route;
        this.Req_otp = Req_otp;
        this.trans_state = 1;
        this.source = Object(rxjs__WEBPACK_IMPORTED_MODULE_0__["timer"])(1000, 1000);
        this.duration = 60;
        this.time_left = true;
        // this.username = localStorage.getItem(USERNAME);
    }
    ngOnInit() {
        this.observableTimer();
        // console.log(this.time);
        this.route.queryParams.subscribe(params => {
            if (this.router.getCurrentNavigation().extras.state) {
                this.username = this.router.getCurrentNavigation().extras.state.s_id;
                this.trans_state = this.router.getCurrentNavigation().extras.state.trans_state;
            }
        });
    }
    resend() {
        if (!this.time_left) {
            this.Req_otp.mutate({
                username: this.username,
            }).subscribe(next => {
                console.log(next.data.requestOtp.status);
            });
        }
    }
    observableTimer() {
        this.subscription = this.source.subscribe(val => {
            if (val < this.duration) {
                this.time = this.duration - val;
                // console.log(this.time);
            }
            if (val == this.duration) {
                // console.log("reached")
                this.time_left = false;
                // this.TryAgain()
            }
            // console.log(this.time)
        });
    }
    ResCheck() {
        this.verify_userGQL.mutate({
            Username: this.username,
            Otp: this.code
        }).subscribe(next => {
            console.log(next.data.verifyUser.status);
            if (next.data.verifyUser.status == "success") {
                if (this.trans_state == 1) {
                    let navigationExtras = {
                        state: {
                            id: this.username
                        }
                    };
                    // this.valid = true;
                    this.router.navigate(['/reset-pass'], navigationExtras);
                }
                if (this.trans_state == 2) {
                    let navigationExtras = {
                        state: {
                            status: 0
                        }
                    };
                    // this.valid = true;
                    this.router.navigate(['/success'], navigationExtras);
                }
            }
            // if(next.data.verifyUser.status=="failed")
            else {
                // this.valid = false;
                // var el: HTMLElement = document.getElementById('form');
                // el.className = "not_valid";
                // el.classList.remove('valid');
                alert("رمز اشتباه وارد شده است.");
            }
        }, (error) => {
            alert("مشکلی در ارسال رمز یکبار مصرف ایجاد شده است لطفا دوباره امتحان کنید.");
        });
    }
}
VerifyPage.ɵfac = function VerifyPage_Factory(t) { return new (t || VerifyPage)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_generated_graphql__WEBPACK_IMPORTED_MODULE_2__["Verify_UserGQL"]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_generated_graphql__WEBPACK_IMPORTED_MODULE_2__["Req_OtpGQL"])); };
VerifyPage.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({ type: VerifyPage, selectors: [["app-verify"]], decls: 25, vars: 4, consts: [["translate", "", 1, "ion-text-center", 2, "color", "white"], ["slot", "start"], ["color", "light", "defaultHref", "home"], [1, "ion-justify-content-center", 2, "margin-top", "7em"], [1, "ion-justify-content-center", "ion-padding-horizontal", "ion-padding-bottom", 2, "padding-top", "0.3em"], ["size", "8", "size-lg", "8", 1, "ion-text-center"], ["translate", ""], [1, "ion-justify-content-center", "ion-padding-horizontal", "ion-padding-top", 2, "padding-top", "4em"], ["size", "12", "size-lg", "8", 1, "ion-text-left"], ["placeholder", "Code", 3, "ngModel", "ngModelChange"], [1, "ion-justify-content-center", "ion-padding-horizontal"], ["size", "12", "size-lg", "8", 1, "ion-text-center"], ["style", "font-size: 0.8em; color: #3eb5df;", 3, "click", 4, "ngIf"], ["style", "font-size: 0.8em; color: #3eb5df;", 4, "ngIf"], [1, "footer"], ["translate", "", "shape", "round", "translate", "", 2, "font-weight", "lighter", "text-transform", "none!important", "width", "100%", "color", "black", "--background", "#3abff8", 3, "click"], [2, "font-size", "0.8em", "color", "#3eb5df", 3, "click"], [2, "font-size", "0.8em", "color", "#3eb5df"]], template: function VerifyPage_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "ion-header");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "ion-toolbar");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](2, "ion-title", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](3, "Verify phone");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](4, "ion-buttons", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](5, "ion-back-button", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](6, "ion-content");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](7, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](8, "ion-grid");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](9, "ion-row", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](10, "ion-col", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](11, "ion-label", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](12);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](13, "ion-row", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](14, "ion-col", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](15, "ion-input", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ngModelChange", function VerifyPage_Template_ion_input_ngModelChange_15_listener($event) { return ctx.code = $event; });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](16, "ion-row", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](17, "ion-col", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](18, VerifyPage_ion_label_18_Template, 2, 0, "ion-label", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](19, VerifyPage_ion_label_19_Template, 2, 1, "ion-label", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](20, "div", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](21, "ion-row", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](22, "ion-col", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](23, "ion-button", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function VerifyPage_Template_ion_button_click_23_listener() { return ctx.ResCheck(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](24, " Continue ");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](12);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtextInterpolate1"](" Please type the verification code sent to ", ctx.username, " ");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngModel", ctx.code);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", !ctx.time_left);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.time_left);
    } }, directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonHeader"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonToolbar"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonTitle"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonButtons"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonBackButton"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonBackButtonDelegate"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonContent"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonGrid"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonRow"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonCol"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonLabel"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonInput"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["TextValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["NgControlStatus"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["NgModel"], _angular_common__WEBPACK_IMPORTED_MODULE_6__["NgIf"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonButton"]], styles: ["ion-toolbar[_ngcontent-%COMP%] {\n  --background:#6754a0;\n}\n\nion-input[_ngcontent-%COMP%] {\n  border: 1px solid #aaaaaa;\n  border-radius: 20px 20px 20px 20px;\n  --placeholder-color:#aaaaaa;\n  --background:#ffffff;\n}\n\nion-content[_ngcontent-%COMP%] {\n  --background:#f2f2f7;\n}\n\nion-button[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 2em;\n  font-size: 1.2em;\n  border-radius: 20px 20px 20px 20px;\n  border: 1px solid #e5e5ea;\n  box-shadow: 0px 1px 2px #000000;\n}\n\n.footer[_ngcontent-%COMP%] {\n  padding-top: 3em;\n  width: 100%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uL3ZlcmlmeS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxvQkFBQTtBQUNGOztBQUVBO0VBQ0UseUJBQUE7RUFDQSxrQ0FBQTtFQUNBLDJCQUFBO0VBQ0Esb0JBQUE7QUFDRjs7QUFHQTtFQUNFLG9CQUFBO0FBQUY7O0FBR0E7RUFDRSxXQUFBO0VBQ0EsV0FBQTtFQUNBLGdCQUFBO0VBQ0Esa0NBQUE7RUFDQSx5QkFBQTtFQUNBLCtCQUFBO0FBQUY7O0FBSUE7RUFDRSxnQkFBQTtFQUNBLFdBQUE7QUFERiIsImZpbGUiOiJ2ZXJpZnkucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLXRvb2xiYXJ7XG4gIC0tYmFja2dyb3VuZDojNjc1NGEwO1xufVxuXG5pb24taW5wdXR7XG4gIGJvcmRlcjoxcHggc29saWQgI2FhYWFhYTtcbiAgYm9yZGVyLXJhZGl1czogMjBweCAyMHB4IDIwcHggMjBweDtcbiAgLS1wbGFjZWhvbGRlci1jb2xvcjojYWFhYWFhO1xuICAtLWJhY2tncm91bmQ6I2ZmZmZmZjtcbn1cblxuXG5pb24tY29udGVudHtcbiAgLS1iYWNrZ3JvdW5kOiNmMmYyZjc7XG59XG5cbmlvbi1idXR0b257XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6MmVtO1xuICBmb250LXNpemU6IDEuMmVtO1xuICBib3JkZXItcmFkaXVzOiAyMHB4IDIwcHggMjBweCAyMHB4O1xuICBib3JkZXI6MXB4IHNvbGlkICNlNWU1ZWE7XG4gIGJveC1zaGFkb3c6IDBweCAxcHggMnB4ICMwMDAwMDA7XG59XG5cblxuLmZvb3RlcntcbiAgcGFkZGluZy10b3A6IDNlbTtcbiAgd2lkdGg6IDEwMCU7XG59XG4iXX0= */"] });


/***/ })

}]);
//# sourceMappingURL=verify-verify-module.js.map