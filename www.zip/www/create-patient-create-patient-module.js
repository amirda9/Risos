(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["create-patient-create-patient-module"],{

/***/ "6/gD":
/*!*******************************************!*\
  !*** ./src/app/services/photo.service.ts ***!
  \*******************************************/
/*! exports provided: PhotoService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PhotoService", function() { return PhotoService; });
/* harmony import */ var _home_mohammad_Work_RisosFront_Risos_node_modules_angular_devkit_build_angular_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@angular-devkit/build-angular/node_modules/@babel/runtime/helpers/esm/asyncToGenerator */ "20ZU");
/* harmony import */ var _capacitor_camera__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @capacitor/camera */ "/s3u");
/* harmony import */ var _capacitor_filesystem__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @capacitor/filesystem */ "F7bV");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");




class PhotoService {
  constructor() {
    this.photos = [];

    this.convertBlobToBase64 = blob => new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onerror = reject;

      reader.onload = () => {
        resolve(reader.result);
      };

      reader.readAsDataURL(blob);
    });
  }

  addNewToGallery() {
    var _this = this;

    return Object(_home_mohammad_Work_RisosFront_Risos_node_modules_angular_devkit_build_angular_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const capturedPhoto = yield _capacitor_camera__WEBPACK_IMPORTED_MODULE_1__["Camera"].getPhoto({
        resultType: _capacitor_camera__WEBPACK_IMPORTED_MODULE_1__["CameraResultType"].Uri,
        source: _capacitor_camera__WEBPACK_IMPORTED_MODULE_1__["CameraSource"].Camera,
        quality: 100
      }); // Save the picture and add it to photo collection

      const savedImageFile = yield _this.savePicture(capturedPhoto);

      _this.photos.unshift(savedImageFile);
    })();
  }

  savePicture(cameraPhoto) {
    var _this2 = this;

    return Object(_home_mohammad_Work_RisosFront_Risos_node_modules_angular_devkit_build_angular_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      // Convert photo to base64 format, required by Filesystem API to save
      const base64Data = yield _this2.readAsBase64(cameraPhoto); // Write the file to the data directory

      const fileName = new Date().getTime() + '.jpeg';
      const savedFile = yield _capacitor_filesystem__WEBPACK_IMPORTED_MODULE_2__["Filesystem"].writeFile({
        path: fileName,
        data: base64Data,
        directory: _capacitor_filesystem__WEBPACK_IMPORTED_MODULE_2__["Directory"].Data
      }); // Use webPath to display the new image instead of base64 since it's
      // already loaded into memory

      return {
        filepath: fileName,
        webviewPath: cameraPhoto.webPath
      };
    })();
  }

  readAsBase64(cameraPhoto) {
    var _this3 = this;

    return Object(_home_mohammad_Work_RisosFront_Risos_node_modules_angular_devkit_build_angular_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      // Fetch the photo, read as a blob, then convert to base64 format
      const response = yield fetch(cameraPhoto.webPath);
      const blob = yield response.blob();
      return yield _this3.convertBlobToBase64(blob);
    })();
  }

}

PhotoService.ɵfac = function PhotoService_Factory(t) {
  return new (t || PhotoService)();
};

PhotoService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjectable"]({
  token: PhotoService,
  factory: PhotoService.ɵfac,
  providedIn: 'root'
});

/***/ }),

/***/ "LHB0":
/*!*****************************************************************!*\
  !*** ./src/app/create-patient/create-patient-routing.module.ts ***!
  \*****************************************************************/
/*! exports provided: CreatePatientPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CreatePatientPageRoutingModule", function() { return CreatePatientPageRoutingModule; });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _create_patient_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./create-patient.page */ "oUKa");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");




const routes = [
    {
        path: '',
        component: _create_patient_page__WEBPACK_IMPORTED_MODULE_1__["CreatePatientPage"]
    }
];
class CreatePatientPageRoutingModule {
}
CreatePatientPageRoutingModule.ɵfac = function CreatePatientPageRoutingModule_Factory(t) { return new (t || CreatePatientPageRoutingModule)(); };
CreatePatientPageRoutingModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineNgModule"]({ type: CreatePatientPageRoutingModule });
CreatePatientPageRoutingModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({ imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"].forChild(routes)], _angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsetNgModuleScope"](CreatePatientPageRoutingModule, { imports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]], exports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]] }); })();


/***/ }),

/***/ "nHKr":
/*!*********************************************************!*\
  !*** ./src/app/create-patient/create-patient.module.ts ***!
  \*********************************************************/
/*! exports provided: CreatePatientPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CreatePatientPageModule", function() { return CreatePatientPageModule; });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _create_patient_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./create-patient-routing.module */ "LHB0");
/* harmony import */ var _create_patient_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./create-patient.page */ "oUKa");
/* harmony import */ var ngx_photo_editor__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ngx-photo-editor */ "kUS0");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngx-translate/core */ "sYmb");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ "fXoL");








class CreatePatientPageModule {
}
CreatePatientPageModule.ɵfac = function CreatePatientPageModule_Factory(t) { return new (t || CreatePatientPageModule)(); };
CreatePatientPageModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineNgModule"]({ type: CreatePatientPageModule });
CreatePatientPageModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineInjector"]({ imports: [[
            _angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["IonicModule"],
            _create_patient_routing_module__WEBPACK_IMPORTED_MODULE_3__["CreatePatientPageRoutingModule"],
            ngx_photo_editor__WEBPACK_IMPORTED_MODULE_5__["NgxPhotoEditorModule"],
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__["TranslateModule"]
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵsetNgModuleScope"](CreatePatientPageModule, { declarations: [_create_patient_page__WEBPACK_IMPORTED_MODULE_4__["CreatePatientPage"]], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"],
        _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormsModule"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["IonicModule"],
        _create_patient_routing_module__WEBPACK_IMPORTED_MODULE_3__["CreatePatientPageRoutingModule"],
        ngx_photo_editor__WEBPACK_IMPORTED_MODULE_5__["NgxPhotoEditorModule"],
        _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__["TranslateModule"]] }); })();


/***/ }),

/***/ "oUKa":
/*!*******************************************************!*\
  !*** ./src/app/create-patient/create-patient.page.ts ***!
  \*******************************************************/
/*! exports provided: CreatePatientPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CreatePatientPage", function() { return CreatePatientPage; });
/* harmony import */ var _home_mohammad_Work_RisosFront_Risos_node_modules_angular_devkit_build_angular_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@angular-devkit/build-angular/node_modules/@babel/runtime/helpers/esm/asyncToGenerator */ "20ZU");
/* harmony import */ var _capacitor_filesystem__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @capacitor/filesystem */ "F7bV");
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../constants */ "l207");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngx-translate/core */ "sYmb");
/* harmony import */ var _services_photo_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../services/photo.service */ "6/gD");
/* harmony import */ var src_generated_graphql__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/generated/graphql */ "FJRG");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var ngx_photo_editor__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ngx-photo-editor */ "kUS0");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/forms */ "3Pt+");













function CreatePatientPage_div_8_Template(rf, ctx) {
  if (rf & 1) {
    const _r6 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](1, "ion-row", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](2, "ion-col", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](3, "ion-button", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function CreatePatientPage_div_8_Template_ion_button_click_3_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r6);
      const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return ctx_r5.import();
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](4, " Import ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](5, "ion-row", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](6, "ion-col", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](7, "ion-button", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function CreatePatientPage_div_8_Template_ion_button_click_7_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r6);
      const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return ctx_r7.take();
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](8, " Take ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("disabled", ctx_r0.ios ? "" : null);
  }
}

function CreatePatientPage_div_9_ion_icon_8_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](0, "ion-icon", 26);
  }
}

function CreatePatientPage_div_9_img_9_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](0, "img", 27);
  }

  if (rf & 2) {
    const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("src", ctx_r9.base64, _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsanitizeUrl"]);
  }
}

function CreatePatientPage_div_9_ion_icon_19_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](0, "ion-icon", 26);
  }
}

function CreatePatientPage_div_9_img_20_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](0, "img", 27);
  }

  if (rf & 2) {
    const ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("src", ctx_r11.base64_2, _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsanitizeUrl"]);
  }
}

function CreatePatientPage_div_9_ion_icon_31_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](0, "ion-icon", 26);
  }
}

function CreatePatientPage_div_9_img_32_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](0, "img", 27);
  }

  if (rf & 2) {
    const ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("src", ctx_r13.base64_3, _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsanitizeUrl"]);
  }
}

function CreatePatientPage_div_9_ion_icon_42_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](0, "ion-icon", 26);
  }
}

function CreatePatientPage_div_9_img_43_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](0, "img", 27);
  }

  if (rf & 2) {
    const ctx_r15 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("src", ctx_r15.base64_4, _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsanitizeUrl"]);
  }
}

function CreatePatientPage_div_9_Template(rf, ctx) {
  if (rf & 1) {
    const _r17 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](1, "ion-grid");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](2, "ion-row");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](3, "ion-col", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](4, "ion-row");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](5, "input", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("change", function CreatePatientPage_div_9_Template_input_change_5_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r17);
      const ctx_r16 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return ctx_r16.fileChangeEvent($event);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](6, "ngx-photo-editor", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("imageCropped", function CreatePatientPage_div_9_Template_ngx_photo_editor_imageCropped_6_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r17);
      const ctx_r18 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return ctx_r18.imageCropped($event);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](7, "ion-button", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](8, CreatePatientPage_div_9_ion_icon_8_Template, 1, 0, "ion-icon", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](9, CreatePatientPage_div_9_img_9_Template, 1, 1, "img", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](10, "ion-row", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](11, "ion-button", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](12, "ion-label", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](13, " Frontal facial rested ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](14, "ion-col", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](15, "ion-row");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](16, "input", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("change", function CreatePatientPage_div_9_Template_input_change_16_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r17);
      const ctx_r19 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return ctx_r19.fileChangeEvent2($event);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](17, "ngx-photo-editor", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("imageCropped", function CreatePatientPage_div_9_Template_ngx_photo_editor_imageCropped_17_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r17);
      const ctx_r20 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return ctx_r20.imageCropped2($event);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](18, "ion-button", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](19, CreatePatientPage_div_9_ion_icon_19_Template, 1, 0, "ion-icon", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](20, CreatePatientPage_div_9_img_20_Template, 1, 1, "img", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](21, "ion-row", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](22, "ion-button", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](23, "ion-label", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](24, " Frontal facial smile ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](25, "ion-row");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](26, "ion-col", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](27, "ion-row");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](28, "input", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("change", function CreatePatientPage_div_9_Template_input_change_28_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r17);
      const ctx_r21 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return ctx_r21.fileChangeEvent3($event);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](29, "ngx-photo-editor", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("imageCropped", function CreatePatientPage_div_9_Template_ngx_photo_editor_imageCropped_29_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r17);
      const ctx_r22 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return ctx_r22.imageCropped3($event);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](30, "ion-button", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](31, CreatePatientPage_div_9_ion_icon_31_Template, 1, 0, "ion-icon", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](32, CreatePatientPage_div_9_img_32_Template, 1, 1, "img", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](33, "ion-row", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](34, "ion-button", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](35, "ion-label", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](36, " Frontal facial retracted ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](37, "ion-col", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](38, "ion-row");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](39, "input", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("change", function CreatePatientPage_div_9_Template_input_change_39_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r17);
      const ctx_r23 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return ctx_r23.fileChangeEvent4($event);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](40, "ngx-photo-editor", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("imageCropped", function CreatePatientPage_div_9_Template_ngx_photo_editor_imageCropped_40_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r17);
      const ctx_r24 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return ctx_r24.imageCropped4($event);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](41, "ion-button", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](42, CreatePatientPage_div_9_ion_icon_42_Template, 1, 0, "ion-icon", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](43, CreatePatientPage_div_9_img_43_Template, 1, 1, "img", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](44, "ion-row", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](45, "ion-button", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](46, "ion-label", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](47, " Profile facial rested ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](48, "div", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](49, "ion-row", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](50, "ion-col", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](51, "ion-button", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function CreatePatientPage_div_9_Template_ion_button_click_51_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r17);
      const ctx_r25 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return ctx_r25.next();
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](52, " Continue ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("imageChanedEvent", ctx_r1.imageChangedEvent)("viewMode", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", !ctx_r1.base64);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx_r1.base64);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("imageChanedEvent", ctx_r1.imageChangedEvent2)("viewMode", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", !ctx_r1.base64_2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx_r1.base64_2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("imageChanedEvent", ctx_r1.imageChangedEvent3)("viewMode", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", !ctx_r1.base64_3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx_r1.base64_3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("imageChanedEvent", ctx_r1.imageChangedEvent4)("viewMode", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", !ctx_r1.base64_4);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx_r1.base64_4);
  }
}

function CreatePatientPage_div_10_Template(rf, ctx) {
  if (rf & 1) {
    const _r27 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](1, "ion-grid");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](2, "ion-row", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](3, "ion-col", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](4, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](5, "ion-row", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](6, "ion-col", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](7, "ion-input", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("ngModelChange", function CreatePatientPage_div_10_Template_ion_input_ngModelChange_7_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r27);
      const ctx_r26 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return ctx_r26.name = $event;
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](8, "div", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](9, "ion-row", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](10, "ion-col", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](11, "ion-button", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function CreatePatientPage_div_10_Template_ion_button_click_11_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r27);
      const ctx_r28 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return ctx_r28.next();
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](12, " Continue ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngModel", ctx_r2.name);
  }
}

function CreatePatientPage_div_11_Template(rf, ctx) {
  if (rf & 1) {
    const _r30 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](1, "ion-grid");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](2, "ion-row", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](3, "ion-col", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](4, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](5, "ion-row", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](6, "ion-col", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](7, "ion-input", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("keyup", function CreatePatientPage_div_11_Template_ion_input_keyup_7_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r30);
      const ctx_r29 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return ctx_r29.checkPhone($event);
    })("ngModelChange", function CreatePatientPage_div_11_Template_ion_input_ngModelChange_7_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r30);
      const ctx_r31 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return ctx_r31.phone_no = $event;
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](8, "div", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](9, "ion-row", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](10, "ion-col", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](11, "ion-button", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function CreatePatientPage_div_11_Template_ion_button_click_11_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r30);
      const ctx_r32 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return ctx_r32.next();
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](12, " Continue ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("placeholder", ctx_r3.Pntranslated)("ngModel", ctx_r3.phone_no);
  }
}

function CreatePatientPage_div_12_Template(rf, ctx) {
  if (rf & 1) {
    const _r34 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](1, "ion-grid");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](2, "ion-row", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](3, "ion-col", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](4, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](5, "ion-row", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](6, "ion-col", 31);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](7, "ion-input", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("keyup", function CreatePatientPage_div_12_Template_ion_input_keyup_7_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r34);
      const ctx_r33 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return ctx_r33.check($event);
    })("ngModelChange", function CreatePatientPage_div_12_Template_ion_input_ngModelChange_7_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r34);
      const ctx_r35 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return ctx_r35.age = $event;
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](8, "div", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](9, "ion-row", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](10, "ion-col", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](11, "ion-button", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function CreatePatientPage_div_12_Template_ion_button_click_11_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r34);
      const ctx_r36 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return ctx_r36.save();
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](12, " Save ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngModel", ctx_r4.age);
  }
}

class CreatePatientPage {
  constructor(platform, translateService, photoService, createpatientgql, router, alertcontroller, loadingcontroller, route) {
    this.platform = platform;
    this.translateService = translateService;
    this.photoService = photoService;
    this.createpatientgql = createpatientgql;
    this.router = router;
    this.alertcontroller = alertcontroller;
    this.loadingcontroller = loadingcontroller;
    this.route = route;
    this.From_storage = false;

    this.fixNumbers = function (str) {
      var persianNumbers = [/۰/g, /۱/g, /۲/g, /۳/g, /۴/g, /۵/g, /۶/g, /۷/g, /۸/g, /۹/g];
      var arabicNumbers = [/٠/g, /١/g, /٢/g, /٣/g, /٤/g, /٥/g, /٦/g, /٧/g, /٨/g, /٩/g];

      if (typeof str === 'string') {
        for (var i = 0; i < 10; i++) {
          str = str.replace(persianNumbers[i], i).replace(arabicNumbers[i], i);
        }
      }

      return str;
    };

    this.route.queryParams.subscribe(params => {
      if (this.router.getCurrentNavigation().extras.state) {
        this.status = 1;
        this.From_storage = true;
      } else {
        this.status = -1;
      }
    });
  }

  ngOnInit() {
    this.Pntranslated = this.translateService.instant('Phone Number');
    this.ios = this.platform.is("ios");
    console.log(this.ios);
  }

  import() {
    this.status += 1;
  }

  take() {
    this.router.navigate(['/capturex']);
  }

  ngAfterViewInit() {// document.getElementById("img1").onchange = (e?: HTMLInputEvent)=> {
    //   var file1: any = e.target.files[0];
    //   this.img1 = file1;
    // }
    // document.getElementById("img2").onchange = (e?: HTMLInputEvent)=> {
    //   var file2: any = e.target.files[0];
    //   this.img2 = file2;
    // }
    // document.getElementById("img3").onchange = (e?: HTMLInputEvent)=> {
    //   var file3: any = e.target.files[0];
    //   this.img3 = file3;
    // }
    // document.getElementById("img4").onchange = (e?: HTMLInputEvent)=> {
    //   var file4: any = e.target.files[0];
    //   this.img4 = file4;
    // }
  }

  next() {
    var _this = this;

    return Object(_home_mohammad_Work_RisosFront_Risos_node_modules_angular_devkit_build_angular_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      switch (_this.status) {
        case 0:
          {
            _this.status += 1;
            break;
          }

        case 1:
          {
            //statements;
            console.log(_this.name);

            if (_this.name) {
              _this.status += 1;
              break;
            } else {
              const alert = yield _this.alertcontroller.create({
                cssClass: 'my-custom-class',
                // header: 'Alert',
                // subHeader: 'Subtitle',
                message: 'Please Enter Valid Name!',
                buttons: [{
                  text: 'Try Again!',
                  cssClass: 'my-custom-class',
                  handler: blah => {// this.router.navigate(['/tabs/patients'])
                  }
                }]
              });
              yield alert.present();
              break;
            } //  break;

          }

        case 2:
          {
            //statements;
            if (_this.phone_no) {
              _this.status += 1;
              break;
            } else {
              const alert = yield _this.alertcontroller.create({
                cssClass: 'my-custom-class',
                // header: 'Alert',
                // subHeader: 'Subtitle',
                message: 'Please Enter Valid Phone Number!',
                buttons: [{
                  text: 'Try Again!',
                  cssClass: 'my-custom-class',
                  handler: blah => {// this.router.navigate(['/tabs/patients'])
                  }
                }]
              });
              yield alert.present();
              break;
            }
          }

        case 3:
          {
            //statements;
            if (_this.age > 0 && _this.age < 100) {
              _this.status += 1;
              break;
            } else {
              const alert = yield _this.alertcontroller.create({
                cssClass: 'my-custom-class',
                // header: 'Alert',
                // subHeader: 'Subtitle',
                message: 'Please Enter Valid Age!',
                buttons: [{
                  text: 'Try Again!',
                  cssClass: 'my-custom-class',
                  handler: blah => {// this.router.navigate(['/tabs/patients'])
                  }
                }]
              });
              yield alert.present();
              break;
            }
          }
      }
    })();
  }

  heavy() {
    var _this2 = this;

    return Object(_home_mohammad_Work_RisosFront_Risos_node_modules_angular_devkit_build_angular_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const alert = yield _this2.alertcontroller.create({
        cssClass: 'my-custom-class',
        // header: 'Alert',
        // subHeader: 'Subtitle',
        message: 'File is too heavy',
        buttons: [{
          text: 'Try Again!',
          cssClass: 'my-custom-class',
          handler: blah => {}
        }]
      });
      yield alert.present();
    })();
  }

  fileChangeEvent(event) {
    this.imageChangedEvent = event;
  }

  imageCropped(event) {
    console.log(event.file.size);

    if (event.file.size > 4000000) {
      this.heavy();
    } else {
      this.img1 = event.file;
      this.base64 = event.base64;
    }
  }

  fileChangeEvent2(event) {
    // console.log('hi');
    this.imageChangedEvent2 = event;
  }

  imageCropped2(event) {
    if (event.file.size > 4000000) {
      this.heavy();
    } else {
      this.img2 = event.file;
      this.base64_2 = event.base64;
    }
  }

  fileChangeEvent3(event) {
    // console.log('hi');
    this.imageChangedEvent3 = event;
  }

  imageCropped3(event) {
    if (event.file.size > 4000000) {
      this.heavy();
    } else {
      this.img3 = event.file;
      this.base64_3 = event.base64;
    }
  }

  fileChangeEvent4(event) {
    // console.log('hi');
    this.imageChangedEvent4 = event;
  }

  imageCropped4(event) {
    if (event.file.size > 4000000) {
      this.heavy();
    } else {
      this.img4 = event.file;
      this.base64_4 = event.base64;
    }
  }

  cleanStorage() {
    return Object(_home_mohammad_Work_RisosFront_Risos_node_modules_angular_devkit_build_angular_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      for (let i = 1; i < 5; i = i + 1) {
        // console.log(i)
        if (localStorage.getItem('photos_' + i)) {
          const removeFile = yield _capacitor_filesystem__WEBPACK_IMPORTED_MODULE_1__["Filesystem"].deleteFile({
            path: localStorage.getItem('photos_' + i),
            directory: _capacitor_filesystem__WEBPACK_IMPORTED_MODULE_1__["Directory"].Data
          });
          localStorage.removeItem('photos_' + i);
        }
      }
    })();
  }

  ngOnDestroy() {
    // console.log("destroy")
    this.cleanStorage();
  } // button(){
  //   const button1 = document.getElementById('button1');
  //   button1.style.backgroundImage =  this.base64;
  // }


  save() {
    var _this3 = this;

    return Object(_home_mohammad_Work_RisosFront_Risos_node_modules_angular_devkit_build_angular_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (_this3.From_storage) {
        _this3.img1 = localStorage.getItem('photos_1');
        _this3.img2 = localStorage.getItem('photos_2');
        _this3.img3 = localStorage.getItem('photos_3');
        _this3.img4 = localStorage.getItem('photos_4');

        if (_this3.img1) {
          var readFile = yield _capacitor_filesystem__WEBPACK_IMPORTED_MODULE_1__["Filesystem"].readFile({
            path: _this3.img1,
            directory: _capacitor_filesystem__WEBPACK_IMPORTED_MODULE_1__["Directory"].Data
          });
          _this3.img1 = readFile.data;
        } // console.log(this.im


        if (_this3.img2) {
          var readFile2 = yield _capacitor_filesystem__WEBPACK_IMPORTED_MODULE_1__["Filesystem"].readFile({
            path: _this3.img2,
            directory: _capacitor_filesystem__WEBPACK_IMPORTED_MODULE_1__["Directory"].Data
          });
          _this3.img2 = readFile2.data;
        }

        if (_this3.img3) {
          console.log(_this3.img3);
          var readFile3 = yield _capacitor_filesystem__WEBPACK_IMPORTED_MODULE_1__["Filesystem"].readFile({
            path: _this3.img3,
            directory: _capacitor_filesystem__WEBPACK_IMPORTED_MODULE_1__["Directory"].Data
          });
          _this3.img3 = readFile3.data;
        }

        if (_this3.img4) {
          console.log("amir");
          console.log(_this3.img4);
          var readFile4 = yield _capacitor_filesystem__WEBPACK_IMPORTED_MODULE_1__["Filesystem"].readFile({
            path: _this3.img4,
            directory: _capacitor_filesystem__WEBPACK_IMPORTED_MODULE_1__["Directory"].Data
          });
          _this3.img4 = readFile4.data;
        }
      }

      const loading = yield _this3.loadingcontroller.create({
        message: 'Loading ...',
        duration: 2000
      });
      loading.present();
      var variable = localStorage.getItem(_constants__WEBPACK_IMPORTED_MODULE_2__["ID"]);
      var variable2 = +variable;
      var my_age = +_this3.age;

      _this3.createpatientgql.mutate({
        Name: _this3.name,
        id: variable2,
        age: my_age,
        Phone_no: _this3.phone_no,
        // Profile:this.pro_pic,
        Pics: {
          smileImage: _this3.img1,
          sideImage: _this3.img2,
          fullSmileImage: _this3.img3,
          optionalImage: _this3.img4
        }
      }).subscribe(next => {
        // console.log(next);
        if (next.data.createPatient.token != null) {
          loading.dismiss();

          _this3.router.navigate(['/tabs/patients']); // console.log(this.username)

        }
      });
    })();
  }

  check(ev) {// const ew = ev.key.charCodeAt();
    // if(!this.age){
    //   alert("لطفا زبان خود را عوض کنید")
    //   this.age=0;
    // }// TS will throw an error here
    // else{
    //   console.log(this.age) 
    // }
    // this.age = this.fixNumbers(this.age);
  } // check(evt){
  //   this.phone_no = this.fixNumbers(this.phone_no);
  // }


  checkPhone(ev) {
    // const ew = ev.key.charCodeAt();
    // if(!this.phone_no){
    //   alert("لطفا زبان خود را عوض کنید")
    //   this.phone_no ="0";
    // }// TS will throw an error here
    // else{
    //   // console.log(this.age) 
    // }
    this.phone_no = this.fixNumbers(this.phone_no);
  }

  addPhotoToGallery() {
    this.photoService.addNewToGallery();
  }

}

CreatePatientPage.ɵfac = function CreatePatientPage_Factory(t) {
  return new (t || CreatePatientPage)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_4__["Platform"]), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__["TranslateService"]), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_services_photo_service__WEBPACK_IMPORTED_MODULE_6__["PhotoService"]), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](src_generated_graphql__WEBPACK_IMPORTED_MODULE_7__["CreatepatientGQL"]), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_8__["Router"]), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"]), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_4__["LoadingController"]), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_8__["ActivatedRoute"]));
};

CreatePatientPage.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
  type: CreatePatientPage,
  selectors: [["app-create-patient"]],
  decls: 13,
  vars: 6,
  consts: [["translate", "", 2, "color", "white"], ["slot", "start"], ["color", "light", "defaultHref", "tabs/patients"], [3, "ngSwitch"], ["class", "ion-justify-content-center", "style", "margin-top: 7em", 4, "ngSwitchCase"], [1, "ion-justify-content-center", 2, "margin-top", "7em"], [1, "ion-justify-content-center", "ion-padding-horizontal"], ["size", "12", "size-lg", "8", 1, "ion-text-center"], ["shape", "round", "translate", "", 2, "font-weight", "lighter", "text-transform", "none !important", "width", "100%", "color", "black", "--background", "#3abff8", 3, "click"], ["shape", "round", "translate", "", 2, "font-weight", "lighter", "text-transform", "none !important", "width", "100%", "color", "black", "--background", "#3abff8", 3, "disabled", "click"], ["size", "6", 1, "ion-text-center"], ["id", "getFile", "type", "file", "accept", "image/png, image/jpg, image/jpeg", 2, "display", "none", 3, "change"], [3, "imageChanedEvent", "viewMode", "imageCropped"], ["id", "button1", "onclick", "document.getElementById('getFile').click()", 2, "--background", "#e2e2e2", "--border-radius", "4px 4px 4px 4px", "border-radius", "4px 4px 4px 4px", "height", "6em"], ["name", "add", "style", "color: #383838; margin-top: -1em", 4, "ngIf"], ["alt", "", "style", "width: 100%", 3, "src", 4, "ngIf"], [2, "margin-top", "-3em"], [2, "--background", "#ffffff", "--border-radius", "4px 4px 4px 4px", "border-radius", "0px 0px 4px 4px", "height", "2em"], ["translate", "", 2, "color", "black", "font-size", "0.5em"], ["id", "getFile2", "type", "file", "accept", "image/png, image/jpg, image/jpeg", 2, "display", "none", 3, "change"], ["id", "button2", "onclick", "document.getElementById('getFile2').click()", 2, "--background", "#e2e2e2", "border-radius", "4px 4px 4px 4px", "height", "6em"], ["id", "getFile3", "type", "file", "accept", "image/png, image/jpg, image/jpeg", 2, "display", "none", 3, "change"], ["id", "button3", "onclick", "document.getElementById('getFile3').click()", 2, "--background", "#e2e2e2", "--border-radius", "4px 4px 4px 4px", "border-radius", "4px 4px 4px 4px", "height", "6em"], ["id", "getFile4", "type", "file", "accept", "image/png, image/jpg, image/jpeg", 2, "display", "none", 3, "change"], ["id", "button4", "onclick", "document.getElementById('getFile4').click()", 2, "--background", "#e2e2e2", "border-radius", "4px 4px 4px 4px", "height", "6em"], [1, "footer"], ["name", "add", 2, "color", "#383838", "margin-top", "-1em"], ["alt", "", 2, "width", "100%", 3, "src"], [1, "ion-justify-content-center", "ion-padding-horizontal", "ion-padding-bottom", 2, "padding-top", "0.3em"], ["size", "8", "size-lg", "8", 1, "ion-text-center"], [1, "ion-justify-content-center", "ion-padding-horizontal", "ion-padding-top", 2, "padding-top", "4em"], ["size", "12", "size-lg", "8", 1, "ion-text-left"], ["placeholder", "Patient Name", 3, "ngModel", "ngModelChange"], [3, "placeholder", "ngModel", "keyup", "ngModelChange"], ["placeholder", "Age", "type", "number", 3, "ngModel", "keyup", "ngModelChange"], ["shape", "round", 2, "font-weight", "lighter", "text-transform", "none !important", "width", "100%", "color", "black", "--background", "#3abff8", 3, "click"]],
  template: function CreatePatientPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-header");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](1, "ion-toolbar");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](2, "ion-title", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](3, "New Patient");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](4, "ion-buttons", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](5, "ion-back-button", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](6, "ion-content");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](7, "div", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](8, CreatePatientPage_div_8_Template, 9, 1, "div", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](9, CreatePatientPage_div_9_Template, 53, 16, "div", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](10, CreatePatientPage_div_10_Template, 13, 1, "div", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](11, CreatePatientPage_div_11_Template, 13, 2, "div", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](12, CreatePatientPage_div_12_Template, 13, 1, "div", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](7);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngSwitch", ctx.status);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngSwitchCase", -1);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngSwitchCase", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngSwitchCase", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngSwitchCase", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngSwitchCase", 3);
    }
  },
  directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonHeader"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonToolbar"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonTitle"], _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__["TranslateDirective"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonButtons"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonBackButton"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonBackButtonDelegate"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonContent"], _angular_common__WEBPACK_IMPORTED_MODULE_9__["NgSwitch"], _angular_common__WEBPACK_IMPORTED_MODULE_9__["NgSwitchCase"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonRow"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonCol"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonButton"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonGrid"], ngx_photo_editor__WEBPACK_IMPORTED_MODULE_10__["NgxPhotoEditorComponent"], _angular_common__WEBPACK_IMPORTED_MODULE_9__["NgIf"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonLabel"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonIcon"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonInput"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["TextValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_11__["NgControlStatus"], _angular_forms__WEBPACK_IMPORTED_MODULE_11__["NgModel"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NumericValueAccessor"]],
  styles: ["ion-toolbar[_ngcontent-%COMP%] {\n  --background: #0000ff;\n}\n\nion-content[_ngcontent-%COMP%] {\n  --background:#f2f2f7;\n}\n\nion-input[_ngcontent-%COMP%] {\n  border: 1px solid #aaaaaa;\n  border-radius: 20px 20px 20px 20px;\n  --placeholder-color:#aaaaaa;\n  --background:#ffffff;\n  --padding-start:0.5em;\n}\n\nion-content[_ngcontent-%COMP%] {\n  --background:#f2f2f7;\n}\n\nion-button[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 2em;\n  font-size: 1.2em;\n  border-radius: 20px 20px 20px 20px;\n  border: 1px solid #e5e5ea;\n  box-shadow: 0px 1px 2px #000000;\n}\n\n.footer[_ngcontent-%COMP%] {\n  position: fixed;\n  bottom: 4em;\n  width: 100%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uL2NyZWF0ZS1wYXRpZW50LnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHFCQUFBO0FBQ0Y7O0FBRUE7RUFDRSxvQkFBQTtBQUNGOztBQUVBO0VBQ0UseUJBQUE7RUFDQSxrQ0FBQTtFQUNBLDJCQUFBO0VBQ0Esb0JBQUE7RUFDQSxxQkFBQTtBQUNGOztBQUdBO0VBQ0Usb0JBQUE7QUFBRjs7QUFHQTtFQUNFLFdBQUE7RUFDQSxXQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQ0FBQTtFQUNBLHlCQUFBO0VBQ0EsK0JBQUE7QUFBRjs7QUFJQTtFQUNFLGVBQUE7RUFDQSxXQUFBO0VBQ0EsV0FBQTtBQURGIiwiZmlsZSI6ImNyZWF0ZS1wYXRpZW50LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi10b29sYmFyIHtcbiAgLS1iYWNrZ3JvdW5kOiAjMDAwMGZmO1xufVxuXG5pb24tY29udGVudHtcbiAgLS1iYWNrZ3JvdW5kOiNmMmYyZjc7XG59XG5cbmlvbi1pbnB1dHtcbiAgYm9yZGVyOjFweCBzb2xpZCAjYWFhYWFhO1xuICBib3JkZXItcmFkaXVzOiAyMHB4IDIwcHggMjBweCAyMHB4O1xuICAtLXBsYWNlaG9sZGVyLWNvbG9yOiNhYWFhYWE7XG4gIC0tYmFja2dyb3VuZDojZmZmZmZmO1xuICAtLXBhZGRpbmctc3RhcnQ6MC41ZW07XG59XG5cblxuaW9uLWNvbnRlbnR7XG4gIC0tYmFja2dyb3VuZDojZjJmMmY3O1xufVxuXG5pb24tYnV0dG9ue1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OjJlbTtcbiAgZm9udC1zaXplOiAxLjJlbTtcbiAgYm9yZGVyLXJhZGl1czogMjBweCAyMHB4IDIwcHggMjBweDtcbiAgYm9yZGVyOjFweCBzb2xpZCAjZTVlNWVhO1xuICBib3gtc2hhZG93OiAwcHggMXB4IDJweCAjMDAwMDAwO1xufVxuXG5cbi5mb290ZXJ7XG4gIHBvc2l0aW9uOiBmaXhlZDtcbiAgYm90dG9tOiA0ZW07XG4gIHdpZHRoOiAxMDAlO1xufVxuXG5cbi8vIC5teV9PdmVybGF5e1xuLy8gICB3aWR0aDogMTAwJTtcbi8vICAgaGVpZ2h0OiAzMCU7XG4vLyAgIC8vIHBhZGRpbmctdG9wOjUlO1xuLy8gICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4vLyAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbi8vICAgei1pbmRleDogOTk7XG4vLyAgIGJvdHRvbTogMzAlO1xuLy8gICB0b3A6NzAlO1xuLy8gICBvcGFjaXR5OiAxO1xuLy8gICBjb2xvcjogYmxhY2s7XG4vLyAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuLy8gICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcbi8vICAgLy8gYm9yZGVyLXJhZGl1czogMHB4IDBweCAyMHB4IDIwcHg7XG4vLyAgIC8vIGJhY2tkcm9wLWZpbHRlcjogcGVyY2VudGFnZSgkbnVtYmVyOiA1MCk7XG4vLyAgIG1hcmdpbi1ib3R0b206IDA7XG4vLyB9XG4iXX0= */"]
});

/***/ })

}]);
//# sourceMappingURL=create-patient-create-patient-module.js.map