(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["capturex-capturex-module"],{

/***/ "X8VC":
/*!*********************************************!*\
  !*** ./src/app/capturex/capturex.module.ts ***!
  \*********************************************/
/*! exports provided: CapturexPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CapturexPageModule", function() { return CapturexPageModule; });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _capturex_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./capturex-routing.module */ "fzfW");
/* harmony import */ var _capturex_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./capturex.page */ "lEgC");
/* harmony import */ var _shared_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../shared.module */ "d2mR");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngx-translate/core */ "sYmb");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ "fXoL");








class CapturexPageModule {
}
CapturexPageModule.ɵfac = function CapturexPageModule_Factory(t) { return new (t || CapturexPageModule)(); };
CapturexPageModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineNgModule"]({ type: CapturexPageModule });
CapturexPageModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineInjector"]({ imports: [[
            _angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["IonicModule"],
            _capturex_routing_module__WEBPACK_IMPORTED_MODULE_3__["CapturexPageRoutingModule"],
            _shared_module__WEBPACK_IMPORTED_MODULE_5__["SharedModule"], _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__["TranslateModule"]
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵsetNgModuleScope"](CapturexPageModule, { declarations: [_capturex_page__WEBPACK_IMPORTED_MODULE_4__["CapturexPage"]], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"],
        _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormsModule"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["IonicModule"],
        _capturex_routing_module__WEBPACK_IMPORTED_MODULE_3__["CapturexPageRoutingModule"],
        _shared_module__WEBPACK_IMPORTED_MODULE_5__["SharedModule"], _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__["TranslateModule"]] }); })();


/***/ }),

/***/ "fzfW":
/*!*****************************************************!*\
  !*** ./src/app/capturex/capturex-routing.module.ts ***!
  \*****************************************************/
/*! exports provided: CapturexPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CapturexPageRoutingModule", function() { return CapturexPageRoutingModule; });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _capturex_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./capturex.page */ "lEgC");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");




const routes = [
    {
        path: '',
        component: _capturex_page__WEBPACK_IMPORTED_MODULE_1__["CapturexPage"]
    }
];
class CapturexPageRoutingModule {
}
CapturexPageRoutingModule.ɵfac = function CapturexPageRoutingModule_Factory(t) { return new (t || CapturexPageRoutingModule)(); };
CapturexPageRoutingModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineNgModule"]({ type: CapturexPageRoutingModule });
CapturexPageRoutingModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({ imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"].forChild(routes)], _angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsetNgModuleScope"](CapturexPageRoutingModule, { imports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]], exports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]] }); })();


/***/ }),

/***/ "lEgC":
/*!*******************************************!*\
  !*** ./src/app/capturex/capturex.page.ts ***!
  \*******************************************/
/*! exports provided: CapturexPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CapturexPage", function() { return CapturexPage; });
/* harmony import */ var _home_mohammad_Work_RisosFront_Risos_node_modules_angular_devkit_build_angular_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@angular-devkit/build-angular/node_modules/@babel/runtime/helpers/esm/asyncToGenerator */ "20ZU");
/* harmony import */ var _capacitor_community_camera_preview__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @capacitor-community/camera-preview */ "SFQQ");
/* harmony import */ var _capacitor_filesystem__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @capacitor/filesystem */ "F7bV");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngx-translate/core */ "sYmb");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ "ofXK");









function CapturexPage_div_7_ion_icon_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](0, "ion-icon", 15);
  }
}

function CapturexPage_div_7_ion_icon_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](0, "ion-icon", 16);
  }
}

function CapturexPage_div_7_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "div", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](1, CapturexPage_div_7_ion_icon_1_Template, 1, 0, "ion-icon", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](2, "div", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](3, CapturexPage_div_7_ion_icon_3_Template, 1, 0, "ion-icon", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx_r0.cameraActive);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx_r0.cameraActive);
  }
}

function CapturexPage_ion_img_8_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](0, "ion-img", 17);
  }

  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("src", ctx_r1.myImage);
  }
}

function CapturexPage_ion_button_9_Template(rf, ctx) {
  if (rf & 1) {
    const _r10 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-button", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function CapturexPage_ion_button_9_Template_ion_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r10);
      const ctx_r9 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return ctx_r9.openCamera();
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, " Open Camera ");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
}

function CapturexPage_ion_col_12_Template(rf, ctx) {
  if (rf & 1) {
    const _r12 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-col");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](1, "ion-button", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function CapturexPage_ion_col_12_Template_ion_button_click_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r12);
      const ctx_r11 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return ctx_r11.submit();
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](2, "Submit Images");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
}

function CapturexPage_ion_col_13_ion_button_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r15 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-button", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function CapturexPage_ion_col_13_ion_button_1_Template_ion_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r15);
      const ctx_r14 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](2);
      return ctx_r14.captureCamera();
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    const ctx_r13 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtextInterpolate1"](" Take Picture Number ", ctx_r13.count, " ");
  }
}

function CapturexPage_ion_col_13_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-col");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](1, CapturexPage_ion_col_13_ion_button_1_Template, 2, 1, "ion-button", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx_r4.cameraActive && ctx_r4.count != 5);
  }
}

function CapturexPage_ion_button_17_Template(rf, ctx) {
  if (rf & 1) {
    const _r17 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-button", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function CapturexPage_ion_button_17_Template_ion_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r17);
      const ctx_r16 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return ctx_r16.saveImage();
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, " Save");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
}

function CapturexPage_ion_button_19_Template(rf, ctx) {
  if (rf & 1) {
    const _r19 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-button", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("click", function CapturexPage_ion_button_19_Template_ion_button_click_0_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r19);
      const ctx_r18 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return ctx_r18.redoImage();
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](1, "Try Again");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
  }
}

class CapturexPage {
  constructor(router) {
    this.router = router;
    this.close_icon = true;
    this.myImage = null;
    this.cameraActive = false;
    this.result = null;
    this.count = 1;
  }

  ngOnInit() {// this.cleanStorage();
  }

  cleanStorage() {
    return Object(_home_mohammad_Work_RisosFront_Risos_node_modules_angular_devkit_build_angular_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      for (let i = 1; i < 5; i = i + 1) {
        if (localStorage.getItem('photos_' + i)) {
          const removeFile = yield _capacitor_filesystem__WEBPACK_IMPORTED_MODULE_2__["Filesystem"].deleteFile({
            path: localStorage.getItem('photos_' + i),
            directory: _capacitor_filesystem__WEBPACK_IMPORTED_MODULE_2__["Directory"].Data
          });
          localStorage.removeItem('photos_' + i);
          localStorage.removeItem('photos_4');
        }
      }
    })();
  }

  savePicture(value) {
    return Object(_home_mohammad_Work_RisosFront_Risos_node_modules_angular_devkit_build_angular_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      // Convert photo to base64 format, required by Filesystem API to save
      // Write the file to the data directory
      const base64Data = value; // Write the file to the data directory
      // const fileName = new Date().getTime() + '.png';

      const fileName = new Date().getTime() + '.png';
      const savedFile = yield _capacitor_filesystem__WEBPACK_IMPORTED_MODULE_2__["Filesystem"].writeFile({
        path: fileName,
        data: base64Data,
        directory: _capacitor_filesystem__WEBPACK_IMPORTED_MODULE_2__["Directory"].Data,
        recursive: true
      }); // Use webPath to display the new image instead of base64 since it's
      // already loaded into memory

      return {
        filepath: fileName
      };
    })();
  }

  openCamera() {
    const cameraPreviewOptions = {
      position: 'rear',
      parent: 'cameraPreview',
      className: 'cameraPreview',
      disableAudio: false,
      storeToFile: true
    };
    _capacitor_community_camera_preview__WEBPACK_IMPORTED_MODULE_1__["CameraPreview"].start(cameraPreviewOptions);
    this.cameraActive = true;
  }

  captureCamera() {
    var _this = this;

    return Object(_home_mohammad_Work_RisosFront_Risos_node_modules_angular_devkit_build_angular_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const cameraPreviewPictureOptions = {
        quality: 100
      };
      _this.result = yield _capacitor_community_camera_preview__WEBPACK_IMPORTED_MODULE_1__["CameraPreview"].capture(cameraPreviewPictureOptions);
      _this.result = yield _this.savePicture(_this.result.value);
      const readFile = yield _capacitor_filesystem__WEBPACK_IMPORTED_MODULE_2__["Filesystem"].readFile({
        path: _this.result.filepath,
        directory: _capacitor_filesystem__WEBPACK_IMPORTED_MODULE_2__["Directory"].Data
      });
      _this.myImage = `data:image/png;base64,${readFile.data}`; // this.myImage=this.result;

      _this.cameraActive = false;
      _this.count = _this.count + 1;
      _capacitor_community_camera_preview__WEBPACK_IMPORTED_MODULE_1__["CameraPreview"].stop();
    })();
  }

  saveImage() {
    var _this2 = this;

    return Object(_home_mohammad_Work_RisosFront_Risos_node_modules_angular_devkit_build_angular_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      localStorage.setItem('photos_' + (_this2.count - 1), _this2.result.filepath);

      if (_this2.count != 5) {
        _this2.openCamera();
      } else {
        _this2.cameraActive = false;
      }
    })();
  }

  redoImage() {
    var _this3 = this;

    return Object(_home_mohammad_Work_RisosFront_Risos_node_modules_angular_devkit_build_angular_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const removeFile = yield _capacitor_filesystem__WEBPACK_IMPORTED_MODULE_2__["Filesystem"].deleteFile({
        path: _this3.result.filepath,
        directory: _capacitor_filesystem__WEBPACK_IMPORTED_MODULE_2__["Directory"].Data
      });
      _this3.count = _this3.count - 1;

      _this3.openCamera();
    })();
  }

  submit() {
    var _this4 = this;

    return Object(_home_mohammad_Work_RisosFront_Risos_node_modules_angular_devkit_build_angular_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this4.cameraActive = false; // console.log("submit");

      _capacitor_community_camera_preview__WEBPACK_IMPORTED_MODULE_1__["CameraPreview"].stop();
      let navigationExtras = {
        state: {
          status: 1
        }
      };

      _this4.router.navigate(['/create-patient'], navigationExtras); // at the end may be?
      // this.cleanStorage();

    })();
  }

}

CapturexPage.ɵfac = function CapturexPage_Factory(t) {
  return new (t || CapturexPage)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"]));
};

CapturexPage.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
  type: CapturexPage,
  selectors: [["app-capturex"]],
  decls: 20,
  vars: 7,
  consts: [["slot", "start"], ["color", "light", "defaultHref", "create-patient"], ["translate", "", 2, "color", "white", "text-align", "center"], [1, "ic"], ["id", "cameraPreview", "class", "cameraPreview", 4, "ngIf"], [3, "src", 4, "ngIf"], ["expand", "full", "translate", "", 3, "click", 4, "ngIf"], ["fixed", ""], [4, "ngIf"], ["color", "success", "expand", "full", "translate", "", 3, "click", 4, "ngIf"], ["color", "danger", "expand", "full", "translate", "", 3, "click", 4, "ngIf"], ["id", "cameraPreview", 1, "cameraPreview"], ["name", "close", "slot", "start", "id", "close", 4, "ngIf"], [2, "font-size", "45px"], ["size", "large", "name", "square-outline", "id", "close", "style", "color:white; position: absolute; left:40%; top:30%;", 4, "ngIf"], ["name", "close", "slot", "start", "id", "close"], ["size", "large", "name", "square-outline", "id", "close", 2, "color", "white", "position", "absolute", "left", "40%", "top", "30%"], [3, "src"], ["expand", "full", "translate", "", 3, "click"], ["color", "success", "expand", "full", "translate", "", 3, "click"], ["color", "primary", "expand", "full", "translate", "", 3, "click", 4, "ngIf"], ["color", "primary", "expand", "full", "translate", "", 3, "click"], ["color", "danger", "expand", "full", "translate", "", 3, "click"]],
  template: function CapturexPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ion-header");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](1, "ion-toolbar");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](2, "ion-buttons", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](3, "ion-back-button", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](4, "ion-title", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtext"](5, " Camera Module ");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](6, "ion-content", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](7, CapturexPage_div_7_Template, 4, 2, "div", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](8, CapturexPage_ion_img_8_Template, 1, 1, "ion-img", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](9, CapturexPage_ion_button_9_Template, 2, 0, "ion-button", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](10, "ion-grid", 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](11, "ion-row");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](12, CapturexPage_ion_col_12_Template, 3, 0, "ion-col", 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](13, CapturexPage_ion_col_13_Template, 2, 1, "ion-col", 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](14, "ion-grid", 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](15, "ion-row");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](16, "ion-col");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](17, CapturexPage_ion_button_17_Template, 2, 0, "ion-button", 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](18, "ion-col");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](19, CapturexPage_ion_button_19_Template, 2, 0, "ion-button", 10);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](7);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.cameraActive);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.myImage && !ctx.cameraActive);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", !ctx.cameraActive && ctx.count === 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.cameraActive && ctx.count > 1 || ctx.count == 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.count != 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.myImage && !ctx.cameraActive && ctx.count != 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.myImage && !ctx.cameraActive && ctx.count != 6);
    }
  },
  directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonHeader"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonToolbar"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonButtons"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonBackButton"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonBackButtonDelegate"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonTitle"], _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__["TranslateDirective"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonContent"], _angular_common__WEBPACK_IMPORTED_MODULE_7__["NgIf"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonGrid"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonRow"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonCol"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonIcon"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonImg"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonButton"]],
  styles: ["ion-toolbar[_ngcontent-%COMP%] {\n  --background: #0000ff;\n}\n\nion-content[_ngcontent-%COMP%] {\n  --background:#f2f2f7;\n}\n\n#container[_ngcontent-%COMP%] {\n  text-align: center;\n  position: absolute;\n  left: 0;\n  right: 0;\n  top: 50%;\n  transform: translateY(-50%);\n}\n\n#container[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%] {\n  font-size: 20px;\n  line-height: 26px;\n}\n\n#container[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  font-size: 16px;\n  line-height: 22px;\n  color: #8c8c8c;\n  margin: 0;\n}\n\n#container[_ngcontent-%COMP%]   a[_ngcontent-%COMP%] {\n  text-decoration: none;\n}\n\n#video[_ngcontent-%COMP%] {\n  width: 100% !important;\n  height: 100% !important;\n}\n\n#ic[_ngcontent-%COMP%] {\n  background: transparent !important;\n}\n\n.cameraPreview[_ngcontent-%COMP%] {\n  display: flex;\n}\n\n.cameraPreview2[_ngcontent-%COMP%] {\n  display: flex;\n}\n\n.overlay[_ngcontent-%COMP%] {\n  width: 100%;\n  height: 100%;\n  z-index: 10;\n}\n\n#close[_ngcontent-%COMP%] {\n  position: absolute;\n  width: 100px;\n  height: 100px;\n  top: 0px;\n  left: 0px;\n  z-index: 1;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uL2NhcHR1cmV4LnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHFCQUFBO0FBQ0Y7O0FBRUE7RUFDRSxvQkFBQTtBQUNGOztBQUdBO0VBQ0ksa0JBQUE7RUFFQSxrQkFBQTtFQUNBLE9BQUE7RUFDQSxRQUFBO0VBQ0EsUUFBQTtFQUNBLDJCQUFBO0FBREo7O0FBSUU7RUFDRSxlQUFBO0VBQ0EsaUJBQUE7QUFESjs7QUFJRTtFQUNFLGVBQUE7RUFDQSxpQkFBQTtFQUVBLGNBQUE7RUFFQSxTQUFBO0FBSEo7O0FBTUU7RUFDRSxxQkFBQTtBQUhKOztBQU1FO0VBQ0Usc0JBQUE7RUFDQSx1QkFBQTtBQUhKOztBQUtFO0VBQ0Usa0NBQUE7QUFGSjs7QUFLRTtFQUNFLGFBQUE7QUFGSjs7QUFLRTtFQUNFLGFBQUE7QUFGSjs7QUFPRTtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtBQUpKOztBQU1FO0VBQ0Usa0JBQUE7RUFDQSxZQUFBO0VBQ0EsYUFBQTtFQUNBLFFBQUE7RUFDQSxTQUFBO0VBQ0EsVUFBQTtBQUhKIiwiZmlsZSI6ImNhcHR1cmV4LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi10b29sYmFyIHtcbiAgLS1iYWNrZ3JvdW5kOiAjMDAwMGZmO1xufVxuXG5pb24tY29udGVudHtcbiAgLS1iYWNrZ3JvdW5kOiNmMmYyZjc7XG59XG5cblxuI2NvbnRhaW5lciB7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIGxlZnQ6IDA7XG4gICAgcmlnaHQ6IDA7XG4gICAgdG9wOiA1MCU7XG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVZKC01MCUpO1xuICB9XG5cbiAgI2NvbnRhaW5lciBzdHJvbmcge1xuICAgIGZvbnQtc2l6ZTogMjBweDtcbiAgICBsaW5lLWhlaWdodDogMjZweDtcbiAgfVxuXG4gICNjb250YWluZXIgcCB7XG4gICAgZm9udC1zaXplOiAxNnB4O1xuICAgIGxpbmUtaGVpZ2h0OiAyMnB4O1xuXG4gICAgY29sb3I6ICM4YzhjOGM7XG5cbiAgICBtYXJnaW46IDA7XG4gIH1cblxuICAjY29udGFpbmVyIGEge1xuICAgIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcbiAgfVxuXG4gICN2aWRlbyB7XG4gICAgd2lkdGg6IDEwMCUhaW1wb3J0YW50O1xuICAgIGhlaWdodDogMTAwJSFpbXBvcnRhbnQ7XG4gIH1cbiAgI2ljIHtcbiAgICBiYWNrZ3JvdW5kOnRyYW5zcGFyZW50IWltcG9ydGFudDtcbiAgfVxuXG4gIC5jYW1lcmFQcmV2aWV3e1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gIH1cblxuICAuY2FtZXJhUHJldmlldzJ7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICAvLyBsZWZ0OiA1MDBweDtcbiAgICAvLyBtYXJnaW4tbGVmdDogNTBweDtcbiAgfVxuXG4gIC5vdmVybGF5IHtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBoZWlnaHQ6IDEwMCU7XG4gICAgei1pbmRleDogMTA7XG4gIH1cbiAgI2Nsb3NlIHtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgd2lkdGg6IDEwMHB4O1xuICAgIGhlaWdodDoxMDBweDtcbiAgICB0b3AgOiAwcHg7XG4gICAgbGVmdDogMHB4O1xuICAgIHotaW5kZXg6IDE7XG4gIH1cbiJdfQ== */"]
});

/***/ })

}]);
//# sourceMappingURL=capturex-capturex-module.js.map