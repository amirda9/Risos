(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["tabs-tabs-module"],{

/***/ "MJr+":
/*!***********************************!*\
  !*** ./src/app/tabs/tabs.page.ts ***!
  \***********************************/
/*! exports provided: TabsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TabsPage", function() { return TabsPage; });
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../constants */ "l207");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var ngx_joyride__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ngx-joyride */ "zZ42");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "TEn/");




class TabsPage {
    constructor(joyrideService) {
        this.joyrideService = joyrideService;
    }
    ngOnInit() {
        if (localStorage.getItem(_constants__WEBPACK_IMPORTED_MODULE_0__["DID"]) != 'DID') {
            console.log("im", localStorage.getItem(_constants__WEBPACK_IMPORTED_MODULE_0__["DID"]));
        }
    }
}
TabsPage.ɵfac = function TabsPage_Factory(t) { return new (t || TabsPage)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](ngx_joyride__WEBPACK_IMPORTED_MODULE_2__["JoyrideService"])); };
TabsPage.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({ type: TabsPage, selectors: [["app-tabs"]], decls: 21, vars: 0, consts: [["slot", "bottom"], ["tab", "", "href", ""], ["tab", "notification"], ["src", "../../assets/lnr-alarm.svg", 2, "color", "#aaaaaa"], ["joyrideStep", "firstStep", "tab", "patients"], ["src", "../../assets/lnr-users.svg", 2, "color", "#aaaaaa"], ["joyrideStep", "secondStep", "tab", "orders"], ["src", "../../assets/lnr-book.svg", 2, "color", "#aaaaaa"], ["tab", "main"], ["src", "../../assets/lnr-home.svg", 2, "color", "#aaaaaa"], ["vertical", "bottom", "horizontal", "start", "edge", "", "slot", "fixed"], ["md", "caret-up", "ios", "chevron-up-circle-outline"], ["side", "top"], ["color", "light", "href", "https://instagram.com/risos_co"], ["name", "logo-instagram"], ["color", "light", "href", "https://linkedin.com/company/risos-smart-smile-design-platform"], ["name", "logo-linkedin"], ["color", "light", "href", "https://www.google.com/search?q=risos.ir"], ["name", "logo-google"]], template: function TabsPage_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "ion-tabs");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "ion-tab-bar", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](2, "ion-tab-button", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](3, "ion-tab-button", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](4, "ion-icon", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "ion-tab-button", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](6, "ion-icon", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](7, "ion-tab-button", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](8, "ion-icon", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](9, "ion-tab-button", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](10, "ion-icon", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](11, "ion-fab", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](12, "ion-fab-button");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](13, "ion-icon", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](14, "ion-fab-list", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](15, "ion-fab-button", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](16, "ion-icon", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](17, "ion-fab-button", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](18, "ion-icon", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](19, "ion-fab-button", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](20, "ion-icon", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    } }, directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonTabs"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonTabBar"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonTabButton"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonIcon"], ngx_joyride__WEBPACK_IMPORTED_MODULE_2__["JoyrideDirective"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonFab"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonFabButton"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonFabList"]], styles: ["ion-tab-bar[_ngcontent-%COMP%] {\n  --background:#f2f2f7;\n}\n\nion-fab-button[_ngcontent-%COMP%] {\n  bottom: 55px;\n  margin-left: 15px;\n  position: relative;\n  --border-radius: 15px;\n}\n\nion-tab-bar[_ngcontent-%COMP%] {\n  height: 60px;\n}\n\nion-tab-bar[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  font-size: 35px;\n}\n\nion-tab-bar[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  font-weight: 500;\n  font-size: 14px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uL3RhYnMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0Usb0JBQUE7QUFDRjs7QUFFQTtFQUNHLFlBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0VBRUEscUJBQUE7QUFBSDs7QUFJQztFQUVDLFlBQUE7QUFGRjs7QUFHRTtFQUNFLGVBQUE7QUFESjs7QUFHRTtFQUNFLGdCQUFBO0VBQ0EsZUFBQTtBQURKIiwiZmlsZSI6InRhYnMucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLXRhYi1iYXJ7XG4gIC0tYmFja2dyb3VuZDojZjJmMmY3O1xufVxuXG5pb24tZmFiLWJ1dHRvbiB7XG4gICBib3R0b206IDU1cHg7XG4gICBtYXJnaW4tbGVmdDogMTVweDtcbiAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgLy8gIHRyYW5zZm9ybTogcm90YXRlKDQ0ZGVnKTtcbiAgIC0tYm9yZGVyLXJhZGl1czogMTVweDtcbiAgLy8gIGJvcmRlcjogM3B4IHNvbGlkICNmZmY7XG4gfVxuXG4gaW9uLXRhYi1iYXIge1xuICAvLyAtLWJhY2tncm91bmQ6dmFyKC0tYnJhbmQtdGVydGlhcnkpO1xuICBoZWlnaHQ6IDYwcHg7XG4gIGlvbi1pY29uIHtcbiAgICBmb250LXNpemU6IDM1cHg7XG4gIH1cbiAgc3BhbiB7XG4gICAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgICBmb250LXNpemU6IDE0cHg7XG4gIH1cbn0iXX0= */"] });


/***/ }),

/***/ "hO9l":
/*!*************************************!*\
  !*** ./src/app/tabs/tabs.module.ts ***!
  \*************************************/
/*! exports provided: TabsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TabsPageModule", function() { return TabsPageModule; });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _tabs_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./tabs-routing.module */ "kB8F");
/* harmony import */ var _tabs_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./tabs.page */ "MJr+");
/* harmony import */ var ngx_joyride__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ngx-joyride */ "zZ42");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ "fXoL");








class TabsPageModule {
}
TabsPageModule.ɵfac = function TabsPageModule_Factory(t) { return new (t || TabsPageModule)(); };
TabsPageModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineNgModule"]({ type: TabsPageModule });
TabsPageModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineInjector"]({ imports: [[
            _angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["IonicModule"],
            _tabs_routing_module__WEBPACK_IMPORTED_MODULE_3__["TabsPageRoutingModule"],
            ngx_joyride__WEBPACK_IMPORTED_MODULE_5__["JoyrideModule"].forChild()
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵsetNgModuleScope"](TabsPageModule, { declarations: [_tabs_page__WEBPACK_IMPORTED_MODULE_4__["TabsPage"]], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"],
        _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormsModule"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["IonicModule"],
        _tabs_routing_module__WEBPACK_IMPORTED_MODULE_3__["TabsPageRoutingModule"], ngx_joyride__WEBPACK_IMPORTED_MODULE_5__["JoyrideModule"]] }); })();


/***/ }),

/***/ "kB8F":
/*!*********************************************!*\
  !*** ./src/app/tabs/tabs-routing.module.ts ***!
  \*********************************************/
/*! exports provided: TabsPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TabsPageRoutingModule", function() { return TabsPageRoutingModule; });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _tabs_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./tabs.page */ "MJr+");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");




const routes = [
    {
        path: '',
        component: _tabs_page__WEBPACK_IMPORTED_MODULE_1__["TabsPage"],
        children: [
            {
                path: 'main',
                loadChildren: () => Promise.all(/*! import() | main-main-module */[__webpack_require__.e("default~capturex-capturex-module~comparison-comparison-module~create-order-create-order-module~creat~e1ba7a73"), __webpack_require__.e("default~main-main-module~profile-profile-module"), __webpack_require__.e("main-main-module")]).then(__webpack_require__.bind(null, /*! ../main/main.module */ "XpXM")).then(m => m.MainPageModule)
            },
            {
                path: 'notification',
                loadChildren: () => Promise.all(/*! import() | notification-notification-module */[__webpack_require__.e("default~capturex-capturex-module~comparison-comparison-module~create-order-create-order-module~creat~e1ba7a73"), __webpack_require__.e("notification-notification-module")]).then(__webpack_require__.bind(null, /*! ../notification/notification.module */ "TLzw")).then(m => m.NotificationPageModule)
            },
            {
                path: 'profile',
                loadChildren: () => Promise.all(/*! import() | profile-profile-module */[__webpack_require__.e("default~capturex-capturex-module~comparison-comparison-module~create-order-create-order-module~creat~e1ba7a73"), __webpack_require__.e("default~create-patient-create-patient-module~gallery-gallery-module~p-detail-p-detail-module~profile~1e5d1939"), __webpack_require__.e("default~main-main-module~profile-profile-module"), __webpack_require__.e("profile-profile-module")]).then(__webpack_require__.bind(null, /*! ../profile/profile.module */ "cRhG")).then(m => m.ProfilePageModule)
            },
            {
                path: 'labs',
                loadChildren: () => Promise.all(/*! import() | labs-labs-module */[__webpack_require__.e("default~capturex-capturex-module~comparison-comparison-module~create-order-create-order-module~creat~e1ba7a73"), __webpack_require__.e("default~capturex-capturex-module~lab-c-lab-c-module~lab-orders-lab-orders-module~labs-choose-labs-ch~d17e10bb"), __webpack_require__.e("default~capturex-capturex-module~create-patient-create-patient-module~lab-c-lab-c-module~lab-orders-~5f0481f7"), __webpack_require__.e("default~capturex-capturex-module~lab-c-lab-c-module~lab-orders-lab-orders-module~labs-choose-labs-ch~7ea3dc9e"), __webpack_require__.e("labs-labs-module")]).then(__webpack_require__.bind(null, /*! ../labs/labs.module */ "LwwQ")).then(m => m.LabsPageModule)
            },
            {
                path: 'patients',
                loadChildren: () => Promise.all(/*! import() | patients-patients-module */[__webpack_require__.e("default~capturex-capturex-module~comparison-comparison-module~create-order-create-order-module~creat~e1ba7a73"), __webpack_require__.e("default~capturex-capturex-module~lab-c-lab-c-module~lab-orders-lab-orders-module~labs-choose-labs-ch~d17e10bb"), __webpack_require__.e("default~capturex-capturex-module~create-patient-create-patient-module~lab-c-lab-c-module~lab-orders-~5f0481f7"), __webpack_require__.e("default~capturex-capturex-module~lab-c-lab-c-module~lab-orders-lab-orders-module~labs-choose-labs-ch~7ea3dc9e"), __webpack_require__.e("patients-patients-module")]).then(__webpack_require__.bind(null, /*! ../patients/patients.module */ "EH7E")).then(m => m.PatientsPageModule)
            },
            {
                path: 'orders',
                loadChildren: () => Promise.all(/*! import() | orders-orders-module */[__webpack_require__.e("default~capturex-capturex-module~comparison-comparison-module~create-order-create-order-module~creat~e1ba7a73"), __webpack_require__.e("default~capturex-capturex-module~lab-c-lab-c-module~lab-orders-lab-orders-module~labs-choose-labs-ch~d17e10bb"), __webpack_require__.e("default~capturex-capturex-module~create-patient-create-patient-module~lab-c-lab-c-module~lab-orders-~5f0481f7"), __webpack_require__.e("default~capturex-capturex-module~lab-c-lab-c-module~lab-orders-lab-orders-module~labs-choose-labs-ch~7ea3dc9e"), __webpack_require__.e("orders-orders-module")]).then(__webpack_require__.bind(null, /*! ../orders/orders.module */ "h9W5")).then(m => m.OrdersPageModule)
            },
            {
                path: 'lab-profile',
                loadChildren: () => Promise.all(/*! import() | lab-profile-lab-profile-module */[__webpack_require__.e("default~capturex-capturex-module~comparison-comparison-module~create-order-create-order-module~creat~e1ba7a73"), __webpack_require__.e("lab-profile-lab-profile-module")]).then(__webpack_require__.bind(null, /*! ../lab-profile/lab-profile.module */ "mt6B")).then(m => m.LabProfilePageModule)
            },
            {
                path: 'p-detail',
                loadChildren: () => Promise.all(/*! import() | p-detail-p-detail-module */[__webpack_require__.e("default~capturex-capturex-module~comparison-comparison-module~create-order-create-order-module~creat~e1ba7a73"), __webpack_require__.e("default~create-patient-create-patient-module~gallery-gallery-module~p-detail-p-detail-module~profile~1e5d1939"), __webpack_require__.e("p-detail-p-detail-module")]).then(__webpack_require__.bind(null, /*! ../p-detail/p-detail.module */ "0kBo")).then(m => m.PDetailPageModule)
            },
            {
                path: '',
                redirectTo: '/tabs/main',
                pathMatch: 'full'
            }
        ]
    },
    {
        path: '',
        redirectTo: '/tabs/tab1',
        pathMatch: 'full'
    }
];
class TabsPageRoutingModule {
}
TabsPageRoutingModule.ɵfac = function TabsPageRoutingModule_Factory(t) { return new (t || TabsPageRoutingModule)(); };
TabsPageRoutingModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineNgModule"]({ type: TabsPageRoutingModule });
TabsPageRoutingModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({ imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"].forChild(routes)], _angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsetNgModuleScope"](TabsPageRoutingModule, { imports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]], exports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]] }); })();


/***/ })

}]);
//# sourceMappingURL=tabs-tabs-module.js.map