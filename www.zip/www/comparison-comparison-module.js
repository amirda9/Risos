(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["comparison-comparison-module"],{

/***/ "2ALG":
/*!*********************************************************!*\
  !*** ./src/app/comparison/comparison-routing.module.ts ***!
  \*********************************************************/
/*! exports provided: ComparisonPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ComparisonPageRoutingModule", function() { return ComparisonPageRoutingModule; });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _comparison_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./comparison.page */ "Iv6B");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");




const routes = [
    {
        path: '',
        component: _comparison_page__WEBPACK_IMPORTED_MODULE_1__["ComparisonPage"]
    }
];
class ComparisonPageRoutingModule {
}
ComparisonPageRoutingModule.ɵfac = function ComparisonPageRoutingModule_Factory(t) { return new (t || ComparisonPageRoutingModule)(); };
ComparisonPageRoutingModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineNgModule"]({ type: ComparisonPageRoutingModule });
ComparisonPageRoutingModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({ imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"].forChild(routes)], _angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsetNgModuleScope"](ComparisonPageRoutingModule, { imports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]], exports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]] }); })();


/***/ }),

/***/ "Iv6B":
/*!***********************************************!*\
  !*** ./src/app/comparison/comparison.page.ts ***!
  \***********************************************/
/*! exports provided: ComparisonPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ComparisonPage", function() { return ComparisonPage; });
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../constants */ "l207");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var src_generated_graphql__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/generated/graphql */ "FJRG");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngx-translate/core */ "sYmb");






class ComparisonPage {
    constructor(save_smile, route, router, servicegql, patientgql) {
        this.save_smile = save_smile;
        this.route = route;
        this.router = router;
        this.servicegql = servicegql;
        this.patientgql = patientgql;
        this.route.queryParams.subscribe(params => {
            if (this.router.getCurrentNavigation().extras.state) {
                this.img = this.router.getCurrentNavigation().extras.state.image;
                this._id = this.router.getCurrentNavigation().extras.state._id;
                this.ratio = this.router.getCurrentNavigation().extras.state.ratio;
                this.t_model = this.router.getCurrentNavigation().extras.state.model;
                this.t_color = this.router.getCurrentNavigation().extras.state.color;
                // console.log("smile _id")
                console.log(this.t_color);
                console.log(this.t_model);
            }
        });
    }
    ngOnInit() {
        this.patientgql.watch({
            id: "Patient:" + localStorage.getItem(_constants__WEBPACK_IMPORTED_MODULE_0__["P_ID"])
        }).valueChanges.subscribe(res => {
            this.secondimg = res.data.Patient.patientPic.smileImage;
        });
        console.log(this._id);
        this.imageUrl = URL.createObjectURL(this.img);
        var img = document.getElementById("image");
        img.src = this.imageUrl;
        var b = this.img;
        //A Blob() is almost a File() - it's just missing the two properties below which we will add
        b.lastModifiedDate = new Date();
        b.name = new Date().getTime().toString() + '.png';
        //Cast to a File() type
        this.pic = b;
        console.log(this.pic);
        // img.height =
        // document.querySelector("#image").src = imageUrl;
    }
    forward() {
        // console.log("go")
        // console.log(this._id)
        this.servicegql.mutate({
            p_id: this._id,
            d_id: localStorage.getItem(_constants__WEBPACK_IMPORTED_MODULE_0__["ID"])
        }).subscribe(res => {
            // this.s_id=res.data.createService.service.id;
            // console.log(res.data.createService.service.id);
            this.s_id = res.data.createService.service.id;
            console.log(this.s_id);
            let navigationExtras = {
                state: {
                    s_id: this.s_id
                }
            };
            // console.log(this.s_id);
            this.router.navigate(['/lab-c'], navigationExtras);
        }, errors => {
        });
        // console.log(this.t_color,this.t_model , " infos")
        this.save_smile.mutate({
            dr: +localStorage.getItem(_constants__WEBPACK_IMPORTED_MODULE_0__["ID"]),
            p_id: +localStorage.getItem(_constants__WEBPACK_IMPORTED_MODULE_0__["P_ID"]),
            color: this.t_color,
            model: this.t_model,
            images: {
                smileImageResult: this.pic
            }
        }).subscribe(res => {
            console.log("sending res is :" + res.data.updateSmileDesign.status);
        });
    }
    backward() {
        let navigationExtras = {
            state: {
                id: this._id
            }
        };
        this.router.navigate(['/tabs/p-detail'], navigationExtras);
    }
}
ComparisonPage.ɵfac = function ComparisonPage_Factory(t) { return new (t || ComparisonPage)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_generated_graphql__WEBPACK_IMPORTED_MODULE_2__["Save_DesignGQL"]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_generated_graphql__WEBPACK_IMPORTED_MODULE_2__["ServiceGQL"]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_generated_graphql__WEBPACK_IMPORTED_MODULE_2__["PatientGQL"])); };
ComparisonPage.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({ type: ComparisonPage, selectors: [["app-comparison"]], decls: 17, vars: 1, consts: [["translate", "", 1, "ion-text-center", 2, "color", "white"], [1, "ion-padding-bottom"], ["id", "col", 1, "ion-text-center"], ["slot", "first", "id", "image", 2, "height", "400px"], ["slot", "second", "id", "image2", 2, "height", "400px", 3, "src"], [1, "ion-justify-content-center", "ion-padding-horizontal", "ion-padding-top"], ["size", "6", "size-lg", "4", 1, "ion-text-center"], ["shape", "round", "translate", "", 2, "text-transform", "none", "width", "100%", "color", "black", "--background", "#cf3109", "height", "2em", "font-size", "1em", "border-radius", "20px 20px 20px 20px", "border", "1px solid #e5e5ea", "box-shadow", "0px 1px 2px #000000", "font-weight", "lighter", 3, "click"], ["shape", "round", "translate", "", 2, "text-transform", "none", "width", "100%", "color", "black", "--background", "#73cf09", "height", "2em", "font-size", "1em", "border-radius", "20px 20px 20px 20px", "border", "1px solid #e5e5ea", "box-shadow", "0px 1px 2px #000000", "font-weight", "lighter", 3, "click"]], template: function ComparisonPage_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "ion-header");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "ion-toolbar");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](2, "ion-title", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](3, "Before and After");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](4, "ion-content");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "ion-row", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](6, "ion-col", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](7, "img-comparison-slider");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](8, "img", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](9, "img", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](10, "ion-row", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](11, "ion-col", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](12, "ion-button", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function ComparisonPage_Template_ion_button_click_12_listener() { return ctx.backward(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](13, " Try Again ");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](14, "ion-col", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](15, "ion-button", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function ComparisonPage_Template_ion_button_click_15_listener() { return ctx.forward(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](16, " Continue ");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](9);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpropertyInterpolate1"]("src", "https://api.risos.ir/mediafiles/", ctx.secondimg, "", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵsanitizeUrl"]);
    } }, directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonHeader"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonToolbar"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonTitle"], _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__["TranslateDirective"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonContent"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonRow"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonCol"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonButton"]], styles: ["ion-toolbar[_ngcontent-%COMP%] {\n  --background: #0000ff;\n}\n\nion-content[_ngcontent-%COMP%] {\n  --background: #f2f2f7;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uL2NvbXBhcmlzb24ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UscUJBQUE7QUFDRjs7QUFFQTtFQUNFLHFCQUFBO0FBQ0YiLCJmaWxlIjoiY29tcGFyaXNvbi5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tdG9vbGJhciB7XG4gIC0tYmFja2dyb3VuZDogIzAwMDBmZjtcbn1cblxuaW9uLWNvbnRlbnQge1xuICAtLWJhY2tncm91bmQ6ICNmMmYyZjc7XG59XG4iXX0= */"] });


/***/ }),

/***/ "t5C+":
/*!*************************************************!*\
  !*** ./src/app/comparison/comparison.module.ts ***!
  \*************************************************/
/*! exports provided: ComparisonPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ComparisonPageModule", function() { return ComparisonPageModule; });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _comparison_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./comparison-routing.module */ "2ALG");
/* harmony import */ var _comparison_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./comparison.page */ "Iv6B");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngx-translate/core */ "sYmb");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ "fXoL");







class ComparisonPageModule {
}
ComparisonPageModule.ɵfac = function ComparisonPageModule_Factory(t) { return new (t || ComparisonPageModule)(); };
ComparisonPageModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineNgModule"]({ type: ComparisonPageModule });
ComparisonPageModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineInjector"]({ imports: [[
            _angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["IonicModule"],
            _comparison_routing_module__WEBPACK_IMPORTED_MODULE_3__["ComparisonPageRoutingModule"],
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__["TranslateModule"]
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵsetNgModuleScope"](ComparisonPageModule, { declarations: [_comparison_page__WEBPACK_IMPORTED_MODULE_4__["ComparisonPage"]], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"],
        _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormsModule"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["IonicModule"],
        _comparison_routing_module__WEBPACK_IMPORTED_MODULE_3__["ComparisonPageRoutingModule"],
        _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__["TranslateModule"]] }); })();


/***/ })

}]);
//# sourceMappingURL=comparison-comparison-module.js.map