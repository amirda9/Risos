(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "+z3p":
/*!***************************************************!*\
  !*** ./src/app/resolver/data-resolver.service.ts ***!
  \***************************************************/
/*! exports provided: DataResolverService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DataResolverService", function() { return DataResolverService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _services_data_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../services/data.service */ "EnSQ");


class DataResolverService {
    constructor(dataService) {
        this.dataService = dataService;
    }
    resolve(route) {
        let id = route.paramMap.get('id');
        return this.dataService.getData();
    }
}
DataResolverService.ɵfac = function DataResolverService_Factory(t) { return new (t || DataResolverService)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_services_data_service__WEBPACK_IMPORTED_MODULE_1__["DataService"])); };
DataResolverService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({ token: DataResolverService, factory: DataResolverService.ɵfac, providedIn: 'root' });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! /home/mohammad/Work/RisosFront/Risos/src/main.ts */"zUnb");


/***/ }),

/***/ "4KHl":
/*!***********************************!*\
  !*** ./src/app/graphql.module.ts ***!
  \***********************************/
/*! exports provided: createApollo, GraphQLModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createApollo", function() { return createApollo; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GraphQLModule", function() { return GraphQLModule; });
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! apollo-angular */ "/IUn");
/* harmony import */ var _apollo_client_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @apollo/client/core */ "ALmS");
/* harmony import */ var apollo_angular_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! apollo-angular/http */ "E21e");
/* harmony import */ var _apollo_client_link_context__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @apollo/client/link/context */ "MWEN");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "fXoL");





const uri = 'https://api.risos.ir/graphql/'; // <-- add the URL of the GraphQL server here
const defaultOptions = {
    watchQuery: {
        fetchPolicy: 'no-cache',
        errorPolicy: 'ignore',
    },
    query: {
        fetchPolicy: 'no-cache',
        errorPolicy: 'all',
    },
};
function createApollo(httpLink) {
    const basic = Object(_apollo_client_link_context__WEBPACK_IMPORTED_MODULE_3__["setContext"])((operation, context) => ({
        headers: {
            Accept: 'charset=utf-8',
        },
        useMultipart: true,
    }));
    const auth = Object(_apollo_client_link_context__WEBPACK_IMPORTED_MODULE_3__["setContext"])((operation, context) => {
        const token = localStorage.getItem('AUTHTOKEN');
        if (token === null) {
            return {};
        }
        else {
            // console.log("graph module")
            return {
                headers: {
                    Authorization: `JWT ${token}`
                }
            };
        }
    });
    return {
        link: _apollo_client_core__WEBPACK_IMPORTED_MODULE_1__["ApolloLink"].from([basic, auth, httpLink.create({ uri })]),
        cache: new _apollo_client_core__WEBPACK_IMPORTED_MODULE_1__["InMemoryCache"](),
        defaultOptions: defaultOptions
    };
}
class GraphQLModule {
}
GraphQLModule.ɵfac = function GraphQLModule_Factory(t) { return new (t || GraphQLModule)(); };
GraphQLModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineNgModule"]({ type: GraphQLModule });
GraphQLModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineInjector"]({ providers: [
        {
            provide: apollo_angular__WEBPACK_IMPORTED_MODULE_0__["APOLLO_OPTIONS"],
            useFactory: createApollo,
            deps: [apollo_angular_http__WEBPACK_IMPORTED_MODULE_2__["HttpLink"]],
        },
    ] });


/***/ }),

/***/ "AytR":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
const environment = {
    production: false
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "EnSQ":
/*!******************************************!*\
  !*** ./src/app/services/data.service.ts ***!
  \******************************************/
/*! exports provided: DataService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DataService", function() { return DataService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "fXoL");

class DataService {
    constructor() { }
    setData(id) {
        this.data = id;
    }
    setRatio(e) {
        this.ratio = e;
    }
    getData() {
        return this.data;
    }
    getRatio() {
        return this.ratio;
    }
}
DataService.ɵfac = function DataService_Factory(t) { return new (t || DataService)(); };
DataService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({ token: DataService, factory: DataService.ɵfac, providedIn: 'root' });


/***/ }),

/***/ "KwcL":
/*!*************************************************************************************************************************************************!*\
  !*** ./node_modules/@ionic/pwa-elements/dist/esm lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
  \*************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./pwa-action-sheet.entry.js": [
		"jDxf",
		43
	],
	"./pwa-camera-modal-instance.entry.js": [
		"37vE",
		44
	],
	"./pwa-camera-modal.entry.js": [
		"cJxf",
		45
	],
	"./pwa-camera.entry.js": [
		"eGHz",
		46
	],
	"./pwa-toast.entry.js": [
		"fHjd",
		47
	]
};
function webpackAsyncContext(req) {
	if(!__webpack_require__.o(map, req)) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}

	var ids = map[req], id = ids[0];
	return __webpack_require__.e(ids[1]).then(function() {
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "KwcL";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "Sy1n":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ "qCKp");
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./constants */ "l207");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ngx-translate/core */ "sYmb");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ "ofXK");






function AppComponent_div_0_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "div", 2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](1, "img", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
} }
class AppComponent {
    constructor(platform, translate) {
        // translate.setDefaultLang('en');
        // the lang to use, if the lang isn't available, it will use the current loader to get them
        this.platform = platform;
        this.translate = translate;
        this.showSplash = true;
        // if(LANG){
        // this.translate.use("fa");
        // }
        // else{
        //   translate.use('en');
        // }
        translate.onLangChange.subscribe(x => this.dir = x.lang == "en" ? "ltr" : "rtl");
        this.init();
        // throw new Error("My first Sentry error!");
    }
    useLanguage(language) {
        this.translate.use(language);
    }
    init() {
        // this.translate.use('en');
        // console.log("fa")
        if (localStorage.getItem(_constants__WEBPACK_IMPORTED_MODULE_1__["LANG"])) {
            this.translate.use(localStorage.getItem(_constants__WEBPACK_IMPORTED_MODULE_1__["LANG"]));
            console.log("here");
        }
        else {
            this.translate.use('en');
            localStorage.setItem(_constants__WEBPACK_IMPORTED_MODULE_1__["LANG"], 'en');
        }
        // this.translate.use("fa");
        this.platform.ready().then(() => {
            // this.splash.hide();
            Object(rxjs__WEBPACK_IMPORTED_MODULE_0__["timer"])(2500).subscribe(() => {
                this.showSplash = false;
            });
        });
    }
}
AppComponent.ɵfac = function AppComponent_Factory(t) { return new (t || AppComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_3__["Platform"]), _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__["TranslateService"])); };
AppComponent.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({ type: AppComponent, selectors: [["app-root"]], decls: 3, vars: 2, consts: [["class", "splash", 4, "ngIf"], [3, "dir"], [1, "splash"], ["src", "../assets/splash.png", 2, "height", "100%", "width", "100%"]], template: function AppComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](0, AppComponent_div_0_Template, 2, 0, "div", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "ion-app", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](2, "ion-router-outlet");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngIf", ctx.showSplash);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("dir", ctx.dir);
    } }, directives: [_angular_common__WEBPACK_IMPORTED_MODULE_5__["NgIf"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonApp"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonRouterOutlet"]], styles: [".splash[_ngcontent-%COMP%] {\n  position: absolute;\n  width: 100%;\n  height: 100%;\n  z-index: 999;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  background: #f2f2f7;\n}\n\nion-app[dir=rtl][_ngcontent-%COMP%]    > *[_ngcontent-%COMP%] {\n  direction: rtl;\n  text-align: right !important;\n}\n\nion-app[dir=rtl][_ngcontent-%COMP%]    > h2[_ngcontent-%COMP%] {\n  direction: rtl;\n  text-align: right;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uL2FwcC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxZQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtBQUNGOztBQUNBO0VBQ0UsY0FBQTtFQUNBLDRCQUFBO0FBRUY7O0FBQUE7RUFDRSxjQUFBO0VBQ0EsaUJBQUE7QUFHRiIsImZpbGUiOiJhcHAuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuc3BsYXNoIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiAxMDAlO1xuICB6LWluZGV4OiA5OTk7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICBiYWNrZ3JvdW5kOiAjZjJmMmY3O1xufVxuaW9uLWFwcFtkaXI9XCJydGxcIl0gPiAqIHtcbiAgZGlyZWN0aW9uOiBydGw7XG4gIHRleHQtYWxpZ246IHJpZ2h0ICFpbXBvcnRhbnQ7XG59XG5pb24tYXBwW2Rpcj1cInJ0bFwiXSA+IGgyIHtcbiAgZGlyZWN0aW9uOiBydGw7XG4gIHRleHQtYWxpZ246IHJpZ2h0O1xufVxuIl19 */"] });


/***/ }),

/***/ "ZAI4":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: createTranslateLoader, SentryIonicErrorHandler, AppModule, HttpLoaderFactory */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createTranslateLoader", function() { return createTranslateLoader; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SentryIonicErrorHandler", function() { return SentryIonicErrorHandler; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HttpLoaderFactory", function() { return HttpLoaderFactory; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser */ "jhN1");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./app.component */ "Sy1n");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./app-routing.module */ "vY5A");
/* harmony import */ var _graphql_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./graphql.module */ "4KHl");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "1kSV");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _angular_service_worker__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/service-worker */ "Jho9");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../environments/environment */ "AytR");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ngx-translate/core */ "sYmb");
/* harmony import */ var _ngx_translate_http_loader__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @ngx-translate/http-loader */ "mqiu");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/common/http */ "tk/3");
/* harmony import */ var ngx_stars__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ngx-stars */ "t10x");
/* harmony import */ var mapir_angular_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! mapir-angular-component */ "7kha");
/* harmony import */ var _sentry_angular__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @sentry/angular */ "UH2p");
/* harmony import */ var ngx_joyride__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ngx-joyride */ "zZ42");
/* harmony import */ var _capacitor_community_camera_preview__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @capacitor-community/camera-preview */ "SFQQ");












// import ngx-translate and the http loader














function createTranslateLoader(http) {
    return new _ngx_translate_http_loader__WEBPACK_IMPORTED_MODULE_13__["TranslateHttpLoader"](http, './assets/translate/', '.json');
}
_sentry_angular__WEBPACK_IMPORTED_MODULE_17__["init"]({ dsn: "https://c3b8f701661842ee866cd0041c71db32@o951247.ingest.sentry.io/5900047" });
class SentryIonicErrorHandler extends _angular_core__WEBPACK_IMPORTED_MODULE_0__["ErrorHandler"] {
    handleError(error) {
        super.handleError(error);
        try {
            _sentry_angular__WEBPACK_IMPORTED_MODULE_17__["captureException"](error.originalError || error);
        }
        catch (e) {
            console.error(e);
        }
    }
}
class AppModule {
    constructor(trace) { }
}
AppModule.ɵfac = function AppModule_Factory(t) { return new (t || AppModule)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_sentry_angular__WEBPACK_IMPORTED_MODULE_17__["TraceService"])); };
AppModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({ type: AppModule, bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_4__["AppComponent"]] });
AppModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({ providers: [{ provide: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ErrorHandler"], useClass: SentryIonicErrorHandler }, { provide: _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouteReuseStrategy"], useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicRouteStrategy"] },
        {
            provide: _sentry_angular__WEBPACK_IMPORTED_MODULE_17__["TraceService"],
            deps: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]],
        }, ,], imports: [[ngx_joyride__WEBPACK_IMPORTED_MODULE_18__["JoyrideModule"].forRoot(), mapir_angular_component__WEBPACK_IMPORTED_MODULE_16__["NgxMapboxGLModule"], ngx_stars__WEBPACK_IMPORTED_MODULE_15__["NgxStarsModule"], _ngx_translate_core__WEBPACK_IMPORTED_MODULE_12__["TranslateModule"].forRoot({
                loader: {
                    provide: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_12__["TranslateLoader"],
                    useFactory: HttpLoaderFactory,
                    deps: [_angular_common_http__WEBPACK_IMPORTED_MODULE_14__["HttpClient"]]
                }
            }), _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["BrowserModule"], _angular_common_http__WEBPACK_IMPORTED_MODULE_14__["HttpClientModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"].forRoot(), _app_routing_module__WEBPACK_IMPORTED_MODULE_5__["AppRoutingModule"], _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_7__["NgbModule"], _graphql_module__WEBPACK_IMPORTED_MODULE_6__["GraphQLModule"], _angular_common__WEBPACK_IMPORTED_MODULE_8__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_9__["FormsModule"],
            _angular_service_worker__WEBPACK_IMPORTED_MODULE_10__["ServiceWorkerModule"].register('ngsw-worker.js', {
                enabled: _environments_environment__WEBPACK_IMPORTED_MODULE_11__["environment"].production,
                // Register the ServiceWorker as soon as the app is stable
                // or after 30 seconds (whichever comes first).
                registrationStrategy: 'registerWhenStable:30000'
            }),
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsetNgModuleScope"](AppModule, { declarations: [_app_component__WEBPACK_IMPORTED_MODULE_4__["AppComponent"]], imports: [ngx_joyride__WEBPACK_IMPORTED_MODULE_18__["JoyrideModule"], mapir_angular_component__WEBPACK_IMPORTED_MODULE_16__["NgxMapboxGLModule"], ngx_stars__WEBPACK_IMPORTED_MODULE_15__["NgxStarsModule"], _ngx_translate_core__WEBPACK_IMPORTED_MODULE_12__["TranslateModule"], _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["BrowserModule"], _angular_common_http__WEBPACK_IMPORTED_MODULE_14__["HttpClientModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"], _app_routing_module__WEBPACK_IMPORTED_MODULE_5__["AppRoutingModule"], _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_7__["NgbModule"], _graphql_module__WEBPACK_IMPORTED_MODULE_6__["GraphQLModule"], _angular_common__WEBPACK_IMPORTED_MODULE_8__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_9__["FormsModule"], _angular_service_worker__WEBPACK_IMPORTED_MODULE_10__["ServiceWorkerModule"]] }); })();
function HttpLoaderFactory(http) {
    return new _ngx_translate_http_loader__WEBPACK_IMPORTED_MODULE_13__["TranslateHttpLoader"](http);
}


/***/ }),

/***/ "kLfG":
/*!*****************************************************************************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
  \*****************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./ion-action-sheet.entry.js": [
		"dUtr",
		"common",
		0
	],
	"./ion-alert.entry.js": [
		"Q8AI",
		"common",
		1
	],
	"./ion-app_8.entry.js": [
		"hgI1",
		"common",
		2
	],
	"./ion-avatar_3.entry.js": [
		"CfoV",
		"common",
		3
	],
	"./ion-back-button.entry.js": [
		"Nt02",
		"common",
		4
	],
	"./ion-backdrop.entry.js": [
		"Q2Bp",
		5
	],
	"./ion-button_2.entry.js": [
		"0Pbj",
		"common",
		6
	],
	"./ion-card_5.entry.js": [
		"ydQj",
		"common",
		7
	],
	"./ion-checkbox.entry.js": [
		"4fMi",
		"common",
		8
	],
	"./ion-chip.entry.js": [
		"czK9",
		"common",
		9
	],
	"./ion-col_3.entry.js": [
		"/CAe",
		10
	],
	"./ion-datetime_3.entry.js": [
		"WgF3",
		"common",
		11
	],
	"./ion-fab_3.entry.js": [
		"uQcF",
		"common",
		12
	],
	"./ion-img.entry.js": [
		"wHD8",
		13
	],
	"./ion-infinite-scroll_2.entry.js": [
		"2lz6",
		14
	],
	"./ion-input.entry.js": [
		"ercB",
		"common",
		15
	],
	"./ion-item-option_3.entry.js": [
		"MGMP",
		"common",
		16
	],
	"./ion-item_8.entry.js": [
		"9bur",
		"common",
		17
	],
	"./ion-loading.entry.js": [
		"cABk",
		"common",
		18
	],
	"./ion-menu_3.entry.js": [
		"kyFE",
		"common",
		19
	],
	"./ion-modal.entry.js": [
		"TvZU",
		"common",
		20
	],
	"./ion-nav_2.entry.js": [
		"vnES",
		"common",
		21
	],
	"./ion-popover.entry.js": [
		"qCuA",
		"common",
		22
	],
	"./ion-progress-bar.entry.js": [
		"0tOe",
		"common",
		23
	],
	"./ion-radio_2.entry.js": [
		"h11V",
		"common",
		24
	],
	"./ion-range.entry.js": [
		"XGij",
		"common",
		25
	],
	"./ion-refresher_2.entry.js": [
		"nYbb",
		"common",
		26
	],
	"./ion-reorder_2.entry.js": [
		"smMY",
		"common",
		27
	],
	"./ion-ripple-effect.entry.js": [
		"STjf",
		28
	],
	"./ion-route_4.entry.js": [
		"k5eQ",
		"common",
		29
	],
	"./ion-searchbar.entry.js": [
		"OR5t",
		"common",
		30
	],
	"./ion-segment_2.entry.js": [
		"fSgp",
		"common",
		31
	],
	"./ion-select_3.entry.js": [
		"lfGF",
		"common",
		32
	],
	"./ion-slide_2.entry.js": [
		"5xYT",
		33
	],
	"./ion-spinner.entry.js": [
		"nI0H",
		"common",
		34
	],
	"./ion-split-pane.entry.js": [
		"NAQR",
		35
	],
	"./ion-tab-bar_2.entry.js": [
		"knkW",
		"common",
		36
	],
	"./ion-tab_2.entry.js": [
		"TpdJ",
		"common",
		37
	],
	"./ion-text.entry.js": [
		"ISmu",
		"common",
		38
	],
	"./ion-textarea.entry.js": [
		"U7LX",
		"common",
		39
	],
	"./ion-toast.entry.js": [
		"L3sA",
		"common",
		40
	],
	"./ion-toggle.entry.js": [
		"IUOf",
		"common",
		41
	],
	"./ion-virtual-scroll.entry.js": [
		"8Mb5",
		42
	]
};
function webpackAsyncContext(req) {
	if(!__webpack_require__.o(map, req)) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}

	var ids = map[req], id = ids[0];
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function() {
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "kLfG";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "l207":
/*!******************************!*\
  !*** ./src/app/constants.ts ***!
  \******************************/
/*! exports provided: USERNAME, AUTHTOKEN, ID, P_ID, DID, LANG */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "USERNAME", function() { return USERNAME; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AUTHTOKEN", function() { return AUTHTOKEN; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ID", function() { return ID; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "P_ID", function() { return P_ID; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DID", function() { return DID; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LANG", function() { return LANG; });
const USERNAME = 'USERNAME';
const AUTHTOKEN = 'AUTHTOKEN';
const ID = 'ID';
const P_ID = 'P_ID';
const DID = 'DID';
const LANG = 'LANG';
// export const Pic = null;


/***/ }),

/***/ "vY5A":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _resolver_data_resolver_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./resolver/data-resolver.service */ "+z3p");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");




const routes = [
    {
        path: 'home',
        loadChildren: () => Promise.all(/*! import() | home-home-module */[__webpack_require__.e("default~capturex-capturex-module~comparison-comparison-module~create-order-create-order-module~creat~e1ba7a73"), __webpack_require__.e("home-home-module")]).then(__webpack_require__.bind(null, /*! ./home/home.module */ "ct+p")).then(m => m.HomePageModule)
    },
    {
        path: '',
        redirectTo: 'home',
        pathMatch: 'full'
    },
    {
        path: 'login',
        loadChildren: () => Promise.all(/*! import() | login-login-module */[__webpack_require__.e("default~capturex-capturex-module~comparison-comparison-module~create-order-create-order-module~creat~e1ba7a73"), __webpack_require__.e("login-login-module")]).then(__webpack_require__.bind(null, /*! ./login/login.module */ "X3zk")).then(m => m.LoginPageModule)
    },
    {
        path: 'forget-pass',
        loadChildren: () => Promise.all(/*! import() | forget-pass-forget-pass-module */[__webpack_require__.e("default~capturex-capturex-module~comparison-comparison-module~create-order-create-order-module~creat~e1ba7a73"), __webpack_require__.e("forget-pass-forget-pass-module")]).then(__webpack_require__.bind(null, /*! ./forget-pass/forget-pass.module */ "gcE3")).then(m => m.ForgetPassPageModule)
    },
    {
        path: 'signup',
        loadChildren: () => Promise.all(/*! import() | signup-signup-module */[__webpack_require__.e("default~capturex-capturex-module~comparison-comparison-module~create-order-create-order-module~creat~e1ba7a73"), __webpack_require__.e("signup-signup-module")]).then(__webpack_require__.bind(null, /*! ./signup/signup.module */ "T9iC")).then(m => m.SignupPageModule)
    },
    {
        path: 'profile',
        loadChildren: () => Promise.all(/*! import() | profile-profile-module */[__webpack_require__.e("default~capturex-capturex-module~comparison-comparison-module~create-order-create-order-module~creat~e1ba7a73"), __webpack_require__.e("default~create-patient-create-patient-module~gallery-gallery-module~p-detail-p-detail-module~profile~1e5d1939"), __webpack_require__.e("default~main-main-module~profile-profile-module"), __webpack_require__.e("profile-profile-module")]).then(__webpack_require__.bind(null, /*! ./profile/profile.module */ "cRhG")).then(m => m.ProfilePageModule)
    },
    {
        path: 'patients',
        loadChildren: () => Promise.all(/*! import() | patients-patients-module */[__webpack_require__.e("default~capturex-capturex-module~comparison-comparison-module~create-order-create-order-module~creat~e1ba7a73"), __webpack_require__.e("default~capturex-capturex-module~lab-c-lab-c-module~lab-orders-lab-orders-module~labs-choose-labs-ch~d17e10bb"), __webpack_require__.e("default~capturex-capturex-module~create-patient-create-patient-module~lab-c-lab-c-module~lab-orders-~5f0481f7"), __webpack_require__.e("default~capturex-capturex-module~lab-c-lab-c-module~lab-orders-lab-orders-module~labs-choose-labs-ch~7ea3dc9e"), __webpack_require__.e("patients-patients-module")]).then(__webpack_require__.bind(null, /*! ./patients/patients.module */ "EH7E")).then(m => m.PatientsPageModule)
    },
    {
        path: 'verify',
        loadChildren: () => Promise.all(/*! import() | verify-verify-module */[__webpack_require__.e("default~capturex-capturex-module~comparison-comparison-module~create-order-create-order-module~creat~e1ba7a73"), __webpack_require__.e("verify-verify-module")]).then(__webpack_require__.bind(null, /*! ./verify/verify.module */ "JqDU")).then(m => m.VerifyPageModule)
    },
    {
        path: 'orders',
        loadChildren: () => Promise.all(/*! import() | orders-orders-module */[__webpack_require__.e("default~capturex-capturex-module~comparison-comparison-module~create-order-create-order-module~creat~e1ba7a73"), __webpack_require__.e("default~capturex-capturex-module~lab-c-lab-c-module~lab-orders-lab-orders-module~labs-choose-labs-ch~d17e10bb"), __webpack_require__.e("default~capturex-capturex-module~create-patient-create-patient-module~lab-c-lab-c-module~lab-orders-~5f0481f7"), __webpack_require__.e("default~capturex-capturex-module~lab-c-lab-c-module~lab-orders-lab-orders-module~labs-choose-labs-ch~7ea3dc9e"), __webpack_require__.e("orders-orders-module")]).then(__webpack_require__.bind(null, /*! ./orders/orders.module */ "h9W5")).then(m => m.OrdersPageModule)
    },
    {
        path: 'tabs',
        loadChildren: () => __webpack_require__.e(/*! import() | tabs-tabs-module */ "tabs-tabs-module").then(__webpack_require__.bind(null, /*! ./tabs/tabs.module */ "hO9l")).then(m => m.TabsPageModule)
    },
    {
        path: 'success',
        loadChildren: () => __webpack_require__.e(/*! import() | success-success-module */ "success-success-module").then(__webpack_require__.bind(null, /*! ./success/success.module */ "VUit")).then(m => m.SuccessPageModule)
    },
    {
        path: 'main',
        loadChildren: () => Promise.all(/*! import() | main-main-module */[__webpack_require__.e("default~capturex-capturex-module~comparison-comparison-module~create-order-create-order-module~creat~e1ba7a73"), __webpack_require__.e("default~main-main-module~profile-profile-module"), __webpack_require__.e("main-main-module")]).then(__webpack_require__.bind(null, /*! ./main/main.module */ "XpXM")).then(m => m.MainPageModule)
    },
    {
        path: 'notification',
        loadChildren: () => Promise.all(/*! import() | notification-notification-module */[__webpack_require__.e("default~capturex-capturex-module~comparison-comparison-module~create-order-create-order-module~creat~e1ba7a73"), __webpack_require__.e("notification-notification-module")]).then(__webpack_require__.bind(null, /*! ./notification/notification.module */ "TLzw")).then(m => m.NotificationPageModule)
    },
    {
        path: 'labs',
        loadChildren: () => Promise.all(/*! import() | labs-labs-module */[__webpack_require__.e("default~capturex-capturex-module~comparison-comparison-module~create-order-create-order-module~creat~e1ba7a73"), __webpack_require__.e("default~capturex-capturex-module~lab-c-lab-c-module~lab-orders-lab-orders-module~labs-choose-labs-ch~d17e10bb"), __webpack_require__.e("default~capturex-capturex-module~create-patient-create-patient-module~lab-c-lab-c-module~lab-orders-~5f0481f7"), __webpack_require__.e("default~capturex-capturex-module~lab-c-lab-c-module~lab-orders-lab-orders-module~labs-choose-labs-ch~7ea3dc9e"), __webpack_require__.e("labs-labs-module")]).then(__webpack_require__.bind(null, /*! ./labs/labs.module */ "LwwQ")).then(m => m.LabsPageModule)
    },
    {
        path: 'lab-profile',
        loadChildren: () => Promise.all(/*! import() | lab-profile-lab-profile-module */[__webpack_require__.e("default~capturex-capturex-module~comparison-comparison-module~create-order-create-order-module~creat~e1ba7a73"), __webpack_require__.e("lab-profile-lab-profile-module")]).then(__webpack_require__.bind(null, /*! ./lab-profile/lab-profile.module */ "mt6B")).then(m => m.LabProfilePageModule)
    },
    {
        path: 'order-detail',
        loadChildren: () => Promise.all(/*! import() | order-detail-order-detail-module */[__webpack_require__.e("default~capturex-capturex-module~comparison-comparison-module~create-order-create-order-module~creat~e1ba7a73"), __webpack_require__.e("default~capturex-capturex-module~lab-c-lab-c-module~lab-orders-lab-orders-module~labs-choose-labs-ch~d17e10bb"), __webpack_require__.e("order-detail-order-detail-module")]).then(__webpack_require__.bind(null, /*! ./order-detail/order-detail.module */ "4aIR")).then(m => m.OrderDetailPageModule)
    },
    {
        path: 'p-detail',
        loadChildren: () => Promise.all(/*! import() | p-detail-p-detail-module */[__webpack_require__.e("default~capturex-capturex-module~comparison-comparison-module~create-order-create-order-module~creat~e1ba7a73"), __webpack_require__.e("default~create-patient-create-patient-module~gallery-gallery-module~p-detail-p-detail-module~profile~1e5d1939"), __webpack_require__.e("p-detail-p-detail-module")]).then(__webpack_require__.bind(null, /*! ./p-detail/p-detail.module */ "0kBo")).then(m => m.PDetailPageModule)
    },
    {
        path: 'create-patient',
        loadChildren: () => Promise.all(/*! import() | create-patient-create-patient-module */[__webpack_require__.e("default~capturex-capturex-module~comparison-comparison-module~create-order-create-order-module~creat~e1ba7a73"), __webpack_require__.e("default~capturex-capturex-module~create-patient-create-patient-module~lab-c-lab-c-module~lab-orders-~5f0481f7"), __webpack_require__.e("default~create-patient-create-patient-module~gallery-gallery-module~p-detail-p-detail-module~profile~1e5d1939"), __webpack_require__.e("create-patient-create-patient-module")]).then(__webpack_require__.bind(null, /*! ./create-patient/create-patient.module */ "nHKr")).then(m => m.CreatePatientPageModule)
    },
    {
        path: 'createlab',
        loadChildren: () => Promise.all(/*! import() | createlab-createlab-module */[__webpack_require__.e("default~capturex-capturex-module~comparison-comparison-module~create-order-create-order-module~creat~e1ba7a73"), __webpack_require__.e("createlab-createlab-module")]).then(__webpack_require__.bind(null, /*! ./createlab/createlab.module */ "LHPf")).then(m => m.CreatelabPageModule)
    },
    {
        path: 'smile',
        loadChildren: () => Promise.all(/*! import() | smile-smile-module */[__webpack_require__.e("default~capturex-capturex-module~comparison-comparison-module~create-order-create-order-module~creat~e1ba7a73"), __webpack_require__.e("default~capturex-capturex-module~lab-c-lab-c-module~lab-orders-lab-orders-module~labs-choose-labs-ch~d17e10bb"), __webpack_require__.e("default~capturex-capturex-module~create-patient-create-patient-module~lab-c-lab-c-module~lab-orders-~5f0481f7"), __webpack_require__.e("default~capturex-capturex-module~lab-c-lab-c-module~lab-orders-lab-orders-module~labs-choose-labs-ch~7ea3dc9e"), __webpack_require__.e("common"), __webpack_require__.e("smile-smile-module")]).then(__webpack_require__.bind(null, /*! ./smile/smile.module */ "Jqk/")).then(m => m.SmilePageModule)
    },
    {
        path: 'smile/:id',
        resolve: {
            special: _resolver_data_resolver_service__WEBPACK_IMPORTED_MODULE_1__["DataResolverService"]
        },
        loadChildren: () => Promise.all(/*! import() | smile-smile-module */[__webpack_require__.e("default~capturex-capturex-module~comparison-comparison-module~create-order-create-order-module~creat~e1ba7a73"), __webpack_require__.e("default~capturex-capturex-module~lab-c-lab-c-module~lab-orders-lab-orders-module~labs-choose-labs-ch~d17e10bb"), __webpack_require__.e("default~capturex-capturex-module~create-patient-create-patient-module~lab-c-lab-c-module~lab-orders-~5f0481f7"), __webpack_require__.e("default~capturex-capturex-module~lab-c-lab-c-module~lab-orders-lab-orders-module~labs-choose-labs-ch~7ea3dc9e"), __webpack_require__.e("common"), __webpack_require__.e("smile-smile-module")]).then(__webpack_require__.bind(null, /*! ./smile/smile.module */ "Jqk/")).then(m => m.SmilePageModule)
    },
    {
        path: 'lab-c',
        loadChildren: () => Promise.all(/*! import() | lab-c-lab-c-module */[__webpack_require__.e("default~capturex-capturex-module~comparison-comparison-module~create-order-create-order-module~creat~e1ba7a73"), __webpack_require__.e("default~capturex-capturex-module~lab-c-lab-c-module~lab-orders-lab-orders-module~labs-choose-labs-ch~d17e10bb"), __webpack_require__.e("default~capturex-capturex-module~create-patient-create-patient-module~lab-c-lab-c-module~lab-orders-~5f0481f7"), __webpack_require__.e("default~capturex-capturex-module~lab-c-lab-c-module~lab-orders-lab-orders-module~labs-choose-labs-ch~7ea3dc9e"), __webpack_require__.e("lab-c-lab-c-module")]).then(__webpack_require__.bind(null, /*! ./lab-c/lab-c.module */ "0AcH")).then(m => m.LabCPageModule)
    },
    {
        path: 'gallery',
        loadChildren: () => Promise.all(/*! import() | gallery-gallery-module */[__webpack_require__.e("default~capturex-capturex-module~comparison-comparison-module~create-order-create-order-module~creat~e1ba7a73"), __webpack_require__.e("default~create-patient-create-patient-module~gallery-gallery-module~p-detail-p-detail-module~profile~1e5d1939"), __webpack_require__.e("gallery-gallery-module")]).then(__webpack_require__.bind(null, /*! ./gallery/gallery.module */ "3ros")).then(m => m.GalleryPageModule)
    },
    {
        path: 'contact-lab',
        loadChildren: () => __webpack_require__.e(/*! import() | contact-lab-contact-lab-module */ "contact-lab-contact-lab-module").then(__webpack_require__.bind(null, /*! ./contact-lab/contact-lab.module */ "2oS9")).then(m => m.ContactLabPageModule)
    },
    {
        path: 'reset-pass',
        loadChildren: () => Promise.all(/*! import() | reset-pass-reset-pass-module */[__webpack_require__.e("default~capturex-capturex-module~comparison-comparison-module~create-order-create-order-module~creat~e1ba7a73"), __webpack_require__.e("reset-pass-reset-pass-module")]).then(__webpack_require__.bind(null, /*! ./reset-pass/reset-pass.module */ "iKkx")).then(m => m.ResetPassPageModule)
    },
    {
        path: 'tutorial',
        loadChildren: () => __webpack_require__.e(/*! import() | tutorial-tutorial-module */ "tutorial-tutorial-module").then(__webpack_require__.bind(null, /*! ./tutorial/tutorial.module */ "6MGo")).then(m => m.TutorialPageModule)
    },
    {
        path: 'lab-orders',
        loadChildren: () => Promise.all(/*! import() | lab-orders-lab-orders-module */[__webpack_require__.e("default~capturex-capturex-module~comparison-comparison-module~create-order-create-order-module~creat~e1ba7a73"), __webpack_require__.e("default~capturex-capturex-module~lab-c-lab-c-module~lab-orders-lab-orders-module~labs-choose-labs-ch~d17e10bb"), __webpack_require__.e("default~capturex-capturex-module~create-patient-create-patient-module~lab-c-lab-c-module~lab-orders-~5f0481f7"), __webpack_require__.e("default~capturex-capturex-module~lab-c-lab-c-module~lab-orders-lab-orders-module~labs-choose-labs-ch~7ea3dc9e"), __webpack_require__.e("lab-orders-lab-orders-module")]).then(__webpack_require__.bind(null, /*! ./lab-orders/lab-orders.module */ "1uXY")).then(m => m.LabOrdersPageModule)
    },
    {
        path: 'lab-gallery',
        loadChildren: () => __webpack_require__.e(/*! import() | lab-gallery-lab-gallery-module */ "lab-gallery-lab-gallery-module").then(__webpack_require__.bind(null, /*! ./lab-gallery/lab-gallery.module */ "rS4i")).then(m => m.LabGalleryPageModule)
    },
    {
        path: 'edit',
        loadChildren: () => __webpack_require__.e(/*! import() | edit-edit-module */ "edit-edit-module").then(__webpack_require__.bind(null, /*! ./edit/edit.module */ "zFnc")).then(m => m.EditPageModule)
    },
    {
        path: 'risos',
        loadChildren: () => Promise.all(/*! import() | risos-risos-module */[__webpack_require__.e("default~capturex-capturex-module~comparison-comparison-module~create-order-create-order-module~creat~e1ba7a73"), __webpack_require__.e("default~capturex-capturex-module~lab-c-lab-c-module~lab-orders-lab-orders-module~labs-choose-labs-ch~d17e10bb"), __webpack_require__.e("default~capturex-capturex-module~create-patient-create-patient-module~lab-c-lab-c-module~lab-orders-~5f0481f7"), __webpack_require__.e("default~capturex-capturex-module~lab-c-lab-c-module~lab-orders-lab-orders-module~labs-choose-labs-ch~7ea3dc9e"), __webpack_require__.e("risos-risos-module")]).then(__webpack_require__.bind(null, /*! ./risos/risos.module */ "gJKh")).then(m => m.RisosPageModule)
    },
    {
        path: 'comparison',
        loadChildren: () => Promise.all(/*! import() | comparison-comparison-module */[__webpack_require__.e("default~capturex-capturex-module~comparison-comparison-module~create-order-create-order-module~creat~e1ba7a73"), __webpack_require__.e("comparison-comparison-module")]).then(__webpack_require__.bind(null, /*! ./comparison/comparison.module */ "t5C+")).then(m => m.ComparisonPageModule)
    },
    {
        path: 'process',
        loadChildren: () => Promise.all(/*! import() | process-process-module */[__webpack_require__.e("default~capturex-capturex-module~comparison-comparison-module~create-order-create-order-module~creat~e1ba7a73"), __webpack_require__.e("default~capturex-capturex-module~lab-c-lab-c-module~lab-orders-lab-orders-module~labs-choose-labs-ch~d17e10bb"), __webpack_require__.e("default~capturex-capturex-module~create-patient-create-patient-module~lab-c-lab-c-module~lab-orders-~5f0481f7"), __webpack_require__.e("default~capturex-capturex-module~lab-c-lab-c-module~lab-orders-lab-orders-module~labs-choose-labs-ch~7ea3dc9e"), __webpack_require__.e("process-process-module")]).then(__webpack_require__.bind(null, /*! ./process/process.module */ "/4kd")).then(m => m.ProcessPageModule)
    },
    {
        path: 'capturex',
        loadChildren: () => Promise.all(/*! import() | capturex-capturex-module */[__webpack_require__.e("default~capturex-capturex-module~comparison-comparison-module~create-order-create-order-module~creat~e1ba7a73"), __webpack_require__.e("default~capturex-capturex-module~lab-c-lab-c-module~lab-orders-lab-orders-module~labs-choose-labs-ch~d17e10bb"), __webpack_require__.e("default~capturex-capturex-module~create-patient-create-patient-module~lab-c-lab-c-module~lab-orders-~5f0481f7"), __webpack_require__.e("default~capturex-capturex-module~lab-c-lab-c-module~lab-orders-lab-orders-module~labs-choose-labs-ch~7ea3dc9e"), __webpack_require__.e("capturex-capturex-module")]).then(__webpack_require__.bind(null, /*! ./capturex/capturex.module */ "X8VC")).then(m => m.CapturexPageModule)
    },
    {
        path: 'invoice',
        loadChildren: () => Promise.all(/*! import() | invoice-invoice-module */[__webpack_require__.e("default~capturex-capturex-module~comparison-comparison-module~create-order-create-order-module~creat~e1ba7a73"), __webpack_require__.e("invoice-invoice-module")]).then(__webpack_require__.bind(null, /*! ./invoice/invoice.module */ "hdHI")).then(m => m.InvoicePageModule)
    },
    {
        path: 'create-order',
        loadChildren: () => Promise.all(/*! import() | create-order-create-order-module */[__webpack_require__.e("default~capturex-capturex-module~comparison-comparison-module~create-order-create-order-module~creat~e1ba7a73"), __webpack_require__.e("common"), __webpack_require__.e("create-order-create-order-module")]).then(__webpack_require__.bind(null, /*! ./create-order/create-order.module */ "158y")).then(m => m.CreateOrderPageModule)
    },
    {
        path: 'create-order/:id',
        loadChildren: () => Promise.all(/*! import() | create-order-create-order-module */[__webpack_require__.e("default~capturex-capturex-module~comparison-comparison-module~create-order-create-order-module~creat~e1ba7a73"), __webpack_require__.e("common"), __webpack_require__.e("create-order-create-order-module")]).then(__webpack_require__.bind(null, /*! ./create-order/create-order.module */ "158y")).then(m => m.CreateOrderPageModule)
    },
    {
        path: 'labs-choose',
        loadChildren: () => Promise.all(/*! import() | labs-choose-labs-choose-module */[__webpack_require__.e("default~capturex-capturex-module~comparison-comparison-module~create-order-create-order-module~creat~e1ba7a73"), __webpack_require__.e("default~capturex-capturex-module~lab-c-lab-c-module~lab-orders-lab-orders-module~labs-choose-labs-ch~d17e10bb"), __webpack_require__.e("default~capturex-capturex-module~create-patient-create-patient-module~lab-c-lab-c-module~lab-orders-~5f0481f7"), __webpack_require__.e("default~capturex-capturex-module~lab-c-lab-c-module~lab-orders-lab-orders-module~labs-choose-labs-ch~7ea3dc9e"), __webpack_require__.e("labs-choose-labs-choose-module")]).then(__webpack_require__.bind(null, /*! ./labs-choose/labs-choose.module */ "AOSi")).then(m => m.LabsChoosePageModule)
    },
    {
        path: 'map',
        loadChildren: () => __webpack_require__.e(/*! import() | map-map-module */ "map-map-module").then(__webpack_require__.bind(null, /*! ./map/map.module */ "yX1w")).then(m => m.MapPageModule)
    },
];
class AppRoutingModule {
}
AppRoutingModule.ɵfac = function AppRoutingModule_Factory(t) { return new (t || AppRoutingModule)(); };
AppRoutingModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineNgModule"]({ type: AppRoutingModule });
AppRoutingModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({ imports: [[
            _angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"].forRoot(routes, { preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_0__["PreloadAllModules"] })
        ], _angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsetNgModuleScope"](AppRoutingModule, { imports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]], exports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]] }); })();


/***/ }),

/***/ "zUnb":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/platform-browser */ "jhN1");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "ZAI4");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "AytR");
/* harmony import */ var _ionic_pwa_elements_loader__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/pwa-elements/loader */ "2Zi2");
/* harmony import */ var img_comparison_slider__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! img-comparison-slider */ "oZXS");
/* harmony import */ var img_comparison_slider__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(img_comparison_slider__WEBPACK_IMPORTED_MODULE_5__);






if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["enableProdMode"])();
}
_angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__["platformBrowser"]().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(err => console.log(err));
Object(_ionic_pwa_elements_loader__WEBPACK_IMPORTED_MODULE_4__["defineCustomElements"])(window);


/***/ }),

/***/ "zn8P":
/*!******************************************************!*\
  !*** ./$$_lazy_route_resource lazy namespace object ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "zn8P";

/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map