(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["labs-labs-module"],{

/***/ "LwwQ":
/*!*************************************!*\
  !*** ./src/app/labs/labs.module.ts ***!
  \*************************************/
/*! exports provided: LabsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LabsPageModule", function() { return LabsPageModule; });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _labs_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./labs-routing.module */ "b/MM");
/* harmony import */ var _labs_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./labs.page */ "lZki");
/* harmony import */ var _shared_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../shared.module */ "d2mR");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngx-translate/core */ "sYmb");
/* harmony import */ var ngx_stars__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ngx-stars */ "t10x");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ "fXoL");









class LabsPageModule {
}
LabsPageModule.ɵfac = function LabsPageModule_Factory(t) { return new (t || LabsPageModule)(); };
LabsPageModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdefineNgModule"]({ type: LabsPageModule });
LabsPageModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdefineInjector"]({ imports: [[
            _angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["IonicModule"],
            _labs_routing_module__WEBPACK_IMPORTED_MODULE_3__["LabsPageRoutingModule"],
            _shared_module__WEBPACK_IMPORTED_MODULE_5__["SharedModule"],
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__["TranslateModule"],
            ngx_stars__WEBPACK_IMPORTED_MODULE_7__["NgxStarsModule"]
        ]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵsetNgModuleScope"](LabsPageModule, { declarations: [_labs_page__WEBPACK_IMPORTED_MODULE_4__["LabsPage"]], imports: [_angular_common__WEBPACK_IMPORTED_MODULE_0__["CommonModule"],
        _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormsModule"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["IonicModule"],
        _labs_routing_module__WEBPACK_IMPORTED_MODULE_3__["LabsPageRoutingModule"],
        _shared_module__WEBPACK_IMPORTED_MODULE_5__["SharedModule"],
        _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__["TranslateModule"],
        ngx_stars__WEBPACK_IMPORTED_MODULE_7__["NgxStarsModule"]] }); })();


/***/ }),

/***/ "b/MM":
/*!*********************************************!*\
  !*** ./src/app/labs/labs-routing.module.ts ***!
  \*********************************************/
/*! exports provided: LabsPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LabsPageRoutingModule", function() { return LabsPageRoutingModule; });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _labs_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./labs.page */ "lZki");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "fXoL");




const routes = [
    {
        path: '',
        component: _labs_page__WEBPACK_IMPORTED_MODULE_1__["LabsPage"]
    }
];
class LabsPageRoutingModule {
}
LabsPageRoutingModule.ɵfac = function LabsPageRoutingModule_Factory(t) { return new (t || LabsPageRoutingModule)(); };
LabsPageRoutingModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineNgModule"]({ type: LabsPageRoutingModule });
LabsPageRoutingModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({ imports: [[_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"].forChild(routes)], _angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵsetNgModuleScope"](LabsPageRoutingModule, { imports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]], exports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__["RouterModule"]] }); })();


/***/ }),

/***/ "lZki":
/*!***********************************!*\
  !*** ./src/app/labs/labs.page.ts ***!
  \***********************************/
/*! exports provided: LabsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LabsPage", function() { return LabsPage; });
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs/operators */ "kU1M");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var src_generated_graphql__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/generated/graphql */ "FJRG");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngx-translate/core */ "sYmb");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _lab_card_lab_card_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../lab-card/lab-card.component */ "3eP6");










function LabsPage_ion_row_20_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "ion-row", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "ion-col", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](2, "app-lab-card", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function LabsPage_ion_row_20_Template_app_lab_card_click_2_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r3);
      const lab_r1 = ctx.$implicit;
      const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
      return ctx_r2.labOrders(lab_r1.node.id);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
  }

  if (rf & 2) {
    const lab_r1 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpropertyInterpolate"]("Name", lab_r1.node.relatedProfile.firstName);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("Number", 0);
  }
}

const _c0 = function () {
  return ["/createlab"];
};

class LabsPage {
  constructor(labsgql, router, search_l, labrated) {
    this.labsgql = labsgql;
    this.router = router;
    this.search_l = search_l;
    this.labrated = labrated;
    this.name = "Arman Laboratory";
    this.number = 6;
  }

  ngOnInit() {
    this.labs = this.labsgql.watch().valueChanges.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_0__["map"])(result => result.data.allLab.edges)); // console.log(this.labs)
    // this.starsComponent.setRating(0);
  }

  doRefresh(e) {
    this.labs = this.labsgql.watch().valueChanges.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_0__["map"])(result => result.data.allLab.edges));
    setTimeout(() => {
      console.log('Async operation has ended');
      e.target.complete();
    }, 2000);
  }

  labOrders(e) {
    let navigationExtras = {
      state: {
        id: e
      }
    };
    this.router.navigate(['/lab-profile'], navigationExtras);
  }

  byRate() {
    this.labs = this.labrated.watch().valueChanges.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_0__["map"])(result => result.data.allLab.edges));
  }

  search() {
    this.labs = this.search_l.watch({
      name: this.text
    }).valueChanges.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_0__["map"])(result => result.data.allLab.edges)); // this.search_l.watch({
    //   name:this.text
    // }).valueChanges.subscribe(res=>{
    //   this.search_res = res.data.allLab;
    // })
    // this.searched = true;
  }

}

LabsPage.ɵfac = function LabsPage_Factory(t) {
  return new (t || LabsPage)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_generated_graphql__WEBPACK_IMPORTED_MODULE_2__["LabsGQL"]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_generated_graphql__WEBPACK_IMPORTED_MODULE_2__["Search_LabGQL"]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](src_generated_graphql__WEBPACK_IMPORTED_MODULE_2__["LabratedGQL"]));
};

LabsPage.ɵcmp = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({
  type: LabsPage,
  selectors: [["app-labs"]],
  decls: 22,
  vars: 6,
  consts: [["translate", "", 1, "ion-text-center", 2, "color", "white"], ["slot", "end"], ["routerLinkActive", "router-link-active", "router", "", "color", "light", 3, "routerLink"], ["name", "add"], ["slot", "fixed", 3, "ionRefresh"], [1, "ion-justify-content-center", "ion-padding-horizontal", "ion-padding-top"], ["size", "2", 1, "ion-text-center"], ["fill", "clear", "translate", "", 3, "click"], ["size", "10"], [3, "ngModel", "ngModelChange"], [1, "ion-text-center"], ["expand", "block", "fill", "clear", "shape", "round", 3, "click"], ["class", "ion-no-padding", 4, "ngFor", "ngForOf"], [1, "ion-no-padding"], ["size", "12", "size-lg", "8", 1, "ion-text-center"], [3, "Name", "Number", "click"]],
  template: function LabsPage_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "ion-header");
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "ion-toolbar");
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](2, "ion-title", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](3, "Laboratory");
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](4, "ion-buttons", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "ion-button", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](6, "ion-icon", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](7, "ion-content");
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](8, "ion-refresher", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ionRefresh", function LabsPage_Template_ion_refresher_ionRefresh_8_listener($event) {
        return ctx.doRefresh($event);
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](9, "ion-refresher-content");
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](10, "ion-row", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](11, "ion-col", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](12, "ion-button", 7);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function LabsPage_Template_ion_button_click_12_listener() {
        return ctx.search();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](13, "Go");
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](14, "ion-col", 8);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](15, "ion-searchbar", 9);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ngModelChange", function LabsPage_Template_ion_searchbar_ngModelChange_15_listener($event) {
        return ctx.text = $event;
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](16, "ion-row");
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](17, "ion-col", 10);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](18, "ion-button", 11);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("click", function LabsPage_Template_ion_button_click_18_listener() {
        return ctx.byRate();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtext"](19, " Sort by Rate ");
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](20, LabsPage_ion_row_20_Template, 3, 2, "ion-row", 12);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](21, "async");
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](5);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("routerLink", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpureFunction0"](5, _c0));
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](10);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngModel", ctx.text);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](5);
      _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](21, 3, ctx.labs));
    }
  },
  directives: [_ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonHeader"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonToolbar"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonTitle"], _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__["TranslateDirective"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonButtons"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonButton"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterLinkActive"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["RouterLinkDelegate"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterLink"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonIcon"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonContent"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonRefresher"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonRefresherContent"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonRow"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonCol"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonSearchbar"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["TextValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_6__["NgControlStatus"], _angular_forms__WEBPACK_IMPORTED_MODULE_6__["NgModel"], _angular_common__WEBPACK_IMPORTED_MODULE_7__["NgForOf"], _lab_card_lab_card_component__WEBPACK_IMPORTED_MODULE_8__["LabCardComponent"]],
  pipes: [_angular_common__WEBPACK_IMPORTED_MODULE_7__["AsyncPipe"]],
  styles: ["ion-toolbar[_ngcontent-%COMP%] {\n  --background: #0000ff;\n}\n\nion-tab-bar[_ngcontent-%COMP%] {\n  --background:#f2f2f7;\n}\n\nion-content[_ngcontent-%COMP%] {\n  --background:#f2f2f7;\n}\n\nion-searchbar[_ngcontent-%COMP%] {\n  --border:1px solid #aaaaaa;\n  --border-radius: 20px 20px 20px 20px;\n  --placeholder-color:#aaaaaa;\n  --background:#f8f7fa;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uL2xhYnMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UscUJBQUE7QUFDRjs7QUFFQTtFQUNFLG9CQUFBO0FBQ0Y7O0FBRUE7RUFDRSxvQkFBQTtBQUNGOztBQUVBO0VBQ0UsMEJBQUE7RUFDQSxvQ0FBQTtFQUNBLDJCQUFBO0VBQ0Esb0JBQUE7QUFDRiIsImZpbGUiOiJsYWJzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi10b29sYmFyIHtcbiAgLS1iYWNrZ3JvdW5kOiAjMDAwMGZmO1xufVxuXG5pb24tdGFiLWJhcntcbiAgLS1iYWNrZ3JvdW5kOiNmMmYyZjc7XG59XG5cbmlvbi1jb250ZW50e1xuICAtLWJhY2tncm91bmQ6I2YyZjJmNztcbn1cblxuaW9uLXNlYXJjaGJhcntcbiAgLS1ib3JkZXI6MXB4IHNvbGlkICNhYWFhYWE7XG4gIC0tYm9yZGVyLXJhZGl1czogMjBweCAyMHB4IDIwcHggMjBweDtcbiAgLS1wbGFjZWhvbGRlci1jb2xvcjojYWFhYWFhO1xuICAtLWJhY2tncm91bmQ6I2Y4ZjdmYTtcbn1cbiJdfQ== */"]
});

/***/ })

}]);
//# sourceMappingURL=labs-labs-module.js.map