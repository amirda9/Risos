(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~capturex-capturex-module~comparison-comparison-module~create-order-create-order-module~creat~e1ba7a73"],{

/***/ "FJRG":
/*!**********************************!*\
  !*** ./src/generated/graphql.ts ***!
  \**********************************/
/*! exports provided: BusinesslogicOrderStatusChoices, BusinesslogicTicketMessgaeStatusChoices, ExtendprofileProfileGenderChoices, ExtendprofileProfileRoleChoices, ExtendprofileProfileStatusChoices, NotificationNotifServiceObjectTypeChoices, NotificationNotificationStatusChoices, SmiledesignSmileDesignServiceStatusChoices, Save_DesignDocument, Save_DesignGQL, CreatepatientDocument, CreatepatientGQL, CreatelabDocument, CreatelabGQL, ForgetPassDocument, ForgetPassGQL, DelpatientpicDocument, DelpatientpicGQL, Update_PicDocument, Update_PicGQL, InvoiceDocument, InvoiceGQL, ServicesDocument, ServicesGQL, CreateOrderDocument, CreateOrderGQL, Orders_LDocument, Orders_LGQL, TicketDocument, TicketGQL, LabDocument, LabGQL, LabsDocument, LabsGQL, Search_LabDocument, Search_LabGQL, CreateDeviceDocument, CreateDeviceGQL, LoginDocument, LoginGQL, VerifyDocument, VerifyGQL, LabratedDocument, LabratedGQL, AllnotifDocument, AllnotifGQL, OrderDocument, OrderGQL, UpdateOrderDocument, UpdateOrderGQL, OrdersDocument, OrdersGQL, Orders_SDocument, Orders_SGQL, Orders_StateDocument, Orders_StateGQL, DelPatientDocument, DelPatientGQL, PatientDocument, PatientGQL, PatientsDocument, PatientsGQL, Search_PDocument, Search_PGQL, LocDocument, LocGQL, ProfileDocument, ProfileGQL, ProfilePicDocument, ProfilePicGQL, ChangePassDocument, ChangePassGQL, Req_OtpDocument, Req_OtpGQL, RegisterDocument, RegisterGQL, ServiceDocument, ServiceGQL, AllsmileDocument, AllsmileGQL, OtpDocument, OtpGQL, Verify_UserDocument, Verify_UserGQL */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BusinesslogicOrderStatusChoices", function() { return BusinesslogicOrderStatusChoices; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BusinesslogicTicketMessgaeStatusChoices", function() { return BusinesslogicTicketMessgaeStatusChoices; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ExtendprofileProfileGenderChoices", function() { return ExtendprofileProfileGenderChoices; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ExtendprofileProfileRoleChoices", function() { return ExtendprofileProfileRoleChoices; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ExtendprofileProfileStatusChoices", function() { return ExtendprofileProfileStatusChoices; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NotificationNotifServiceObjectTypeChoices", function() { return NotificationNotifServiceObjectTypeChoices; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NotificationNotificationStatusChoices", function() { return NotificationNotificationStatusChoices; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SmiledesignSmileDesignServiceStatusChoices", function() { return SmiledesignSmileDesignServiceStatusChoices; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Save_DesignDocument", function() { return Save_DesignDocument; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Save_DesignGQL", function() { return Save_DesignGQL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CreatepatientDocument", function() { return CreatepatientDocument; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CreatepatientGQL", function() { return CreatepatientGQL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CreatelabDocument", function() { return CreatelabDocument; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CreatelabGQL", function() { return CreatelabGQL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ForgetPassDocument", function() { return ForgetPassDocument; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ForgetPassGQL", function() { return ForgetPassGQL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DelpatientpicDocument", function() { return DelpatientpicDocument; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DelpatientpicGQL", function() { return DelpatientpicGQL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Update_PicDocument", function() { return Update_PicDocument; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Update_PicGQL", function() { return Update_PicGQL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InvoiceDocument", function() { return InvoiceDocument; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InvoiceGQL", function() { return InvoiceGQL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ServicesDocument", function() { return ServicesDocument; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ServicesGQL", function() { return ServicesGQL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CreateOrderDocument", function() { return CreateOrderDocument; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CreateOrderGQL", function() { return CreateOrderGQL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Orders_LDocument", function() { return Orders_LDocument; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Orders_LGQL", function() { return Orders_LGQL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TicketDocument", function() { return TicketDocument; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TicketGQL", function() { return TicketGQL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LabDocument", function() { return LabDocument; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LabGQL", function() { return LabGQL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LabsDocument", function() { return LabsDocument; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LabsGQL", function() { return LabsGQL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Search_LabDocument", function() { return Search_LabDocument; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Search_LabGQL", function() { return Search_LabGQL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CreateDeviceDocument", function() { return CreateDeviceDocument; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CreateDeviceGQL", function() { return CreateDeviceGQL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginDocument", function() { return LoginDocument; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginGQL", function() { return LoginGQL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VerifyDocument", function() { return VerifyDocument; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VerifyGQL", function() { return VerifyGQL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LabratedDocument", function() { return LabratedDocument; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LabratedGQL", function() { return LabratedGQL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AllnotifDocument", function() { return AllnotifDocument; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AllnotifGQL", function() { return AllnotifGQL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OrderDocument", function() { return OrderDocument; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OrderGQL", function() { return OrderGQL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UpdateOrderDocument", function() { return UpdateOrderDocument; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UpdateOrderGQL", function() { return UpdateOrderGQL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OrdersDocument", function() { return OrdersDocument; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OrdersGQL", function() { return OrdersGQL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Orders_SDocument", function() { return Orders_SDocument; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Orders_SGQL", function() { return Orders_SGQL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Orders_StateDocument", function() { return Orders_StateDocument; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Orders_StateGQL", function() { return Orders_StateGQL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DelPatientDocument", function() { return DelPatientDocument; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DelPatientGQL", function() { return DelPatientGQL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PatientDocument", function() { return PatientDocument; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PatientGQL", function() { return PatientGQL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PatientsDocument", function() { return PatientsDocument; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PatientsGQL", function() { return PatientsGQL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Search_PDocument", function() { return Search_PDocument; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Search_PGQL", function() { return Search_PGQL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LocDocument", function() { return LocDocument; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LocGQL", function() { return LocGQL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProfileDocument", function() { return ProfileDocument; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProfileGQL", function() { return ProfileGQL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProfilePicDocument", function() { return ProfilePicDocument; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProfilePicGQL", function() { return ProfilePicGQL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ChangePassDocument", function() { return ChangePassDocument; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ChangePassGQL", function() { return ChangePassGQL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Req_OtpDocument", function() { return Req_OtpDocument; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Req_OtpGQL", function() { return Req_OtpGQL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RegisterDocument", function() { return RegisterDocument; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RegisterGQL", function() { return RegisterGQL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ServiceDocument", function() { return ServiceDocument; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ServiceGQL", function() { return ServiceGQL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AllsmileDocument", function() { return AllsmileDocument; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AllsmileGQL", function() { return AllsmileGQL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OtpDocument", function() { return OtpDocument; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OtpGQL", function() { return OtpGQL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Verify_UserDocument", function() { return Verify_UserDocument; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Verify_UserGQL", function() { return Verify_UserGQL; });
/* harmony import */ var apollo_angular__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! apollo-angular */ "/IUn");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");




/** An enumeration. */
var BusinesslogicOrderStatusChoices;
(function (BusinesslogicOrderStatusChoices) {
    /** Sent */
    BusinesslogicOrderStatusChoices["Sent"] = "SENT";
    /** Invoice Ready */
    BusinesslogicOrderStatusChoices["ProcessingInvoiceReady"] = "PROCESSING_INVOICE_READY";
    /** Accept */
    BusinesslogicOrderStatusChoices["ProcessingAccept"] = "PROCESSING_ACCEPT";
    /** Reject */
    BusinesslogicOrderStatusChoices["ProcessingReject"] = "PROCESSING_REJECT";
    /** Reject And Resend */
    BusinesslogicOrderStatusChoices["ProcessingRejectAndResend"] = "PROCESSING_REJECT_AND_RESEND";
    /** Molding */
    BusinesslogicOrderStatusChoices["ProcessingMolding"] = "PROCESSING_MOLDING";
    /** Ditch */
    BusinesslogicOrderStatusChoices["ProcessingDitch"] = "PROCESSING_DITCH";
    /** Scan */
    BusinesslogicOrderStatusChoices["ProcessingScan"] = "PROCESSING_SCAN";
    /** Water Wax */
    BusinesslogicOrderStatusChoices["ProcessingWaterWax"] = "PROCESSING_WATER_WAX";
    /** Designing */
    BusinesslogicOrderStatusChoices["ProcessingDesigning"] = "PROCESSING_DESIGNING";
    /** Print/Milling */
    BusinesslogicOrderStatusChoices["ProcessingPrintMilling"] = "PROCESSING_PRINT_MILLING";
    /** Ceramic */
    BusinesslogicOrderStatusChoices["ProcessingCeramic"] = "PROCESSING_CERAMIC";
    /** ready */
    BusinesslogicOrderStatusChoices["Ready"] = "READY";
})(BusinesslogicOrderStatusChoices || (BusinesslogicOrderStatusChoices = {}));
/** An enumeration. */
var BusinesslogicTicketMessgaeStatusChoices;
(function (BusinesslogicTicketMessgaeStatusChoices) {
    /** Read */
    BusinesslogicTicketMessgaeStatusChoices["Read"] = "READ";
    /** Unread */
    BusinesslogicTicketMessgaeStatusChoices["Unread"] = "UNREAD";
})(BusinesslogicTicketMessgaeStatusChoices || (BusinesslogicTicketMessgaeStatusChoices = {}));
/** An enumeration. */
var ExtendprofileProfileGenderChoices;
(function (ExtendprofileProfileGenderChoices) {
    /** Male */
    ExtendprofileProfileGenderChoices["Male"] = "MALE";
    /** Female */
    ExtendprofileProfileGenderChoices["Female"] = "FEMALE";
    /** Unknown */
    ExtendprofileProfileGenderChoices["Unknown"] = "UNKNOWN";
})(ExtendprofileProfileGenderChoices || (ExtendprofileProfileGenderChoices = {}));
/** An enumeration. */
var ExtendprofileProfileRoleChoices;
(function (ExtendprofileProfileRoleChoices) {
    /** Doctor */
    ExtendprofileProfileRoleChoices["Doctor"] = "DOCTOR";
    /** Patient */
    ExtendprofileProfileRoleChoices["Patient"] = "PATIENT";
    /** Lab */
    ExtendprofileProfileRoleChoices["Lab"] = "LAB";
})(ExtendprofileProfileRoleChoices || (ExtendprofileProfileRoleChoices = {}));
/** An enumeration. */
var ExtendprofileProfileStatusChoices;
(function (ExtendprofileProfileStatusChoices) {
    /** Active */
    ExtendprofileProfileStatusChoices["Active"] = "ACTIVE";
    /** Deactive */
    ExtendprofileProfileStatusChoices["Deactive"] = "DEACTIVE";
    /** Freetrial */
    ExtendprofileProfileStatusChoices["Freetrial"] = "FREETRIAL";
    /** Banned */
    ExtendprofileProfileStatusChoices["Banned"] = "BANNED";
})(ExtendprofileProfileStatusChoices || (ExtendprofileProfileStatusChoices = {}));
/** An enumeration. */
var NotificationNotifServiceObjectTypeChoices;
(function (NotificationNotifServiceObjectTypeChoices) {
    /** INVOICE */
    NotificationNotifServiceObjectTypeChoices["Invoice"] = "INVOICE";
    /** ORDER */
    NotificationNotifServiceObjectTypeChoices["Order"] = "ORDER";
})(NotificationNotifServiceObjectTypeChoices || (NotificationNotifServiceObjectTypeChoices = {}));
/** An enumeration. */
var NotificationNotificationStatusChoices;
(function (NotificationNotificationStatusChoices) {
    /** FAILED */
    NotificationNotificationStatusChoices["Failed"] = "FAILED";
    /** SUCCESS */
    NotificationNotificationStatusChoices["Success"] = "SUCCESS";
})(NotificationNotificationStatusChoices || (NotificationNotificationStatusChoices = {}));
/** An enumeration. */
var SmiledesignSmileDesignServiceStatusChoices;
(function (SmiledesignSmileDesignServiceStatusChoices) {
    /** READY */
    SmiledesignSmileDesignServiceStatusChoices["Ready"] = "READY";
    /** NOTREADY */
    SmiledesignSmileDesignServiceStatusChoices["Notready"] = "NOTREADY";
    /** IMPROPER IMAGE */
    SmiledesignSmileDesignServiceStatusChoices["ImproperImage"] = "IMPROPER_IMAGE";
})(SmiledesignSmileDesignServiceStatusChoices || (SmiledesignSmileDesignServiceStatusChoices = {}));
const Save_DesignDocument = apollo_angular__WEBPACK_IMPORTED_MODULE_0__["gql"] `
    mutation save_design($dr: Int!, $p_id: Int!, $images: SmileDesignImages, $model: String!, $color: String!) {
  updateSmileDesign(
    doctorId: $dr
    patientId: $p_id
    smileDesignImages: $images
    smileCategory: $model
    smileColor: $color
  ) {
    status
  }
}
    `;
class Save_DesignGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Mutation"] {
    constructor(apollo) {
        super(apollo);
        this.document = Save_DesignDocument;
    }
}
Save_DesignGQL.ɵfac = function Save_DesignGQL_Factory(t) { return new (t || Save_DesignGQL)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Apollo"])); };
Save_DesignGQL.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({ token: Save_DesignGQL, factory: Save_DesignGQL.ɵfac, providedIn: 'root' });
const CreatepatientDocument = apollo_angular__WEBPACK_IMPORTED_MODULE_0__["gql"] `
    mutation createpatient($Name: String!, $Pics: patientPics, $Phone_no: String!, $age: Int!, $id: Int!) {
  createPatient(
    name: $Name
    profileDoctorId: $id
    patientPics: $Pics
    age: $age
    phoneNumber: $Phone_no
  ) {
    token
  }
}
    `;
class CreatepatientGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Mutation"] {
    constructor(apollo) {
        super(apollo);
        this.document = CreatepatientDocument;
    }
}
CreatepatientGQL.ɵfac = function CreatepatientGQL_Factory(t) { return new (t || CreatepatientGQL)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Apollo"])); };
CreatepatientGQL.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({ token: CreatepatientGQL, factory: CreatepatientGQL.ɵfac, providedIn: 'root' });
const CreatelabDocument = apollo_angular__WEBPACK_IMPORTED_MODULE_0__["gql"] `
    mutation createlab($Username: String!, $mobile: String!, $land: String!, $adress: String!, $description: String!) {
  createLab(
    name: $Username
    phoneNumber: $mobile
    telephoneNumber: $land
    address: $adress
    description: $description
  ) {
    token
  }
}
    `;
class CreatelabGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Mutation"] {
    constructor(apollo) {
        super(apollo);
        this.document = CreatelabDocument;
    }
}
CreatelabGQL.ɵfac = function CreatelabGQL_Factory(t) { return new (t || CreatelabGQL)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Apollo"])); };
CreatelabGQL.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({ token: CreatelabGQL, factory: CreatelabGQL.ɵfac, providedIn: 'root' });
const ForgetPassDocument = apollo_angular__WEBPACK_IMPORTED_MODULE_0__["gql"] `
    mutation forgetPass($phoneNumber: String!) {
  forgetPass(phoneNumber: $phoneNumber) {
    status
  }
}
    `;
class ForgetPassGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Mutation"] {
    constructor(apollo) {
        super(apollo);
        this.document = ForgetPassDocument;
    }
}
ForgetPassGQL.ɵfac = function ForgetPassGQL_Factory(t) { return new (t || ForgetPassGQL)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Apollo"])); };
ForgetPassGQL.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({ token: ForgetPassGQL, factory: ForgetPassGQL.ɵfac, providedIn: 'root' });
const DelpatientpicDocument = apollo_angular__WEBPACK_IMPORTED_MODULE_0__["gql"] `
    mutation delpatientpic($id: Int!, $selectedFields: patientPicsDeletion) {
  deletePatientPic(patientId: $id, selectedFields: $selectedFields) {
    status
  }
}
    `;
class DelpatientpicGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Mutation"] {
    constructor(apollo) {
        super(apollo);
        this.document = DelpatientpicDocument;
    }
}
DelpatientpicGQL.ɵfac = function DelpatientpicGQL_Factory(t) { return new (t || DelpatientpicGQL)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Apollo"])); };
DelpatientpicGQL.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({ token: DelpatientpicGQL, factory: DelpatientpicGQL.ɵfac, providedIn: 'root' });
const Update_PicDocument = apollo_angular__WEBPACK_IMPORTED_MODULE_0__["gql"] `
    mutation update_pic($id: Int!, $pics: patientPics!) {
  updatePatientPic(patientId: $id, patientPics: $pics) {
    status
  }
}
    `;
class Update_PicGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Mutation"] {
    constructor(apollo) {
        super(apollo);
        this.document = Update_PicDocument;
    }
}
Update_PicGQL.ɵfac = function Update_PicGQL_Factory(t) { return new (t || Update_PicGQL)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Apollo"])); };
Update_PicGQL.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({ token: Update_PicGQL, factory: Update_PicGQL.ɵfac, providedIn: 'root' });
const InvoiceDocument = apollo_angular__WEBPACK_IMPORTED_MODULE_0__["gql"] `
    mutation invoice($s_id: ID!, $teeth: JSONString!, $central: String!) {
  toothMutationJson(
    relatedService: $s_id
    jsonObject: $teeth
    centralSize: $central
  ) {
    status
  }
}
    `;
class InvoiceGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Mutation"] {
    constructor(apollo) {
        super(apollo);
        this.document = InvoiceDocument;
    }
}
InvoiceGQL.ɵfac = function InvoiceGQL_Factory(t) { return new (t || InvoiceGQL)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Apollo"])); };
InvoiceGQL.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({ token: InvoiceGQL, factory: InvoiceGQL.ɵfac, providedIn: 'root' });
const ServicesDocument = apollo_angular__WEBPACK_IMPORTED_MODULE_0__["gql"] `
    query services {
  allToothsevice {
    edges {
      node {
        name
      }
    }
  }
}
    `;
class ServicesGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Query"] {
    constructor(apollo) {
        super(apollo);
        this.document = ServicesDocument;
    }
}
ServicesGQL.ɵfac = function ServicesGQL_Factory(t) { return new (t || ServicesGQL)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Apollo"])); };
ServicesGQL.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({ token: ServicesGQL, factory: ServicesGQL.ɵfac, providedIn: 'root' });
const CreateOrderDocument = apollo_angular__WEBPACK_IMPORTED_MODULE_0__["gql"] `
    mutation createOrder($sid: ID!, $lid: ID!, $date: Date) {
  createOrder(
    input: {relatedService: $sid, finalizedLab: $lid, status: "sent", expectedDate: $date}
  ) {
    order {
      id
    }
  }
}
    `;
class CreateOrderGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Mutation"] {
    constructor(apollo) {
        super(apollo);
        this.document = CreateOrderDocument;
    }
}
CreateOrderGQL.ɵfac = function CreateOrderGQL_Factory(t) { return new (t || CreateOrderGQL)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Apollo"])); };
CreateOrderGQL.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({ token: CreateOrderGQL, factory: CreateOrderGQL.ɵfac, providedIn: 'root' });
const Orders_LDocument = apollo_angular__WEBPACK_IMPORTED_MODULE_0__["gql"] `
    query orders_l($dr: [String], $lab: [String]) {
  allOrder(doctorId: $dr, finalizedLab_In: $lab) {
    edges {
      node {
        _id
        id
        status
        expectedDate
        relatedService {
          relatedPatient {
            relatedProfile {
              firstName
              profilePic
            }
          }
        }
      }
    }
  }
}
    `;
class Orders_LGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Query"] {
    constructor(apollo) {
        super(apollo);
        this.document = Orders_LDocument;
    }
}
Orders_LGQL.ɵfac = function Orders_LGQL_Factory(t) { return new (t || Orders_LGQL)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Apollo"])); };
Orders_LGQL.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({ token: Orders_LGQL, factory: Orders_LGQL.ɵfac, providedIn: 'root' });
const TicketDocument = apollo_angular__WEBPACK_IMPORTED_MODULE_0__["gql"] `
    mutation ticket($text: String!, $order: Int!, $send: Int!, $receive: Int!) {
  createTicker(
    message: $text
    relatedOrder: $order
    receiverProfile: $receive
    senderProfile: $send
  ) {
    status
  }
}
    `;
class TicketGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Mutation"] {
    constructor(apollo) {
        super(apollo);
        this.document = TicketDocument;
    }
}
TicketGQL.ɵfac = function TicketGQL_Factory(t) { return new (t || TicketGQL)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Apollo"])); };
TicketGQL.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({ token: TicketGQL, factory: TicketGQL.ɵfac, providedIn: 'root' });
const LabDocument = apollo_angular__WEBPACK_IMPORTED_MODULE_0__["gql"] `
    query lab($id: ID!) {
  Lab(id: $id) {
    relatedProfile {
      id
      _id
      firstName
      phoneNumber
      telephoneNumber
      profilePic
    }
    orderSet {
      expectedDate
      relatedService {
        relatedPatient {
          relatedProfile {
            firstName
            profilePic
          }
        }
      }
    }
  }
}
    `;
class LabGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Query"] {
    constructor(apollo) {
        super(apollo);
        this.document = LabDocument;
    }
}
LabGQL.ɵfac = function LabGQL_Factory(t) { return new (t || LabGQL)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Apollo"])); };
LabGQL.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({ token: LabGQL, factory: LabGQL.ɵfac, providedIn: 'root' });
const LabsDocument = apollo_angular__WEBPACK_IMPORTED_MODULE_0__["gql"] `
    query labs {
  allLab {
    edges {
      node {
        id
        _id
        relatedProfile {
          firstName
        }
      }
    }
  }
}
    `;
class LabsGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Query"] {
    constructor(apollo) {
        super(apollo);
        this.document = LabsDocument;
    }
}
LabsGQL.ɵfac = function LabsGQL_Factory(t) { return new (t || LabsGQL)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Apollo"])); };
LabsGQL.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({ token: LabsGQL, factory: LabsGQL.ɵfac, providedIn: 'root' });
const Search_LabDocument = apollo_angular__WEBPACK_IMPORTED_MODULE_0__["gql"] `
    query search_lab($name: String!) {
  allLab(searchByName: $name) {
    edges {
      node {
        id
        _id
        relatedProfile {
          firstName
        }
      }
    }
  }
}
    `;
class Search_LabGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Query"] {
    constructor(apollo) {
        super(apollo);
        this.document = Search_LabDocument;
    }
}
Search_LabGQL.ɵfac = function Search_LabGQL_Factory(t) { return new (t || Search_LabGQL)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Apollo"])); };
Search_LabGQL.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({ token: Search_LabGQL, factory: Search_LabGQL.ɵfac, providedIn: 'root' });
const CreateDeviceDocument = apollo_angular__WEBPACK_IMPORTED_MODULE_0__["gql"] `
    mutation CreateDevice($ProfileId: ID!, $deviceId: String!) {
  createDevice(ProfileId: $ProfileId, deviceId: $deviceId) {
    status
  }
}
    `;
class CreateDeviceGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Mutation"] {
    constructor(apollo) {
        super(apollo);
        this.document = CreateDeviceDocument;
    }
}
CreateDeviceGQL.ɵfac = function CreateDeviceGQL_Factory(t) { return new (t || CreateDeviceGQL)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Apollo"])); };
CreateDeviceGQL.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({ token: CreateDeviceGQL, factory: CreateDeviceGQL.ɵfac, providedIn: 'root' });
const LoginDocument = apollo_angular__WEBPACK_IMPORTED_MODULE_0__["gql"] `
    mutation login($username: String!, $password: String!) {
  tokenAuth(username: $username, password: $password) {
    token
    profile
  }
}
    `;
class LoginGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Mutation"] {
    constructor(apollo) {
        super(apollo);
        this.document = LoginDocument;
    }
}
LoginGQL.ɵfac = function LoginGQL_Factory(t) { return new (t || LoginGQL)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Apollo"])); };
LoginGQL.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({ token: LoginGQL, factory: LoginGQL.ɵfac, providedIn: 'root' });
const VerifyDocument = apollo_angular__WEBPACK_IMPORTED_MODULE_0__["gql"] `
    mutation verify($token: String!) {
  verifyToken(token: $token) {
    payload
  }
}
    `;
class VerifyGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Mutation"] {
    constructor(apollo) {
        super(apollo);
        this.document = VerifyDocument;
    }
}
VerifyGQL.ɵfac = function VerifyGQL_Factory(t) { return new (t || VerifyGQL)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Apollo"])); };
VerifyGQL.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({ token: VerifyGQL, factory: VerifyGQL.ɵfac, providedIn: 'root' });
const LabratedDocument = apollo_angular__WEBPACK_IMPORTED_MODULE_0__["gql"] `
    query labrated {
  allLab(sortByRate: "-rating") {
    edges {
      node {
        rating
        id
        relatedProfile {
          firstName
        }
      }
    }
  }
}
    `;
class LabratedGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Query"] {
    constructor(apollo) {
        super(apollo);
        this.document = LabratedDocument;
    }
}
LabratedGQL.ɵfac = function LabratedGQL_Factory(t) { return new (t || LabratedGQL)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Apollo"])); };
LabratedGQL.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({ token: LabratedGQL, factory: LabratedGQL.ɵfac, providedIn: 'root' });
const AllnotifDocument = apollo_angular__WEBPACK_IMPORTED_MODULE_0__["gql"] `
    query allnotif($id: [String]) {
  allNotification(receivers_In: $id) {
    edges {
      node {
        id
        message
      }
    }
  }
}
    `;
class AllnotifGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Query"] {
    constructor(apollo) {
        super(apollo);
        this.document = AllnotifDocument;
    }
}
AllnotifGQL.ɵfac = function AllnotifGQL_Factory(t) { return new (t || AllnotifGQL)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Apollo"])); };
AllnotifGQL.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({ token: AllnotifGQL, factory: AllnotifGQL.ɵfac, providedIn: 'root' });
const OrderDocument = apollo_angular__WEBPACK_IMPORTED_MODULE_0__["gql"] `
    query order($id: ID!) {
  Order(id: $id) {
    id
    status
    finalizedLab {
      relatedProfile {
        firstName
        _id
      }
    }
    ticketSet {
      edges {
        node {
          id
          message
          sender {
            _id
          }
        }
      }
    }
    invoice {
      price
      description
      actualDate
    }
    expectedDate
    relatedService {
      relatedPatient {
        relatedProfile {
          firstName
          lastName
          profilePic
        }
      }
    }
  }
}
    `;
class OrderGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Query"] {
    constructor(apollo) {
        super(apollo);
        this.document = OrderDocument;
    }
}
OrderGQL.ɵfac = function OrderGQL_Factory(t) { return new (t || OrderGQL)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Apollo"])); };
OrderGQL.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({ token: OrderGQL, factory: OrderGQL.ɵfac, providedIn: 'root' });
const UpdateOrderDocument = apollo_angular__WEBPACK_IMPORTED_MODULE_0__["gql"] `
    mutation UpdateOrder($id: ID!, $status: String) {
  updateOrder(status: $status, orderId: $id) {
    status
  }
}
    `;
class UpdateOrderGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Mutation"] {
    constructor(apollo) {
        super(apollo);
        this.document = UpdateOrderDocument;
    }
}
UpdateOrderGQL.ɵfac = function UpdateOrderGQL_Factory(t) { return new (t || UpdateOrderGQL)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Apollo"])); };
UpdateOrderGQL.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({ token: UpdateOrderGQL, factory: UpdateOrderGQL.ɵfac, providedIn: 'root' });
const OrdersDocument = apollo_angular__WEBPACK_IMPORTED_MODULE_0__["gql"] `
    query orders($dr: [String]) {
  allOrder(doctorId: $dr) {
    edges {
      node {
        _id
        id
        status
        expectedDate
        updatedAt
        relatedService {
          relatedPatient {
            relatedProfile {
              firstName
              profilePic
            }
          }
        }
      }
    }
  }
}
    `;
class OrdersGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Query"] {
    constructor(apollo) {
        super(apollo);
        this.document = OrdersDocument;
    }
}
OrdersGQL.ɵfac = function OrdersGQL_Factory(t) { return new (t || OrdersGQL)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Apollo"])); };
OrdersGQL.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({ token: OrdersGQL, factory: OrdersGQL.ɵfac, providedIn: 'root' });
const Orders_SDocument = apollo_angular__WEBPACK_IMPORTED_MODULE_0__["gql"] `
    query orders_s($name: String!) {
  allOrder(searchByName: $name) {
    edges {
      node {
        _id
        id
        status
        expectedDate
        updatedAt
        relatedService {
          relatedPatient {
            relatedProfile {
              firstName
              profilePic
            }
          }
        }
      }
    }
  }
}
    `;
class Orders_SGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Query"] {
    constructor(apollo) {
        super(apollo);
        this.document = Orders_SDocument;
    }
}
Orders_SGQL.ɵfac = function Orders_SGQL_Factory(t) { return new (t || Orders_SGQL)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Apollo"])); };
Orders_SGQL.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({ token: Orders_SGQL, factory: Orders_SGQL.ɵfac, providedIn: 'root' });
const Orders_StateDocument = apollo_angular__WEBPACK_IMPORTED_MODULE_0__["gql"] `
    query orders_state($name: String!) {
  allOrder(statusStartwith: $name) {
    edges {
      node {
        _id
        id
        status
        expectedDate
        updatedAt
        relatedService {
          relatedPatient {
            relatedProfile {
              firstName
              profilePic
            }
          }
        }
      }
    }
  }
}
    `;
class Orders_StateGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Query"] {
    constructor(apollo) {
        super(apollo);
        this.document = Orders_StateDocument;
    }
}
Orders_StateGQL.ɵfac = function Orders_StateGQL_Factory(t) { return new (t || Orders_StateGQL)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Apollo"])); };
Orders_StateGQL.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({ token: Orders_StateGQL, factory: Orders_StateGQL.ɵfac, providedIn: 'root' });
const DelPatientDocument = apollo_angular__WEBPACK_IMPORTED_MODULE_0__["gql"] `
    mutation delPatient($id: Int!) {
  deletePatient(patientId: $id) {
    status
  }
}
    `;
class DelPatientGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Mutation"] {
    constructor(apollo) {
        super(apollo);
        this.document = DelPatientDocument;
    }
}
DelPatientGQL.ɵfac = function DelPatientGQL_Factory(t) { return new (t || DelPatientGQL)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Apollo"])); };
DelPatientGQL.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({ token: DelPatientGQL, factory: DelPatientGQL.ɵfac, providedIn: 'root' });
const PatientDocument = apollo_angular__WEBPACK_IMPORTED_MODULE_0__["gql"] `
    query patient($id: ID!) {
  Patient(id: $id) {
    _id
    patientPic {
      sideImage
      fullSmileImage
      optionalImage
      smileImage
    }
    relatedProfile {
      firstName
      lastName
      profilePic
      _id
      age
      phoneNumber
    }
  }
}
    `;
class PatientGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Query"] {
    constructor(apollo) {
        super(apollo);
        this.document = PatientDocument;
    }
}
PatientGQL.ɵfac = function PatientGQL_Factory(t) { return new (t || PatientGQL)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Apollo"])); };
PatientGQL.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({ token: PatientGQL, factory: PatientGQL.ɵfac, providedIn: 'root' });
const PatientsDocument = apollo_angular__WEBPACK_IMPORTED_MODULE_0__["gql"] `
    query patients($dr: [String]) {
  allPatient(doctor_In: $dr) {
    edges {
      node {
        id
        relatedProfile {
          id
          firstName
          lastName
          profilePic
        }
      }
    }
  }
}
    `;
class PatientsGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Query"] {
    constructor(apollo) {
        super(apollo);
        this.document = PatientsDocument;
    }
}
PatientsGQL.ɵfac = function PatientsGQL_Factory(t) { return new (t || PatientsGQL)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Apollo"])); };
PatientsGQL.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({ token: PatientsGQL, factory: PatientsGQL.ɵfac, providedIn: 'root' });
const Search_PDocument = apollo_angular__WEBPACK_IMPORTED_MODULE_0__["gql"] `
    query search_p($id: [String]!, $name: String!) {
  allPatient(doctor_In: $id, searchByName: $name) {
    edges {
      node {
        id
        relatedProfile {
          id
          firstName
          lastName
          profilePic
        }
      }
    }
  }
}
    `;
class Search_PGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Query"] {
    constructor(apollo) {
        super(apollo);
        this.document = Search_PDocument;
    }
}
Search_PGQL.ɵfac = function Search_PGQL_Factory(t) { return new (t || Search_PGQL)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Apollo"])); };
Search_PGQL.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({ token: Search_PGQL, factory: Search_PGQL.ɵfac, providedIn: 'root' });
const LocDocument = apollo_angular__WEBPACK_IMPORTED_MODULE_0__["gql"] `
    mutation loc($long: Float!, $lat: Float!, $profileId: Int!) {
  locationMutation(latitude: $lat, longitude: $long, profileId: $profileId) {
    status
  }
}
    `;
class LocGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Mutation"] {
    constructor(apollo) {
        super(apollo);
        this.document = LocDocument;
    }
}
LocGQL.ɵfac = function LocGQL_Factory(t) { return new (t || LocGQL)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Apollo"])); };
LocGQL.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({ token: LocGQL, factory: LocGQL.ɵfac, providedIn: 'root' });
const ProfileDocument = apollo_angular__WEBPACK_IMPORTED_MODULE_0__["gql"] `
    query profile($id: ID!) {
  Profile(id: $id) {
    id
    phoneNumber
    email
    profilePic
  }
}
    `;
class ProfileGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Query"] {
    constructor(apollo) {
        super(apollo);
        this.document = ProfileDocument;
    }
}
ProfileGQL.ɵfac = function ProfileGQL_Factory(t) { return new (t || ProfileGQL)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Apollo"])); };
ProfileGQL.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({ token: ProfileGQL, factory: ProfileGQL.ɵfac, providedIn: 'root' });
const ProfilePicDocument = apollo_angular__WEBPACK_IMPORTED_MODULE_0__["gql"] `
    mutation profilePic($id: ID!, $profilePic: Upload) {
  updateProfile(profilePic: $profilePic, id: $id) {
    status
  }
}
    `;
class ProfilePicGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Mutation"] {
    constructor(apollo) {
        super(apollo);
        this.document = ProfilePicDocument;
    }
}
ProfilePicGQL.ɵfac = function ProfilePicGQL_Factory(t) { return new (t || ProfilePicGQL)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Apollo"])); };
ProfilePicGQL.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({ token: ProfilePicGQL, factory: ProfilePicGQL.ɵfac, providedIn: 'root' });
const ChangePassDocument = apollo_angular__WEBPACK_IMPORTED_MODULE_0__["gql"] `
    mutation changePass($new: String!, $user: String!) {
  changePassword(newPassword: $new, username: $user) {
    status
  }
}
    `;
class ChangePassGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Mutation"] {
    constructor(apollo) {
        super(apollo);
        this.document = ChangePassDocument;
    }
}
ChangePassGQL.ɵfac = function ChangePassGQL_Factory(t) { return new (t || ChangePassGQL)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Apollo"])); };
ChangePassGQL.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({ token: ChangePassGQL, factory: ChangePassGQL.ɵfac, providedIn: 'root' });
const Req_OtpDocument = apollo_angular__WEBPACK_IMPORTED_MODULE_0__["gql"] `
    mutation req_otp($username: String!) {
  requestOtp(username: $username) {
    status
  }
}
    `;
class Req_OtpGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Mutation"] {
    constructor(apollo) {
        super(apollo);
        this.document = Req_OtpDocument;
    }
}
Req_OtpGQL.ɵfac = function Req_OtpGQL_Factory(t) { return new (t || Req_OtpGQL)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Apollo"])); };
Req_OtpGQL.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({ token: Req_OtpGQL, factory: Req_OtpGQL.ɵfac, providedIn: 'root' });
const RegisterDocument = apollo_angular__WEBPACK_IMPORTED_MODULE_0__["gql"] `
    mutation register($username: String!, $password: String!, $email: String!) {
  createUser(username: $username, password: $password, email: $email) {
    token
  }
}
    `;
class RegisterGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Mutation"] {
    constructor(apollo) {
        super(apollo);
        this.document = RegisterDocument;
    }
}
RegisterGQL.ɵfac = function RegisterGQL_Factory(t) { return new (t || RegisterGQL)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Apollo"])); };
RegisterGQL.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({ token: RegisterGQL, factory: RegisterGQL.ɵfac, providedIn: 'root' });
const ServiceDocument = apollo_angular__WEBPACK_IMPORTED_MODULE_0__["gql"] `
    mutation service($p_id: ID!, $d_id: ID!) {
  createService(input: {relatedPatient: $p_id, relatedDoctor: $d_id}) {
    service {
      id
    }
  }
}
    `;
class ServiceGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Mutation"] {
    constructor(apollo) {
        super(apollo);
        this.document = ServiceDocument;
    }
}
ServiceGQL.ɵfac = function ServiceGQL_Factory(t) { return new (t || ServiceGQL)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Apollo"])); };
ServiceGQL.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({ token: ServiceGQL, factory: ServiceGQL.ɵfac, providedIn: 'root' });
const AllsmileDocument = apollo_angular__WEBPACK_IMPORTED_MODULE_0__["gql"] `
    query allsmile($d_id: [String], $p_id: [String]) {
  allSmiledesignservice(doctor_In: $d_id, patient_In: $p_id) {
    edges {
      node {
        status
        teethLessImage
        width
        heigth
      }
    }
  }
}
    `;
class AllsmileGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Query"] {
    constructor(apollo) {
        super(apollo);
        this.document = AllsmileDocument;
    }
}
AllsmileGQL.ɵfac = function AllsmileGQL_Factory(t) { return new (t || AllsmileGQL)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Apollo"])); };
AllsmileGQL.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({ token: AllsmileGQL, factory: AllsmileGQL.ɵfac, providedIn: 'root' });
const OtpDocument = apollo_angular__WEBPACK_IMPORTED_MODULE_0__["gql"] `
    mutation OTP($user: String!) {
  requestOtp(username: $user) {
    status
  }
}
    `;
class OtpGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Mutation"] {
    constructor(apollo) {
        super(apollo);
        this.document = OtpDocument;
    }
}
OtpGQL.ɵfac = function OtpGQL_Factory(t) { return new (t || OtpGQL)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Apollo"])); };
OtpGQL.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({ token: OtpGQL, factory: OtpGQL.ɵfac, providedIn: 'root' });
const Verify_UserDocument = apollo_angular__WEBPACK_IMPORTED_MODULE_0__["gql"] `
    mutation verify_user($Username: String!, $Otp: String!) {
  verifyUser(username: $Username, otpMessage: $Otp) {
    status
  }
}
    `;
class Verify_UserGQL extends apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Mutation"] {
    constructor(apollo) {
        super(apollo);
        this.document = Verify_UserDocument;
    }
}
Verify_UserGQL.ɵfac = function Verify_UserGQL_Factory(t) { return new (t || Verify_UserGQL)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](apollo_angular__WEBPACK_IMPORTED_MODULE_0__["Apollo"])); };
Verify_UserGQL.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({ token: Verify_UserGQL, factory: Verify_UserGQL.ɵfac, providedIn: 'root' });


/***/ })

}]);
//# sourceMappingURL=default~capturex-capturex-module~comparison-comparison-module~create-order-create-order-module~creat~e1ba7a73.js.map